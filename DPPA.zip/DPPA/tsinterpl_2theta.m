function OUT=tsinterpl_2theta(data,wavelen)
%%%TSimm 07

%%%turns theta values to K-values by interpolation

% close all

%             wavelen=0.398270000000000;
          

            I(:,:)=data(:,2);

            theta1=data(1,1);

            theta2=data(end,1);

            theta(:,:)=data(:,1);

            len=length(theta);
            
            
            
            K(:,:)=(180/pi)*2*asin(theta.*wavelen/(2));
            
            Krange=K(end)-K(1);

            Kincr=Krange/(1.5*len);
            
            Kincrstr=num2str(Kincr);
            posnumbers=find(Kincrstr~='0' & Kincrstr~='.' & Kincrstr~='-');posnumbers=posnumbers(1);
            Kincrstr=Kincrstr(1:posnumbers);
            Kincr=str2num(Kincrstr);
            
%             Kincr=.5e-04;
%             Kincr=1e-04;
            rk=rem(K(1),Kincr);
            K1=K(1)-rk;K1=K1/Kincr;K1=int16(K1);K1=double(K1)*Kincr;
            rk=rem(K(end),Kincr);
            Kend=K(end)-rk;
%             Kend=Kend/Kincr;
%             Kend=int16(Kend);
%             Kend=double(Kend)*Kincr;
            
            
            cc(:,:)=K1:Kincr:Kend;

            cc=cc';

         

            IK=interp1(K(:,1),I(:,1),cc(:,1),'cubic');

          

            OUT=[cc IK];

    



end