function varargout = aDPPA(varargin)
% ADPPA M-file for aDPPA.fig
%      ADPPA, by itself, creates a new ADPPA or raises the existing
%      singleton*.
%
%      H = ADPPA returns the handle to a new ADPPA or the handle to
%      the existing singleton*.
%
%      ADPPA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ADPPA.M with the given input arguments.
%
%      ADPPA('Property','Value',...) creates a new ADPPA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before steel_WAnew_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to aDPPA_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help aDPPA

% Last Modified by GUIDE v2.5 18-Mar-2016 01:57:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @aDPPA_OpeningFcn, ...
                   'gui_OutputFcn',  @aDPPA_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before aDPPA is made visible.
function aDPPA_OpeningFcn(hObject, eventdata, handles, varargin)
global delK type
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to aDPPA (see VARARGIN)
% Choose default command line output for aDPPA
delK=0.02;

set(handles.delK_t,'string',num2str(delK))
type=[0 0 100 300 0 0];
handles.output = hObject;

load([cd,'/0. variables/genset.mat'],'identa')
set(handles.sampleid_t,'string',identa)
% Update handles structure
guidata(hObject, handles);
grid on
% UIWAIT makes aDPPA wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = aDPPA_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in menu_l.
function menu_l_Callback(hObject, eventdata, handles)
global FCres 
% hObject    handle to menu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns menu_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from menu_l

load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/FC_Iall.mat'])

val=get(hObject,'value');

switch val
    case 2
        set(handles.res_p,'visible','off')
        set(handles.WA_p,'visible','on')
        set(handles.loadsave_p,'visible','off')
        set(handles.fit2allI_p,'visible','off')
    case 4
        set(handles.res_p,'visible','on')
        set(handles.WA_p,'visible','off')
        set(handles.loadsave_p,'visible','off')
        set(handles.q_t,'string',num2str(FCres(1)) )
        set(handles.gs_t,'string',num2str(FCres(2)*1e-4) )
        set(handles.rho_t,'string',num2str(FCres(3)) )
        set(handles.M_t,'string',num2str(FCres(4)) )
        set(handles.fit2allI_p,'visible','off')
        set(handles.edit_p,'visible','off')
        set(handles.resall_p,'visible','off')
        set(handles.resplot_p,'visible','on')
    case 5
        set(handles.res_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.loadsave_p,'visible','on')
        set(handles.fit2allI_p,'visible','off')
        set(handles.edit_p,'visible','off')
    case 6
        set(handles.FCset_p,'visible','on')
        set(handles.axes1_p,'visible','off')
        set(handles.menu_l,'visible','off')
        set(handles.res_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.loadsave_p,'visible','off')
        set(handles.fit2allI_p,'visible','off')
        set(handles.edit_p,'visible','off')
    case 3
        set(handles.fit2allI_p,'visible','on')
        
        set(handles.res_p,'visible','off')
        set(handles.WA_p,'visible','off')
        set(handles.loadsave_p,'visible','off')
        set(handles.edit_p,'visible','off')
    case 7
        set(handles.res_p,'visible','on')
        set(handles.WA_p,'visible','off')
        set(handles.loadsave_p,'visible','off')
        set(handles.resallnom_l,'value',1)
%         set(handles.q_t,'string',num2str(FCres(1)) )
%         set(handles.gs_t,'string',num2str(FCres(2)*1e-4) )
%         set(handles.rho_t,'string',num2str(FCres(3)) )
%         set(handles.M_t,'string',num2str(FCres(4)) )
        set(handles.fit2allI_p,'visible','off')
        set(handles.edit_p,'visible','off')
        set(handles.resall_p,'visible','on')
        set(handles.resplot_p,'visible','off')
end

% --- Executes during object creation, after setting all properties.
function menu_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to menu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in getFC_b.
function getFC_b_Callback(hObject, eventdata, handles)
global    delK selected 

% hObject    handle to getFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/FC_Iall.mat'])
load([cd,'/0. variables/phases.mat'])

sample_n=str2num( get(handles.sample_n_t,'string') );
% [  FC]=steel_findfourier(aa,aabcg,data, aa_I,aabcg_I, data_I,sample_n,0,dsettings);
[ FCi FC FCm]=ts_findfourier_indi(I_all,sample_n,selected);
clear FCi FCm
   if ishold==1;hold;end
axes(handles.axes1)
L=0:1:size( FC,1 )-1;
a3=0.5/delK;
L=L*a3;

% figure(4)

plot(L,FC(:,selected),'.:'),
xlim([0 sample_n*1.3*a3])
ind_leg= num2str( dsettings(1,1).index(selected,:) );
set(gca,'fontsize',17)
legend(ind_leg)
xlabel('L- fourier length Am','fontsize',17)
ylabel('Fourier coefficients A(n)','fontsize',17)
    
save([cd,'/0. variables/FC.mat'],'FC','selected','L','delK')

function sample_n_t_Callback(hObject, eventdata, handles)
% hObject    handle to sample_n_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sample_n_t as text
%        str2double(get(hObject,'String')) returns contents of sample_n_t as a double


% --- Executes during object creation, after setting all properties.
function sample_n_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample_n_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fitFC_b.
function fitFC_b_Callback(hObject, eventdata, handles)
global    FCres  type selected indiv_comb Burgcomb
% hObject    handle to fitFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/FC.mat'])
load([cd,'/0. variables/phases.mat'])


% set(handles.plf_l,'value',1)
% type(2)=0;


num=str2num( get(handles.sample_n_t,'string') );
hexcub=str2num(dsettings(1).cstruct(1));
if hexcub~=4
    set(handles.pfault_t,'string','P-Fault %')
else
    set(handles.pfault_t,'string','q2')
end



set(handles.boxlabel_p,'visible','on');
set(handles.boxlabelsf_p,'visible','off');
set(handles.hexdispop_p,'visible','off')
switch type(6)
    
    case 1
        if hexcub==4%hx
%             [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num);
            [ FCres all_I]=tsfourier_hex_new_lin(FC,dsettings,selected,num,'ind');
%             [ FCres all_I]=steel_tsfourier_all_hex_new(FC,dsettings,selected,num);
            
            CHOI=menu('Plast or equal?','Plast','Equal');
            if CHOI==2
            tizr=menu('Select Hexagonal type:','Zirconium','Titanium','Magnesium')-1;
            [indiv_comb Burgcomb]=contrast(FCres(1) ,FCres(5),tizr);
            Re=FCres(4)/( (FCres(3)*1e-4).^.5 );
            FCres(3)=FCres(3)/Burgcomb(4);
            FCres(4)=(FCres(3)*1e-4 )^.5*Re;
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
            
            
            set(handles.apc_t,'string',Burgcomb(3))
            set(handles.capc_t,'string',Burgcomb(2))
            set(handles.cpc_t,'string',Burgcomb(1))
            set(handles.hexdispop_p,'visible','on')
            else
                Burgcomb=[1/3 1/3 1/3 1];
            end
            
        else
            [ FCres all_I]=tsfourier_cub_lin_new(FC,dsettings,selected,num);
        end

    case 0
        if hexcub==4%hx
%             [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num);
            [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num,'ind');
%             [ FCres all_I]=steel_tsfourier_all_hex_new(FC,dsettings,selected,num);
            
            CHOI=menu('Plast or equal?','Plast','Equal');
            if CHOI==2
            tizr=menu('Select Hexagonal type:','Zirconium','Titanium','Magnesium')-1;
            [indiv_comb Burgcomb]=contrast(FCres(1) ,FCres(5),tizr);
            Re=FCres(4)/( (FCres(3)*1e-4).^.5 );
            FCres(3)=FCres(3)/Burgcomb(4);
            FCres(4)=(FCres(3)*1e-4 )^.5*Re;
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
            
            
            set(handles.apc_t,'string',Burgcomb(3))
            set(handles.capc_t,'string',Burgcomb(2))
            set(handles.cpc_t,'string',Burgcomb(1))
            set(handles.hexdispop_p,'visible','on')
            else
                Burgcomb=[1/3 1/3 1/3 1];
            end
        else
%             [ FCres all_I]=steel_tsfourier_hrpd(FC,dsettings,selected,num);
%             [ FCres all_I]=tsfourier_cub_planar_new(FC,dsettings,selected,num);

            if length(selected)<3
            [ FCres all_I]=tsfourier_cub_new_WA(FC,dsettings,selected,num);
            else
            
            [ FCres all_I]=tsfourier_cub_new(FC,dsettings,selected,num);
            end

        end
    
    case 2
        if hexcub==4%hx
%             [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num);
            [ FCres all_I]=steel_tsfourier_alt_hex(FC,dsettings,selected,num,'ind');
%             [ FCres all_I]=steel_tsfourier_all_hex_new(FC,dsettings,selected,num);
            
            CHOI=menu('Plast or equal?','Plast','Equal');
            if CHOI==2
            tizr=menu('Select Hexagonal type:','Zirconium','Titanium','Magnesium')-1;
            [indiv_comb Burgcomb]=contrast(FCres(1) ,FCres(5),tizr);
            Re=FCres(4)/( (FCres(3)*1e-4).^.5 );
            FCres(3)=FCres(3)/Burgcomb(4);
            FCres(4)=(FCres(3)*1e-4 )^.5*Re;
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
            
            
            set(handles.apc_t,'string',Burgcomb(3))
            set(handles.capc_t,'string',Burgcomb(2))
            set(handles.cpc_t,'string',Burgcomb(1))
            set(handles.hexdispop_p,'visible','on')
            else
                Burgcomb=[1/3 1/3 1/3 1];
            end
        else
            [FCres all_I]=steel_tsfourier_alt(FC,dsettings,selected,num);
%             all_I=zeros(size(all_I));
        end
    case 3
        if hexcub==4%hx
            [FCres all_I ]=steel_tsfourier_sfield(FC,dsettings,[selected],num);
            ;
        else
            [FCres all_I ]=steel_tsfourier_sfield(FC,dsettings,[1 5],num);
        end
        FCres(6)=FCres(5);
        FCres(5)=0;
        FCres(2)=1e6*1e4*FCres(2);
        set(handles.boxlabel_p,'visible','off');
        set(handles.boxlabelsf_p,'visible','on');
end


set(handles.q_t,'string',num2str(FCres(1)) )
set(handles.gs_t,'string',num2str(1e-4*FCres(2)) )
set(handles.rho_t,'string',num2str(FCres(3)) )
set(handles.M_t,'string',num2str(FCres(4)) )
set(handles.res_p,'visible','on')
set(handles.WA_p,'visible','off')
set(handles.fit2allI_p,'visible','off')
set(handles.menu_l,'value',4)

type
    
    if hexcub==4
        plf=num2str(FCres(5));
    else
        plf=num2str(FCres(5));
    end
    if length(plf)>7;plf=plf(1:7);end
    set(handles.plf_t,'string',plf )
type(5)=0;

if type(6)==3
    string_plotres = {
    'Res. Plot:'
    '1. FCs'
    '2. --'
    '3. --'
    '4. WA plot'
    '5. --'
    '6. --'
    '7. WH plot'
    '8. Intensity values'};
else
    string_plotres = {
    'Res. Plot:'
    '1. FCs'
    '2. FC log'
    '3. FC Wilkens'
    '4. WA plot'
    '5. Size FCs'
    '6. Strain FCs'
    '7. Kriv-Wilk plot'
    '8. Intensity values'};
end

save([cd,'/0. variables/all_I.mat'],'all_I')

set(handles.plotres_l,'string',string_plotres);

% --- Executes on button press in view_b.
function view_b_Callback(hObject, eventdata, handles)
global delK
% hObject    handle to getFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/fit_I.mat'])
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/data_I.mat'])
load([cd,'/0. variables/phases.mat'],'dsettings')


sample_n=str2num( get(handles.sample_n_t,'string') );
[I_all]=steel_findfourier_hrpd_tiesrf( aa,aabcg, data, aa_I,aabcg_I, data_I,sample_n,1,dsettings);

save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')



function q_t_Callback(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q_t as text
%        str2double(get(hObject,'String')) returns contents of q_t as a double


% --- Executes during object creation, after setting all properties.
function q_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function gs_t_Callback(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gs_t as text
%        str2double(get(hObject,'String')) returns contents of gs_t as a double


% --- Executes during object creation, after setting all properties.
function gs_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_t_Callback(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_t as text
%        str2double(get(hObject,'String')) returns contents of rho_t as a double


% --- Executes during object creation, after setting all properties.
function rho_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function M_t_Callback(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of M_t as text
%        str2double(get(hObject,'String')) returns contents of M_t as a double


% --- Executes during object creation, after setting all properties.
function M_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q_t as text
%        str2double(get(hObject,'String')) returns contents of q_t as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gs_t as text
%        str2double(get(hObject,'String')) returns contents of gs_t as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_t as text
%        str2double(get(hObject,'String')) returns contents of rho_t as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of M_t as text
%        str2double(get(hObject,'String')) returns contents of M_t as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to M_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in plotres_l.
function plotres_l_Callback(hObject, eventdata, handles)
global       Ifit type selected delK FCres
% hObject    handle to plotres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns plotres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from plotres_l
val=get(hObject,'value');
% axes(handles.axes1),if ishold==1;hold;end
load([cd,'/0. variables/FC.mat'])
load([cd,'/0. variables/FC_Iall.mat'])
load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/phases.mat'])
% load([cd,'/0. variables/FCres.mat'])
load([cd,'/0. variables/all_I.mat'],'all_I')


col={'ok';'+k';'xk';'<k';'>k';'^k';'sk';'ok--';'+k--';'xk--';'<k--';'>k--';'^k--';'sk--';'ok-.';'+k-.';'xk-.';'<k-.';'>k-.';'^k-.';'sk-.';'ok:';'+k:';'xk:';'<k:';'>k:';'^k:';'sk:';
    'ob-';'+b-';'xb-';'<b-';'>b-';'^b-';'sb-';'ob--';'+b--';'xb--';'<b--';'>b--';'^b--';'sb--';'ob-.';'+b-.';'xb-.';'<b-.';'>b-.';'^b-.';'sb-.';'ob:';'+b:';'xb:';'<b:';'>b:';'^b:';'sb:';
    'or-';'+r-';'xr-';'<r-';'>r-';'^r-';'sr-';'or--';'+r--';'xr--';'<r--';'>r--';'^r--';'sr--';'or-.';'+r-.';'xr-.';'<r-.';'>r-.';'^r-.';'sr-.';'or:';'+r:';'xr:';'<r:';'>r:';'^r:';'sr:';
};
if size(all_I,1)~=0
L=0:1:length( all_I(:,2) )-1;
L=L*FCres(end);
end
nmax=str2double( get(handles.sample_n_t,'string') );

% figure(5)
if ishold==1;hold;end
set(gca,'fontsize',17)
switch val 
    case 2
        for bh=1:length(selected)
        plot(L,FC(1:length(L),selected(bh)),col{bh},'markersize',10,'linewidth',2),if ishold~=1;hold;end
        end
        tsfourier_plot(val,nmax);
    case 3
        for bh=1:length(selected)
        plot(L,FC(1:length(L),selected(bh)),col{bh},'markersize',10,'linewidth',2),if ishold~=1;hold;end
        end
        tsfourier_plot(val,nmax);
    case 4
        for bh=1:length(selected)
        plot(L,FC(1:length(L),selected(bh)),col{bh},'markersize',10,'linewidth',2),if ishold~=1;hold;end
        end
        tsfourier_plot(val,nmax);
    case 5        
        tsfourier_plot(val,nmax);
    case 6  %Size FCs      
        tsfourier_plot(val,nmax);
        get(handles.sizehook_b,'value')
        if get(handles.sizehook_b,'value')==1
            set(handles.sizehook_b,'value',0);
            MNU=menu('Click after the hook','ok','no');
            if MNU ==1
            [ x y]=ginput(1);
            POS=find(abs(L-x)==min(abs(L-x)));
            POSS=POS:1:length(all_I);
            hook_sizefit(POSS)
            set(handles.gs_t,'string',num2str( FCres(2)*1e-4 ) )
            end
           
        end
    case 7        
        tsfourier_plot(val,nmax);    
    case 8        
        tsfourier_plot(val,nmax);
    case 9        
        tsfourier_plot(val,nmax);
end
         set(handles.plotres_l,'value',1)

% --- Executes during object creation, after setting all properties.
function plotres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_b.
function save_b_Callback(hObject, eventdata, handles)
global type FCres selected
% hObject    handle to save_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

batchQ=get(handles.batchON_b,'Value');

if batchQ==0

    [FileName,PathName] = uiputfile('*.mat','Select the Fit_Results file',[cd,'/5. Results/']);
    load([cd,'/0. variables/genset.mat'],'identa')
    filq=exist( [PathName,FileName]);
    if filq~=0
    load([PathName,FileName],'FCres_set')
    sizfit=length(FCres_set);
    len=length(FCres_set);
    else
        
        dotsq=find(FileName=='.');
        if isempty(dotsq)==0
            FileName=FileName(1:dotsq-1);
            FileName=[FileName,'_RES'];
        end
        len=0
        FCres_set=[];
    end
    
else
    FileName=get(handles.batch_t,'string');
    PathName=get(handles.batch2_t,'string');
    
    load([cd,'/0. variables/genset.mat'],'identa')
    load( [PathName,FileName])
    if exist('FCres_set')~=0
    load([PathName,FileName],'FCres_set')
    sizfit=length(FCres_set);
    len=length(FCres_set);
    else
        
    len=0;
        FCres_set=[];
    end
end



FCres_set(1,len+1).FCres=FCres;
FCres_set(1,len+1).type=type;
FCres_set(1,len+1).selected=selected;
FCres_set(1,len+1).identa=identa;

load([cd,'/0. variables/FC.mat'],'FC')
load([cd,'/0. variables/all_I.mat'],'all_I')

FCres_set(1,len+1).FC=FC;
FCres_set(1,len+1).all_I=all_I;

FCres_set(1,len+1).identa;
val=input('input \n');
FCres_set(1,len+1).val=val;
save([PathName,FileName],'FCres_set')

% --- Executes on button press in load_b.
function load_b_Callback(hObject, eventdata, handles)
global FileName PathName
% hObject    handle to load_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName] = uigetfile('*.mat','Select the Results file');
load([PathName,FileName])%,'FCres_set')
if exist('RESA')==1
    for n=1:length(RESA)
        FCres_set(n)=RESA(n);
       
    end
    FileName=[FileName(1:end-4),'_FCres_set.mat'];
    save([PathName,FileName],'FCres_set')
end
    for n=1:length(FCres_set)
        nom{n}=FCres_set(1,n).identa;
    end

set(handles.resallnom_l,'String',nom)

% load([PathName,FileName],'FCres_set')

% --- Executes on selection change in index_l.
function index_l_Callback(hObject, eventdata, handles)
global  selected delK
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns index_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from index_l

load([cd,'/0. variables/FC_Iall.mat'])
val=get(hObject,'value');
semilogq=get(handles.semilog_b,'value');
axes(handles.axes1)
% figure(3)
if ishold==1;hold;end
set(gca,'fontsize',17)
I_FC=get(handles.fcintens_b,'value');
switch I_FC
    case 0
        lenI=size(I_all,1);
        ttxp=-delK:delK/(.5*(lenI-1)):delK;
        if semilogq==1
            semilogy(ttxp,I_all(:,val,2),'b.-');%hold
        else
            plot(ttxp,I_all(:,val,2),'b.-');%hold
        end
        plot(ttxp,I_all(:,val,1),'r.-')
        plot(ttxp,I_all(:,val,3),'k-')
        ylim([-.1 1.1])
        legend('Instrumental','Measured','Real','Location','Northeast')

    case 1
    sample_n=str2num( get(handles.sample_n_t,'string') );
    [   FCi  FCnew FCm]=ts_findfourier_indi(I_all,sample_n,selected(val));
    
    n=0:1:length(FCm)-1;L=n*25;
    plot(L,FCnew(:,selected(val)),'-k','linewidth',3),
    hold
    plot(L,FCi(:,selected(val)),':k','linewidth',3)
    plot(L,FCm(:, selected(val) ),'--k','linewidth',3)
    
    legend('Real','Instrument','Measured','Real 2')
    xlabel('Fourier Length L (10^-^1^0m)')
    ylabel('Fourier coefficients A(L)', 'fontsize',17)
%     xlim([0 sample_n*1.3])
xlim([0 625])
    set(gca,'fontsize',17)
end




% --- Executes during object creation, after setting all properties.
function index_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in removepk_b.
function removepk_b_Callback(hObject, eventdata, handles)
global selected
% hObject    handle to removepk_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/phases.mat'])




NPKS=size(dsettings(1,1).index,1);
for n=1:NPKS
index{n}=num2str(dsettings(1,1).index(n,:));
end
index{n+1}='ALL';
index{n+2}='END';
sizeindex=size(index,2)
n=1;menusel=1;
selected=[];
while  menusel<sizeindex-1;
    menusel=menu('Select peaks to use',index')
    if menusel<sizeindex-1
        selected(n)=menusel;
        index{menusel}=['<- ',index{menusel},' ->'];
        n=n+1;
    elseif menusel==sizeindex-1
        selected=1:1:NPKS;
    end
end
% bb=menu('those or these','those','these');
% if bb==2
% selected=[1:1:13,15:18,20];
% end

selected=sort(selected);
set(handles.index_l,'value',1)
set(handles.index_l,'string',num2str(dsettings(1,1).index(selected,:)));
% --- Executes on button press in refreshpks_b.
function refreshpks_b_Callback(hObject, eventdata, handles)
% hObject    handle to refreshpks_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in semilog_b.
function semilog_b_Callback(hObject, eventdata, handles)
% hObject    handle to semilog_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of semilog_b


% --- Executes on selection change in Ifitindex_l.
function Ifitindex_l_Callback(hObject, eventdata, handles)
global Ifit 
% hObject    handle to Ifitindex_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Ifitindex_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Ifitindex_l
load([cd,'/0. variables/FC_Iall.mat'])
val=get(hObject,'value');
axes(handles.axes1),if ishold==1;hold;end
semilogy(Ifit(:,val)),hold,plot(real(I_all(:,val,1)),'o')
Idiff=-0.2+Ifit(:,val)-real(I_all(:,val,1));
plot(Idiff,'k')
plot(-0.2*ones(size(Idiff)),'b:')
legend('Fit','Measured','Difference (from -0.2)')
Idiff=abs( Ifit(:,val).^2-real(I_all(:,val,1)).^2 );
error=sum(Idiff);
set(handles.lsqerror_t,'string',num2str(error))
% --- Executes during object creation, after setting all properties.
function Ifitindex_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ifitindex_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Ifitreturn_b.
function Ifitreturn_b_Callback(hObject, eventdata, handles)
global Ifit
% hObject    handle to Ifitreturn_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Ifit_p,'visible','off')
        set(handles.plotres_l,'visible','on')
%         clear global Ifit


% --- Executes on button press in fitFCall_b.
function fitFCall_b_Callback(hObject, eventdata, handles)
global    FCres all_I type selected indiv_comb Burgcomb
% hObject    handle to fitFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
num=str2num( get(handles.sample_n_t,'string') );
load([cd,'/0. variables/FC.mat'])
load([cd,'/0. variables/phases.mat'])

num=str2num( get(handles.sample_n_t,'string') );
hexcub=str2num(dsettings(1).cstruct(1));
if hexcub~=4
    set(handles.pfault_t,'string','P-Fault %')
else
    set(handles.pfault_t,'string','q2')
end



set(handles.boxlabel_p,'visible','on');
set(handles.boxlabelsf_p,'visible','off');
set(handles.hexdispop_p,'visible','off')

switch type(6)
    
    case 1
        if hexcub==4%hx
%             [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num);
            [ FCres all_I]=tsfourier_hex_new_lin(FC,dsettings,selected,num,'all');
%             [ FCres all_I]=steel_tsfourier_all_hex_new(FC,dsettings,selected,num);
            
            CHOI=menu('Plast or equal?','Plast','Equal');
            if CHOI==2
            tizr=menu('Select Hexagonal type:','Zirconium','Titanium','Magnesium')-1;
            [indiv_comb Burgcomb]=contrast(FCres(1) ,FCres(5),tizr);
            Re=FCres(4)/( (FCres(3)*1e-4).^.5 );
            FCres(3)=FCres(3)/Burgcomb(4);
            FCres(4)=(FCres(3)*1e-4 )^.5*Re;
            all_I(:,3)=all_I(:,3)/Burgcomb(4);
            
            
            set(handles.apc_t,'string',Burgcomb(3))
            set(handles.capc_t,'string',Burgcomb(2))
            set(handles.cpc_t,'string',Burgcomb(1))
            set(handles.hexdispop_p,'visible','on')
            else
                Burgcomb=[1/3 1/3 1/3 1];
            end
            
        end
    case 0


        if type(2)~=0

            [ FCres all_I]=steel_tsfourier_allpl(FC,dsettings,selected,num, FCres);
        else
            if hexcub~=4
%                 [ FCres all_I]=tsfourier_cub_new(FC,dsettings,selected,num);
                [ FCres all_I]=steel_tsfourier_all_update(FC,dsettings,selected,num, FCres);
            else
                [ FCres all_I]=tsfourier_hex_new(FC,dsettings,selected,num,'all');
                CHOI=menu('Plast or equal?','Plast','Equal');
                    if CHOI==2
                    tizr=menu('Select Hexagonal type:','Zirconium','Titanium','Magnesium')-1;
                    [indiv_comb Burgcomb]=contrast(FCres(1) ,FCres(5),tizr);
                    Re=FCres(4)/( (FCres(3)*1e-4).^.5 );
                    FCres(3)=FCres(3)/Burgcomb(4);
                    FCres(4)=(FCres(3)*1e-4 )^.5*Re;
                    all_I(:,3)=all_I(:,3)/Burgcomb(4);


                    set(handles.apc_t,'string',Burgcomb(3))
                    set(handles.capc_t,'string',Burgcomb(2))
                    set(handles.cpc_t,'string',Burgcomb(1))
                    set(handles.hexdispop_p,'visible','on')
                    else
                        Burgcomb=[1/3 1/3 1/3 1];
                    end

            end
        end    
end
set(handles.q_t,'string',num2str(FCres(1)) )
set(handles.gs_t,'string',num2str(1e-4*FCres(2)) )
set(handles.rho_t,'string',num2str(FCres(3)) )
set(handles.M_t,'string',num2str(FCres(4)) )
set(handles.res_p,'visible','on')
set(handles.WA_p,'visible','off')
set(handles.menu_l,'value',4)

    plf=num2str(FCres(5));
    if length(plf)>7;plf=plf(1:7);end
    set(handles.plf_t,'string',plf)
    
    type(5)=1;
    
    
set(handles.q_t,'string',num2str(FCres(1)) )
set(handles.gs_t,'string',num2str(1e-4*FCres(2)) )
set(handles.rho_t,'string',num2str(FCres(3)) )
set(handles.M_t,'string',num2str(FCres(4)) )
set(handles.res_p,'visible','on')
set(handles.WA_p,'visible','off')
set(handles.fit2allI_p,'visible','off')
set(handles.menu_l,'value',4)

save([cd,'/0. variables/all_I.mat'],'all_I')

% --- Executes on button press in fitset_b.
function fitset_b_Callback(hObject, eventdata, handles)
% hObject    handle to fitset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.FCset_p,'visible','on')
set(handles.axes1_p,'visible','off')
set(handles.menu_l,'visible','off')

function KWLmin_t_Callback(hObject, eventdata, handles)
% hObject    handle to KWLmin_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KWLmin_t as text
%        str2double(get(hObject,'String')) returns contents of KWLmin_t as a double


% --- Executes during object creation, after setting all properties.
function KWLmin_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KWLmin_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function KWLmax_t_Callback(hObject, eventdata, handles)
% hObject    handle to KWLmax_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KWLmax_t as text
%        str2double(get(hObject,'String')) returns contents of KWLmax_t as a double


% --- Executes during object creation, after setting all properties.
function KWLmax_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KWLmax_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in strain_l.
function strain_l_Callback(hObject, eventdata, handles)
% hObject    handle to strain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns strain_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from strain_l


% --- Executes during object creation, after setting all properties.
function strain_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to strain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in doneFCset_b.
function doneFCset_b_Callback(hObject, eventdata, handles)
global type dsettings selected
% hObject    handle to doneFCset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



type(1)=get(handles.strain_l,'value')-1;
type(2)=get(handles.plf_l,'value')-1;

type(3)=str2double( get(handles.KWLmin_t,'string') );
type(4)=str2double( get(handles.KWLmax_t,'string') );
type(6)=get(handles.sizestrain_l,'value')-1;

modWA=get(handles.modWA_b,'value');
if modWA==1
%     selected=1:1:length(dsettings(1,1).d);
else
    index=dsettings(1,1).index;
    
        H2=Hsq(index);H=H2;
        m=1;
        for n=1:length(dsettings(1,1).d)
            sel{m}=( find(H2(n)==H2) );
            if length(sel{m})>1
            m=m+1;
            else
                sel=sel(1:m-1);
            end
            H2(n)=-1;
        end
        lensel=length(sel);
        if lensel>1
            for n=1:lensel
                selstr{n}=num2str(index(sel{n}(1),:));
            end

            num=menu('select peak',selstr);
            selected=sel{num};
        else 
            selected=sel{1};
        end
end
    
set(handles.FCset_p,'visible','off')
set(handles.axes1_p,'visible','on')
set(handles.menu_l,'visible','on')

;
% --- Executes on selection change in plf_l.
function plf_l_Callback(hObject, eventdata, handles)
% hObject    handle to plf_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns plf_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from plf_l


% --- Executes during object creation, after setting all properties.
function plf_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plf_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function plf_t_Callback(hObject, eventdata, handles)
% hObject    handle to plf_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of plf_t as text
%        str2double(get(hObject,'String')) returns contents of plf_t as a double


% --- Executes during object creation, after setting all properties.
function plf_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plf_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lsqerror_t_Callback(hObject, eventdata, handles)
% hObject    handle to lsqerror_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lsqerror_t as text
%        str2double(get(hObject,'String')) returns contents of lsqerror_t as a double


% --- Executes during object creation, after setting all properties.
function lsqerror_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lsqerror_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fit2allI_b.
function fit2allI_b_Callback(hObject, eventdata, handles)
global FCres Ifit  dsettings type aa data aa_I data_I sample_n selected
% hObject    handle to fit2allI_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
[I_all]=steel_findfourier( aa,data, aa_I, data_I,sample_n,1,dsettings);



        type(5)=2;
        selectedall=1:1:length(dsettings(1,1).d);
        [ FCres Ifit]=steel_tsfourier_I(I_all,dsettings,selectedall,20, FCres);
        
        
set(handles.q_t,'string',num2str(FCres(1)) )
set(handles.gs_t,'string',num2str(1e-4*FCres(2)) )
set(handles.rho_t,'string',num2str(FCres(3)) )
set(handles.M_t,'string',num2str(FCres(4)) )
set(handles.res_p,'visible','on')
set(handles.fit2allI_p,'visible','off')
set(handles.menu_l,'value',4)


    plf=num2str(FCres(5));
    if length(plf)>7;plf=plf(1:7);end
    set(handles.plf_t,'string',plf )

save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
% --- Executes on selection change in sizestrain_l.
function sizestrain_l_Callback(hObject, eventdata, handles)
% hObject    handle to sizestrain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns sizestrain_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sizestrain_l


% --- Executes during object creation, after setting all properties.
function sizestrain_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizestrain_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in modWA_b.
function modWA_b_Callback(hObject, eventdata, handles)
% hObject    handle to modWA_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of modWA_b


% --- Executes on button press in edit_b.
function edit_b_Callback(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

vis=get(handles.edit_p,'visible');
if strcmp(vis,'off')==1
    set(handles.edit_p,'visible','on')
else
    set(handles.edit_p,'visible','off')
end


% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton24.
function pushbutton24_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in plotraw_b.
function plotraw_b_Callback(hObject, eventdata, handles)
global   selected delK
load([cd,'/0. variables/FC_Iall.mat'])

lenI=size(I_all,1);
ttxp=-delK:delK/(.5*(lenI-1)):delK;

n=get(handles.index_l,'value');
n=selected(n);
xx=get(handles.realinstrplot_b,'value');
if xx==0;xx=2;else xx=1;end
I=I_all(:,n,xx);
% I=I/abs(max(I));
if ishold==1;hold;end
if get(handles.semilog_b,'value')==1
semilogy(ttxp,I,'k-.','Linewidth',2),hold
else
plot(ttxp,I,'k.-','Linewidth',2),hold
end

xlabel('delta-K')
ylabel('counts')
legend('data to use','Location','NorthEast')
                
                
                % %     legend('data to use','fit of rest','raw data','Location','NorthEast')
% --- Executes on button press in refit_b.
function refit_b_Callback(hObject, eventdata, handles)
global aa data delK
% hObject    handle to refit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% plotraw_b_Callback(hObject, eventdata, handles)
aa2=aa;

n=get(handles.index_l,'value');


incretth=data(2,1)-data(1,1);
incretth=double( int16(incretth/1e-5 ))*1e-05;
posdelK=delK/incretth;

    adjtth=abs(data(:,1)-aa(1,n));
    peakpos=find(adjtth==min(adjtth));
    Ipeak=data(:,2) ;
    posb4=peakpos-posdelK;if posb4<1;menu('ERROR too few data points b4 peaks','ok') ;end
    posa4=peakpos+posdelK;if posa4>size(data,1);menu('ERROR too few data points after peaks','ok');end
    
    I=Ipeak(posb4:posa4);
    
    delxp=abs( aa(1,:)-aa(1,n) );    
    aapos=find( delxp<delK *1.5);
    lenaa=length(aa);aa(:,lenaa)=[I(1) 0 0 0]';
    aapos(end+1)=lenaa;
    tth=data((posb4:posa4), 1);
    aa(:,aapos)=onepeak(tth, I, aa(:,aapos));
    
    lam=aa(:,aapos); 
    delxp=abs( lam(1,:)-aa(1,n) );    
    aapos=find( delxp==min(delxp) );
    lam(4,aapos)=0;
    lam(:,end)=0;
    newdata=I-pv_tv_aa(lam,data((posb4:posa4), 1));
    lendat=length(newdata);lendata=(lendat-rem(lendat,7))/7;
    
    newdata=[newdata(1:lendata)];%;newdata(lendat-lendata:lendat)];
    newtth=[tth(1:lendata,1)];%;tth(lendat-lendata:lendat,1)];
%     aa(:,lenaa)=lsqcurvefit(@pv_tv_aa, aa(:,lenaa), newtth,newdata);
    data((posb4:posa4), 2)=data((posb4:posa4), 2)-pv_tv_aa(aa(:,lenaa),data((posb4:posa4), 1)) +pv_tv_aa(aa2(:,lenaa),data((posb4:posa4), 1)) ;
    aa(:,lenaa)=aa2(:,lenaa);
    
    lam=aa;lam(2,n)=0;
    minI=min(data((posb4:posa4), 2) -pv_tv_aa(lam,data((posb4:posa4), 1)));
    if minI<0
        data((posb4:posa4), 2)=data((posb4:posa4), 2)+abs(minI);
    end
    
    
%     aa=aa2;
    
    plotraw_b_Callback(hObject, eventdata, handles)

% --- Executes on selection change in edit_l.
function edit_l_Callback(hObject, eventdata, handles)
global  selected 
load([cd,'/0. variables/FC_Iall.mat'])
load([cd,'/0. variables/fit.mat'])


plotraw_b_Callback(hObject, eventdata, handles)
value=get(hObject,'value');
peakno=get(handles.index_l,'value');
peakno=selected(peakno);
xx=get(handles.realinstrplot_b,'value');
sample_n=str2num( get(handles.sample_n_t,'string') );

if xx==0;xx=2;else xx=1;end

switch value
    case 2
        n=get(handles.index_l,'value');
        n=selected(n);
     
        if ishold==1;hold;end
        if get(handles.semilog_b,'value')==1
        semilogy(I_all(:,n,xx),'k-.','Linewidth',2),hold
        else
        plot(I_all(:,n,xx),'k.-','Linewidth',2),hold

        end

        menu('click on points to create new intensity points','ok');
        but=1;n=1;
        while but~=3
            [x(n) y(n) but]=ginput(1);
            n=n+1;
            
            
            
        end
        x=x(1:end-1);y=y(1:end-1);
        x2=sort(x);
        for nn=1:length(x2)
            x2pos(nn)=find(x2(nn)==x,1);
        end
            y2=y(x2pos);
            
            xstart=x2(1)-rem(x2(1),1)+1;
            xend=x2(end)-rem(x2(end),1);
            xdata=xstart:1:xend;
            newdata=interp1(x2,y2,xdata);
            
            I_all(xstart:xend,peakno,xx)=newdata;
            disp('hi');
    case 3 %%%increase all I
        
        
        [x y]=ginput(1);
        I_all(:,peakno,xx)=I_all(:,peakno,xx)-y;
        
    case 4 %%%increase all I
        
        
        [x y]=ginput(1);
        I_all(:,peakno,xx)=I_all(:,peakno,xx)+y;
    case 5
        LR=1;
        I_all(:,peakno,xx)=oneside(I_all(:,peakno,xx),LR);
       
    case 6
        LR=2;
        I_all(:,peakno,xx)=oneside(I_all(:,peakno,xx),LR);
    case 7
        quest=menu('Which peaks to adjust the background of?','All','Selected');
        if quest==1
            for n=1:length(selected)
                I_all=bcgmin(sample_n, selected(n), I_all);
            end
        else
            I_all=bcgmin(sample_n,peakno, I_all);
        end
    case 8
        
            for n=1:length(selected)
                I_all=alphastrip(selected(n), I_all);
            end
            
    case 9
        aatemp=aa(:,peakno);
        aatemp(1,:)=0;aatemp(2,:)=1;
        delK=str2num( get(handles.delK_t,'string') );
        len00=size(I_all,1);incr0=2*delK/(-1+len00);
        xdata=-delK:incr0:delK;
        I_all(:,peakno,xx)=pk_voigt2asymm(xdata',aatemp)';
        
end
% figure(55)
set(hObject,'value',1)
save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
 
plotraw_b_Callback(hObject, eventdata, handles)
                       
% --- Executes during object creation, after setting all properties.
function edit_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function delK_t_Callback(hObject, eventdata, handles)
global delK
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delK_t as text
%        str2double(get(hObject,'String')) returns contents of delK_t as a double
delK=str2num( get(hObject,'string') );


% --- Executes during object creation, after setting all properties.
function delK_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in realinstrplot_b.
function realinstrplot_b_Callback(hObject, eventdata, handles)
% hObject    handle to realinstrplot_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of realinstrplot_b


% --- Executes on button press in fcintens_b.
function fcintens_b_Callback(hObject, eventdata, handles)
% hObject    handle to fcintens_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fcintens_b


% --- Executes on button press in editmeasinstr_b.
function editmeasinstr_b_Callback(hObject, eventdata, handles)
% hObject    handle to editmeasinstr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of editmeasinstr_b


% --- Executes on button press in saveIall_b.
function saveIall_b_Callback(hObject, eventdata, handles)
global type selected delK
% hObject    handle to saveIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName] = uiputfile('*.mat','Select the Fit file',[cd,'/3. fit_data/']);
load([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')

load([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
filq=exist( [PathName,FileName]);
if filq~=0
load([PathName,FileName],'fita')
sizfit=length(fita);
else
    dotsq=find(FileName=='.');
    if isempty(dotsq)==0
        FileName=FileName(1:dotsq-1);
        
    end
    FileName=[FileName,'_Iall'];
    sizfit=0;
    val_old=1;
    fita=[];
end

for n=1:length(fita)
noms=fita(1,n).name;
ifind=strcmp(noms,identa);
val_old=sizfit+1;
if ifind~=0
    val_old=n;
    
    break
end
end


    
fita(1,val_old).I_all=I_all;
fita(1,val_old).delK=delK;
fita(1,val_old).type=type;
fita(1,val_old).selected=selected;
if size(identa)~=0
    fita(1,val_old).name=identa;
else
    identa=input('Enter name:     ','s');
    fita(1,val_old).name=identa;
end

val=input('Enter a numerical value? \n');
fita(1,val_old).val=val;
save([PathName,FileName],'fita')

% --- Executes on button press in loadIall_b.
function loadIall_b_Callback(hObject, eventdata, handles)
global type selected delK
% hObject    handle to loadIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName,PathName] = uigetfile('*.mat','Select the Intensity Fit file',[cd,'/3. fit_data/00.fitdata/']);
load([cd,'/0. variables/genset.mat'])
load([PathName,FileName],'fita')
% load(['/Applications/MATLAB74/work/4. Steel Fit/3. fit_data','/','steelnew','_I_all'],'fita')
 sizfit=length(fita);
for n=1:length(fita)
noms{n}=fita(1,n).name;
end

val_old=menu('Select Intensity values to load',noms);

I_all=fita(1,val_old).I_all;

if isfield(fita,'delK')==1
    delK_=fita(1,val_old).delK;
    if size(delK_,1)==0
        delK
    end
else 
    delK
end
% type=fita(1,val_old).type;
selected=fita(1,val_old).selected;

identa=fita(1,val_old).name;
set(handles.sampleid_t,'string',identa)
save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
save([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')
set(handles.delK_t,'string',delK)
function autobcgno_t_Callback(hObject, eventdata, handles)
% hObject    handle to autobcgno_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of autobcgno_t as text
%        str2double(get(hObject,'String')) returns contents of autobcgno_t as a double


% --- Executes during object creation, after setting all properties.
function autobcgno_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to autobcgno_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton29.
function pushbutton29_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sampleid_t_Callback(hObject, eventdata, handles)
% hObject    handle to sampleid_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampleid_t as text
%        str2double(get(hObject,'String')) returns contents of sampleid_t as a double


% --- Executes during object creation, after setting all properties.
function sampleid_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampleid_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton8



function apc_t_Callback(hObject, eventdata, handles)
% hObject    handle to apc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of apc_t as text
%        str2double(get(hObject,'String')) returns contents of apc_t as a double


% --- Executes during object creation, after setting all properties.
function apc_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to apc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function capc_t_Callback(hObject, eventdata, handles)
% hObject    handle to capc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of capc_t as text
%        str2double(get(hObject,'String')) returns contents of capc_t as a double


% --- Executes during object creation, after setting all properties.
function capc_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to capc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function cpc_t_Callback(hObject, eventdata, handles)
% hObject    handle to cpc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cpc_t as text
%        str2double(get(hObject,'String')) returns contents of cpc_t as a double


% --- Executes during object creation, after setting all properties.
function cpc_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cpc_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in hexss_b.
function hexss_b_Callback(hObject, eventdata, handles)
global indiv_comb 
% hObject    handle to hexss_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str{1}= 'Edge Basal <a>:   ';
str{2}= 'Edge Prism <a>:   ';
str{3}='Edge Prism <c>:   ';
str{4}='Edge Prism<c+a>:   ';
str{5}= 'Edge Pyramidal {1011} <a>:   ';
str{6}='Edge Pyramidal {2112} <c+a>:   ';
str{7}='Edge Pyramidal {1121} <c+a>:   ';
str{8}='Edge Pyramidal {1011} <c+a>:   ';
str{9}='Screw <a>:   ';
str{10}='Screw <c+a>:   ';
str{11}='Screw <c>:   ';
for n=1:11
    pc=[];
    pc=num2str(indiv_comb(n));
    X=length(pc);if X>4;pc=pc(1:4);X=4;end
    str{n}(end+1:end+X)=pc;
end
menu('Slip system %s',str);


% --- Executes on selection change in resallplot_l.
function resallplot_l_Callback(hObject, eventdata, handles)
global FileName PathName %dsettings rho val gs id
% hObject    handle to resallplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns resallplot_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from resallplot_l
load([cd, '/0. variables/phases.mat'])

filter_=0;
load([PathName,FileName])
q=[];gs=[];rho=[];M=[];PF=[];val=[];typeSS=[];
for n=1:length(FCres_set)
    q(n)=FCres_set(1,n).FCres(1);
    gs(n)=FCres_set(1,n).FCres(2);
    rho(n)=FCres_set(1,n).FCres(3);
    M(n)=FCres_set(1,n).FCres(4);
    PF(n)=FCres_set(1,n).FCres(5);
    val(n)=FCres_set(1,n).val(1);
    typeSS(n)=FCres_set(1,n).type(6);
    id{n}=FCres_set(1,n).identa;
    selected{n}=FCres_set(1,n).selected;
    if n>1
        selVAL(n)=n;
        for nmn=1:n-1
            if size(selected{n})==size(selected{nmn})
                if selected{n}==selected{nmn}
                    selVAL(n)=nmn;
                    break
                end
            end
        end
         
    else
        selVAL(n)=1;        
    end
%     gss(n)=FCres_set(1,n).gs;
end


col={'ok';'bs';'<g';'>m';'^y';'r+'};
 hexcubq=str2double( dsettings(1,1).cstruct(1) );
if hexcubq==4;
    
    for n=1:length(PF)
        [indiv_comb Burgcomb]=contrast(q(n) ,PF(n),1);
        bb(n,:)=Burgcomb(1:3);
    end
    
    q=[q;PF];
    PF=[];PF=bb;
end

comportens=get(handles.comportens_l,'value');
val_C=-100*log(1-val/100);
val_T=100*log(1+val/100);
% switch comportens
%     case 1
%     case 2 %tens
%         val=val_T;
%     case 3 %comp
%         val=val_C;
%     case 4 %both
%         valmid=40;%input('Enter value that above this data is rolled:  ');
%         pos_hi=find(val>=valmid);%compression
%         pos_lo=find(val<valmid);%tension
%         val(pos_lo)=val_T(pos_lo);
%         val(pos_hi)=val_C(pos_hi);
% end
        

% val=val+180;
if typeSS(1)~=3
    sel=get(handles.resallnom_l,'value')
    choice=get(handles.resallplot_l,'Value')
    if get(handles.RESALL_fig_b,'value')==1
%         figure(1)
%         close
        figure(1)
        mbhj=0;
    else
        mbhj=1;
    end
    
    figure(2)
     if ishold~=1;hold;end
     
    switch choice
        case 2
            plot(val,q,'.r','Markersize',10,'linewidth',3),hold
            for bnm=1:length(selVAL)
            plot(val(bnm),q(bnm),col{selVAL(bnm)},'Markersize',10,'linewidth',3),
            end
            if mbhj==1
                
                plot(val(sel),q(:,sel),'sg','Markersize',12)
            end
            title('The change in the parameter q','fontsize',18)
            xlabel('Srain %','fontsize',16)
            ylabel('q','fontsize',16)
            set(gca,'Fontsize',18)
            grid
    %         gs100=find(gss==100);
    %         plot(val(gs100),q(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),q(gs30),'sb','Markersize',8)
        case 3
            vall=[val',gs'];
            vall=sortrows(vall);
            

            if filter_==1
                for n=2:length(vall)-1
                    vall_(n-1,1)=mean( vall(n-1:n+1,1) );
                    vall_(n-1,2)=mean( vall(n-1:n+1,2) );
                end
%                 vall_=vall;
                val=vall_(:,1);
                gs=vall_(:,2);
            end
            if ishold~=1;hold;end
            plot(val,gs,'sr','Markersize',10,'linewidth',3)
%             for bnm=1:length(val)
%                 
%             plot(val(bnm),gs(bnm),col{1},'Markersize',10,'linewidth',3),
%             end
            
%             if mbhj==1
%                 
%                 plot(val(sel),gs(sel),'+g','Markersize',10,'linewidth',3)
%             end
            title('Grain Size','fontsize',18)
            xlabel('Srain %','fontsize',17)
            ylabel('Grain size Armstrongs','fontsize',17)
            set(gca,'Fontsize',18)
            xlim([min(val)- abs(min(val)*.1), max(val)+abs(max(val)*.1)])
            grid
%             xlim([0 max(val)*1.3])
%             ylim([min(gs)*.5 max(gs)*1.5])
    %         gs100=find(gss==100);
    %         plot(val(gs100),gs(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),gs(gs30),'sb','Markersize',8)
        case 4
%             rho=rho*.85*  .2/.32;%*.69;%*0.5*(0.69+1);
%             rho=rho*1.2918;
            if hexcubq==4
                
%             for n=1:length(rho); 
%                 [indiv_comb(:,n) Burgcomb(n,:)]=contrast(q(1,n) ,q(2,n),1);end
%             rho=rho.*Burgcomb(:,4)';
            end
%             val=-100*log(1-val/100);


if filter_==1
            vall=[val',rho'];
            vall=sortrows(vall);
            for n=2:length(gs)-1
                vall_(n-1,1)=mean( vall(n-1:n+1,1) );
                vall_(n-1,2)=mean( vall(n-1:n+1,2) );
            end
            val=vall_(:,1);
            rho=vall_(:,2);
end
            
            for n=1:length(val)
                if val(n)>0; %rho(n)=rho(n)/1.75;
                end
            end
            if ishold~=1;hold;end
            plot(val,rho,'sr','Markersize',10,'linewidth',3),
%             for bnm=1:length(val)
%             plot(val(bnm),rho(bnm),col{1},'Markersize',10,'linewidth',3),
%             end
            
            
%             if mbhj==1
%             
%             plot(val(sel),rho(sel),'+g','Markersize',10,'linewidth',4)
%             end
            grid
            title('Dislocation Density ','fontsize',18)
            xlabel('Srain %','fontsize',17)
            ylabel('Dislocation density (10^1^6 m^-^2)','fontsize',17)
            set(gca,'Fontsize',18)
            xlim([min(val)- abs(min(val)*.1), max(val)+abs(max(val)*.1)])
    %         gs100=find(gss==100);
    %         plot(val(gs100),rho(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),rho(gs30),'sb','Markersize',8)
        case 5
            M=M*(.2/.32)^.5;
            
            if filter_==1
            vall=[val',M'];
            vall=sortrows(vall);
            for n=2:length(gs)-1
                vall_(n-1,1)=mean( vall(n-1:n+1,1) );
                vall_(n-1,2)=mean( vall(n-1:n+1,2) );
            end
            val=vall_(:,1);
            M=vall_(:,2);
            end
            
            plot(val,M,'sr','Markersize',10,'linewidth',3),
%             for bnm=1:length(val)
%             plot(val(bnm),M(bnm),col{selVAL(bnm)},'Markersize',10,'linewidth',3),
%             end
            
%             if mbhj==1
%             
%             plot(val(sel),M(sel),'+g','Markersize',10,'linewidth',4)
%             end
            title('Dipole character M','fontsize',18)
            xlabel('Srain %','fontsize',16)
            ylabel('Dipole character M','fontsize',16)
            set(gca,'Fontsize',18)
            if max(M)>10
            ylim([0 10])
            end
            grid
    %         gs100=find(gss==100);
    %         plot(val(gs100),M(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),M(gs30),'sb','Markersize',8)
        case 6
            plot(val,PF,'o','Markersize',12,'linewidth',4),
            if mbhj==1
            hold
            plot(val(sel),PF(sel,:),'.k','Markersize',15)
            end
            title('Planar Fault %','fontsize',14)
            grid
    %         gs100=find(gss==100);
    %         plot(val(gs100),PF(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),PF(gs30),'sb','Markersize',8)
        case 7
%             rho=rho*0.2/0.32;
            Re=M./rho.^.5;
            rho2=rho*1e16%*   .2/.32;
            gs2=gs*1e-10;%(.2/.316)
            
            if filter_==1
            vall=[val',Re'];
            vall=sortrows(vall);
            for n=2:length(gs)-1
                vall_(n-1,1)=mean( vall(n-1:n+1,1) );
                vall_(n-1,2)=mean( vall(n-1:n+1,2) );
            end
            val=vall_(:,1);
            Re=vall_(:,2);
            end
            
            
            l=rho2.^(-0.5)*1e6;lambda=gs2*1e6;
            plot(val,Re,'+k','Markersize',10,'linewidth',4),ylim([0 1.3*max(Re)])
            xlabel('Strain (%)'),ylabel('Re')
            grid
            
            
            
            
%             plot(l,lambda,'+k','Markersize',10,'linewidth',4),hold
%              plot(l(sel),lambda(sel),'.g','Markersize',15,'linewidth',4)
%              plot(Re/200,lambda,'xr','Markersize',10,'linewidth',4)
%             plot(val(sel),Re(sel),'sg','Markersize',8)
%             title('Dipole character M','fontsize',18)
%             xlabel('Srain %','fontsize',16)
%             ylabel('Dipole character M','fontsize',16)
% xlabel('(dislocation density)^-^0^.^5','fontsize',17)
% ylabel('domain size','fontsize',17)

maxl=max(l);
if maxl>1e3;maxl=.1;end
x=0:0.001:maxl;
y=x;
% plot(x,y,'k')
% y=3*x;
% plot(x,y,'b')
            set(gca,'Fontsize',18)
    end
    
else
    gs=gs/1e10;
    if hexcubq==4
        q=q(1,:).*rho;
    else
        q=q.*rho;
    end
    
    sel=get(handles.resallnom_l,'value');
    choice=get(handles.resallplot_l,'Value');
    if ishold==1;hold;end
    switch choice
        case 2
            semilogy(val,q,'.k','Markersize',25),
            if mbhj==1
            hold
            plot(val(sel),q(sel),'sg','Markersize',12)
            end
            title('The change in the parameter wr the width of the component strain fields','fontsize',18)
            xlabel('Srain %','fontsize',16)
            ylabel('Width of the component strain fields','fontsize',16)
            set(gca,'Fontsize',18)
    %         gs100=find(gss==100);
    %         plot(val(gs100),q(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),q(gs30),'sb','Markersize',8)
        case 3
            semilogy(val,gs,'.k','Markersize',25),
            if mbhj==1
            hold
            plot(val(sel),gs(sel),'sg','Markersize',8)
            end
            title('Mean Square strain','fontsize',18)
            xlabel('Srain %','fontsize',16)
            ylabel('Mean square strain','fontsize',16)
            set(gca,'Fontsize',18)
    %         gs100=find(gss==100);
    %         plot(val(gs100),gs(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),gs(gs30),'sb','Markersize',8)
        case 4
            
            plot(val,rho,'.k','Markersize',25),
            if mbhj==1
            hold
            plot(val(sel),rho(sel),'sg','Markersize',8)
            end
            title(' Distance between defects','fontsize',18)
            xlabel('strain %','fontsize',16)
            ylabel('Distance between defects Am','fontsize',16)
            set(gca,'Fontsize',18)
    %         gs100=find(gss==100);
    %         plot(val(gs100),rho(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),rho(gs30),'sb','Markersize',8)
        case 5
            plot(val,M,'.k','Markersize',25),
            if mbhj==1
            hold
            plot(val(sel),M(sel),'sg','Markersize',8)
            end
            title('Dipole character M','fontsize',18)
            xlabel('Srain %','fontsize',16)
            ylabel('Dipole character M','fontsize',16)
            set(gca,'Fontsize',18)
    %         gs100=find(gss==100);
    %         plot(val(gs100),M(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),M(gs30),'sb','Markersize',8)
        case 6
            plot(val,PF,'ok','Markersize',8),
            if mbhj==1
            hold
            plot(val(sel),PF(sel),'sg','Markersize',8)
            end
            title('Planar Fault %','fontsize',14)
    %         gs100=find(gss==100);
    %         plot(val(gs100),PF(gs100),'sr','Markersize',8)
    %         gs30=find(gss==30);
    %         plot(val(gs30),PF(gs30),'sb','Markersize',8)
    end
end

    
% --- Executes during object creation, after setting all properties.
function resallplot_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resallplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in resallnom_l.
function resallnom_l_Callback(hObject, eventdata, handles)
global PathName FileName 
% hObject    handle to resallnom_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns resallnom_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from resallnom_l
load([PathName,FileName])
val=get(handles.resallnom_l,'value');
FCres=FCres_set(1,val).FCres;
type=FCres_set(1,val).type;
selected=FCres_set(1,val).selected;
set(handles.q_t,'string',num2str(FCres(1)) )
set(handles.gs_t,'string',num2str(1e-4*FCres(2)) )
set(handles.rho_t,'string',num2str(FCres(3)) )
set(handles.M_t,'string',num2str(FCres(4)) )
resallplot_l_Callback(hObject, eventdata, handles)

switch type(5)
    case 0
        set(handles.allindiv_t,'string','INDIV FCs')
    case 1
        set(handles.allindiv_t,'string','ALL FCs')
end

sizestrain=get(handles.sizestrain_l,'string');
set(handles.sizestrain_t,'string',sizestrain{type(6)+1});

if type(6)==3
    set(handles.boxlabel_p,'visible','on');
        set(handles.boxlabelsf_p,'visible','off');
else
    set(handles.boxlabel_p,'visible','on');
    set(handles.boxlabelsf_p,'visible','off');
end
set(handles.selectedpks_t,'string',num2str(selected));



% --- Executes during object creation, after setting all properties.
function resallnom_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resallnom_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function allindiv_t_Callback(hObject, eventdata, handles)
% hObject    handle to allindiv_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of allindiv_t as text
%        str2double(get(hObject,'String')) returns contents of allindiv_t as a double


% --- Executes during object creation, after setting all properties.
function allindiv_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to allindiv_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sizestrain_t_Callback(hObject, eventdata, handles)
% hObject    handle to sizestrain_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sizestrain_t as text
%        str2double(get(hObject,'String')) returns contents of sizestrain_t as a double


% --- Executes during object creation, after setting all properties.
function sizestrain_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizestrain_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function selectedpks_t_Callback(hObject, eventdata, handles)
% hObject    handle to selectedpks_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of selectedpks_t as text
%        str2double(get(hObject,'String')) returns contents of selectedpks_t as a double


% --- Executes during object creation, after setting all properties.
function selectedpks_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectedpks_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadfit_b.
function loadfit_b_Callback(hObject, eventdata, handles)
global dsettings aa aabcg aa_I aabcg_I data data_I selected I_all FCres delK 
% hObject    handle to loadfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delK=0.025;
selected=[1 6];
[file path] = uigetfile('','Select File containing batch data',[cd,'/2. data/hrpd/1.hrpd batch']);
load([cd,'/0. variables/phases.mat'],'dsettings')
load([path,file]);
for n=1:length(fita)
    nom{n}=fita(n).name;
end

filnom=menu('Select File',nom);
filnomI=menu('Select Instrumental File',nom);

for ggg=1:filnomI-1
    filenom=ggg;
    data=fita(filnom).data;
    aa=fita(filnom).aa;
    aabcg=fita(filnom).aabcg;
    data_I=fita(filnomI).data;
    aa_I=fita(filnomI).aa;
    aabcg_I=fita(filnomI).aabcg;
    % incre=5e-06;
    sample_n=str2num( get(handles.sample_n_t,'string') )
    for n=1:length(data)
        data(n,:)=data(n,:)+rand(1,2)*1e-5;
    end
    for n=1:length(data_I)
        data_I(n,:)=data_I(n,:)+rand(1,2)*1e-5;
    end
    data=tsinterpl_hrpd(data,1);data_I=tsinterpl_hrpd(data_I,1);
    load([cd,'/0. variables/phases.mat'],'dsettings')
    view_b_Callback(hObject, eventdata, handles)

    for n=1:length(selected)
            I_all=bcgmin(sample_n, selected(n), I_all);
    end

    getFC_b_Callback(hObject, eventdata, handles)
    fitFC_b_Callback(hObject, eventdata, handles)
    
    FCRESALL(ggg,:)=FCres;
    valall(ggg)=fita(ggg).val;
    n
end
save('FCALL_200','FCRESALL','valall')


% --- Executes on button press in nextpk_b.
function nextpk_b_Callback(hObject, eventdata, handles)
% hObject    handle to nextpk_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


indexs=get(handles.index_l,'string');
indexval=get(handles.index_l,'value');
if indexval<size(indexs,1)
    indexval=indexval+1;
end
set(handles.index_l,'value',indexval)
plotraw_b_Callback(hObject, eventdata, handles)


% --- Executes on button press in RESALL_fig_b.
function RESALL_fig_b_Callback(hObject, eventdata, handles)
% hObject    handle to RESALL_fig_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of RESALL_fig_b


% --- Executes on button press in pushbutton33.
function pushbutton33_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in sizehook_b.
function sizehook_b_Callback(hObject, eventdata, handles)
% hObject    handle to sizehook_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in comportens_l.
function comportens_l_Callback(hObject, eventdata, handles)
% hObject    handle to comportens_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns comportens_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from comportens_l


% --- Executes during object creation, after setting all properties.
function comportens_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to comportens_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Tibatch_b.
function Tibatch_b_Callback(hObject, eventdata, handles)
% hObject    handle to Tibatch_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selected delK
%first peaks are loaded manually
%select peaks


[FileName_,PathName_] = uiputfile('*.mat','Select the Intensity I_all file: ');
mkl=1;
while mkl==1

    
    load([cd,'/0. variables/genset.mat'])
    load([PathName_,FileName_],'fita')
    sizfit=length(fita);
    for n=1:length(fita);noms{n}=fita(1,n).name;end
        LENJ=length(fita);
        noms{LENJ+1}='FINISH';
        val_old=menu('Select Intensity values to load',noms);
        if val_old==LENJ+1
            break;break
        else
            I_all=fita(1,val_old).I_all;

            if isfield(fita,'delK')==1
                delK_=fita(1,val_old).delK;
                if size(delK_,1)==0
                    delK
                end
            else 
                delK
            end
            selected=fita(1,val_old).selected;
            identa=fita(1,val_old).name;
            set(handles.sampleid_t,'string',identa)
            save([cd,'/0. variables/FC_Iall.mat'],'I_all','delK')
            save([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')
            set(handles.delK_t,'string',delK)
          
        end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     select_={[1     5     7    14    20];%5X
%      [1     7    20];%3X
%      [1 7];%2X
%      [2 10];%002
%      [3 11];};%111
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    select_={1:1:6; 1:1:8; 1:1:10; 1:1:12; 1:1:14; 1:1:16; 1:1:18; 1:1:20};
            
 

    [FileName,PathName] = uiputfile('*.mat','Select the Fit_Results file: Each option for this intensity is saved there; cancel for same one');

    if max(size(FileName))<2

        FileName=get(handles.batch_t,'string');
        PathName=get(handles.batch2_t,'string');
    end

    if strcmp(FileName(end-3:end),'.mat')~=1
        FileName=[FileName,'.mat'];
    end
    set(handles.batch_t,'string',FileName)
    set(handles.batch2_t,'string',PathName)
    set(handles.batchON_b,'value',1);

    if exist( [PathName,FileName])==0
    save( [PathName,FileName],'select_')
    a='dont exist'
    end

    for msele=1:length(select_)
        msele_loop=1;
        while msele_loop==1
            selected=select_{msele};%select peaks
            
%             menu('Select sample n- number of FCs','ok')  
            
            getFC_b_Callback(hObject, eventdata, handles)%get FCs

%             fitFCall_b_Callback(hObject, eventdata, handles)%fit
            fitFC_b_Callback(hObject, eventdata, handles)%fit

            set(handles.plotres_l,'value',8)
            plotres_l_Callback(hObject, eventdata, handles)%plot K-W plot
            msele_loop=menu('is this ok?','no','yes','if no change range in dsettings etc');
        end
        save_b_Callback(hObject, eventdata, handles)

    end
end
set(handles.batchON_b,'value',0);

function batch_t_Callback(hObject, eventdata, handles)
% hObject    handle to batch_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of batch_t as text
%        str2double(get(hObject,'String')) returns contents of batch_t as a double


% --- Executes during object creation, after setting all properties.
function batch_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to batch_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function batch2_t_Callback(hObject, eventdata, handles)
% hObject    handle to batch2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of batch2_t as text
%        str2double(get(hObject,'String')) returns contents of batch2_t as a double


% --- Executes during object creation, after setting all properties.
function batch2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to batch2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in batchON_b.
function batchON_b_Callback(hObject, eventdata, handles)
% hObject    handle to batchON_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of batchON_b


% --- Executes on button press in AllszFC_b.
function AllszFC_b_Callback(hObject, eventdata, handles)
global FileName PathName %dsettings rho val gs id
% hObject    handle to AllszFC_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pk=get(handles.resallnom_l,'value');
str_=get(handles.resallnom_l,'string');
str=str_{pk};
load([PathName,FileName])
nmax=str2double( get(handles.sample_n_t,'string') );
all_I=FCres_set(pk).all_I;

L=0:1:length( all_I(:,2) )-1;
a3=FCres_set(pk).FCres(end);
L=L*a3;
if ishold==1;hold;end
plot(L, exp( all_I(:,2) ) ,'ok'),
hold
plot(L,exp(-L/FCres_set(pk).FCres(2) )) ;
xlim([0 nmax*a3*1.3])
title(str)
ylim([0 3])
