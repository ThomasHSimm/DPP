function [f ]=pk_voigt2asymm(x,lam);
% f= pk_voigt(x,lam)
% actual function to calculate single voigt peak
% 5-2-94 SMB (Bren@SLAC.stanford.edu)
f=zeros(size(x));
delx=x-lam(1);
x1=delx(find(delx<0));
x2=delx(find(delx>=0));

%%%     3 is fw right of peak

% lam(6)=lam(4);
% lam(2)=1;
if length(lam)==4; lam(5)=lam(3);lam(6)=lam(4);  end
    delx=x1;
    gau= exp(-(x1 ./(0.600561*lam(5))).^2);
    lor= 1+ (x1 ./(0.5*lam(5))).^2;
    delx=x2;
    gau2= exp(-(x2 ./(0.600561*lam(3))).^2);
    lor2= 1+ (x2 ./(0.5*lam(3))).^2;
    
    f= f+ [lam(2) .*((lam(4)./lor)+((1-lam(4)).*gau));    lam(2) .*((lam(6)./lor2)+((1-lam(6)).*gau2))] ;

    
    
    
    


%%%lam(1) ==x0
%%%lam(2) ==PHI0  intensity
%%%lam(3) ==FWHM
%%%lam(4) ==neta (0->1 gauss->lorentz)
%%%%f intensity
%%%%x twotheta values

% iff=real(fft(f,10000))/max(fft(f,10000));
% plot(iff,'--go')




end