function tsfourier_plot(plotval,nmax)

global   FCres    selected type g Burgcomb
load([cd,'/0. variables/phases.mat'],'dsettings')
g=[];
load([cd,'/0. variables/FC.mat'],'FC')
load([cd,'/0. variables/all_I.mat'],'all_I')
if size(all_I,1)~=0
L=0:1:length( all_I(:,2) )-1;
a3=FCres(end);
L=L*a3;
end

for n=1:length(selected)
        g(n)=1./dsettings(1,1).d(selected(n));
end

hexcubq=str2double( dsettings(1,1).cstruct(1) );
if hexcubq==4 && type(6)~=3; %%is hex
    hexcub=0;
    l=dsettings(1,1).index(selected,3)';
    x=(2/3)*((l./(g*0.295*10)).^2);
    C=(1+FCres(1)*x + FCres(5)*x.^2)  ;
    C=Burgcomb(4)*C;
  
        TQ=4;%menu('Taylor?','Ax','trans','C=0.5','NO','intergranular');
        
        if TQ<3 || TQ==5
        load('Taylor_C_ti','newC_ax','newC_tran')
            if TQ==1
                    C=newC_ax(selected);
                    interq=1-1;
            elseif TQ==5
                C=newC_tran(selected)*0+1;
                interq=1;
            elseif TQ==3
                C=0.5;
                interq=0;
            elseif TQ==2
                C=newC_tran(selected)
                interq=0;
            else
                
            interq=0;
            end
        
            interq=0;
        else
            interq=0;
        end
%     end
    B=pi/2;
else %cubic
    hexcub=1;
    H2=Hsq(dsettings(1,1).index(selected,:));
    C=0.2*(1-FCres(1)*H2);
    lat=0.35675*10;%for nickel 
    B=0.5*pi*(lat/2^0.5)^2;
end

% figure(14),if ishold==1hold;end
if type(6)==2
    L=0:1:length(all_I)-1;L=L*a3;
                for n=1:length(g)
                    Li(:,n)=L*g(1)./g(n);
                end
                
                
                allI(:,2)=-(all_I(:,3));
                allI(:,1)=(all_I(:,2));
                for n=1:length(selected)
                    Li(:,n)=L*g(n)./g(1);
                end
                
                A=FC(:,selected);
%                 plot(Li,A ,'o'),hold
%                 lat=0.35675*10;%for nickel 
%                 B=0.5*pi*(lat/2^0.5)^2;C=0.3*(1-2.3*H2);C=C(1);
                for n=1:length(allI)
                lnA(n,:)=logalt(allI(n,:),g);
                end
                
                
            a3_new=a3/2;
            Linterp=0:a3_new:500;
            A=FC(:,selected);
            for n=1:length(selected)
                Anew(:,n) = interp1(Li(:,n),A(:,n),Linterp)';
            end
end
        
% a3=0.5/delK;

%% which plot selected
% 1=FCs-3=FC_log-4=FC_Wilk-5=WAplot-6=SizeFC-7=StrainFC-8=KrivWilk-9=Intsty

plotval
switch plotval
    case 2
        type6=type(6);
        switch type6
            case 0%%log WA
                
                switch hexcub
                    case 0
                        lnA=allF_hex(all_I,L);
                        if interq==1
                            lnA=allF_inter(FCres, L);
                        end
                        plot(L,exp(lnA))
                    case 1
                        lnA=allF_tsf(all_I,L);
                        OUT=[];for n=2:length(all_I);OUT(n,:)=indivF(all_I(n,:));end
                        plot(L,exp(lnA))
                end
                title('Fourier Coefficiients Using fit of different n values --log WA method','fontsize',15)
                xlabel('Fourier length L','fontsize',15)
            case 1
                
                lnA=( allF_lin(all_I, L) );
                plot(L,exp(lnA))
                
                title('Fourier Coefficients Using fit of different n values --linear WA method','fontsize',15)
                xlabel('Fourier length L','fontsize',15)
                
            case 2
                
                if ishold==1;hold;end
                
                plot(Li,A ,'o'),hold
                
                plot(L,exp(lnA))
                title('Fourier Coefficiients Using fit of different n values --Alt method','fontsize',15)
                xlabel('Fourier length Li (L*g)','fontsize',15)
            case 3
                
                FCres0=FCres;
                FCres0(2)=FCres(2)/(1e6*1e4);
                AA=strainfield_fit(FCres0,L);
                plot(L,AA,'-')
                
                title('Fourier Coefficiients Using fit of different n values --Strain field method','fontsize',15)
                xlabel('Fourier length L','fontsize',15)
        end
        legend(num2str(dsettings(1,1).index(selected,:)));
        
        ylabel('Fourier Coefficiients','fontsize',15)
        
        
        xlim([0 nmax*a3*1.3])
        ylim([0 1])
        
    case 3
        
        IN=FCres(1:4);
        IN(3)=FCres(3)/(1e20*1e-16);
        
        lnA=allF_log(IN,L);
        plot(L,exp(lnA))
        ylim([0 1.1])
        legend(num2str(dsettings(1,1).index(selected,:)));
        title('Fourier Coefficiients LOG TERM Using fit values','fontsize',15)
        ylabel('Fourier Coefficiients','fontsize',15)
        xlabel('Fourier length L','fontsize',15)
        xlim([0 nmax*a3*1.3])
        
    case 4
        
        IN=FCres(1:5);
        IN(3)=FCres(3)/(1e20*1e-16);
        
        if type(6)==0
%             lnA=allF_Wilk(IN,L);
            if hexcub==0
                IN(6)=FCres(6);
                IN(7)=1;
                lnA=log(allF_together_FC_lognorm(IN,L));
                %swap below with commented below it when done
                        if size(lnA,2)>1
                        col={'-';'--';':';'-.';'-'};
                        for mkl=1:size(lnA,2)
                            mkl
                            plot(L,exp(lnA(:,mkl)),col{mkl},'markersize',10,'linewidth',3)
                        end
                        else

                        end
        
%                 plot(L,exp(lnA),'linewidth',3)
                IN(7)=0;
                lnA=log(allF_together_FC_lognorm(IN,L));%plots size
            else
                lnA=log(allF_together_FC_lognorm(IN,L));
            end
        elseif type(6)==1
            if hexcub==0
            IN(6)=FCres(6);
            IN(7)=1;
            end
            lnA=log(allF_together_FC_lognorm_lin(IN,L));
        end
        
        
        plot(L,exp(lnA))


        ylim([0 1.1])
        legend(num2str(dsettings(1,1).index(selected,:)));
        title('Fourier Coefficiients WILKENS TERM Using fit values','fontsize',15)
        ylabel('Fourier Coefficiients','fontsize',15)
        xlabel('Fourier length L','fontsize',15)
        xlim([0 nmax*a3*1.3])
        grid
    case 5
%         figure(3)
        if ishold==1;hold;end
        col=['ok';'sk';'<k';'>k';'^k';'pk';'ob';'sb';'<b';'>b';'^b';'pb'];
        
        if  type(6)==2
            if ishold==1;hold;end
            
            for nn=1:length(selected)                    
                plot(1./g(nn),log( Anew(1,nn) ),col(nn,:)),if nn==1;hold;end
            end
            for nn=1:length(selected)    
                plot(1/g(nn),log( Anew(:,nn) ),col(nn,:)),
            end
            for n=1:nmax
                plot(1./g,lnA(n,:),'m')
            end
            titstr{1,1}='Alternative plot, Increasing Fourier length downwards';
            titstr{1,2}='log(size Fourier coeffs)-->gradient  && log(strain FCs)-->intercept';
            title(titstr,'fontsize',15)
            ylabel('log of Fourier Coefficiients','fontsize',15)
            xlabel('1/g','fontsize',15)
            legend(num2str(dsettings(1,1).index(selected,:)),'Location','SouthWest');
            
        elseif type(6)==3
                L=L(1:15);
                nmax=15;
        nn=1;
        if ishold==1;hold;end
        col=['xk';'+k'];
                for nn=1:length(selected)  
                
                n=selected(nn);
                plot(g(nn).^2,log( FC(1,n) ),col(nn,:),'markersize',13,'linewidth',1.5),
                if nn==1;hold;end
                end
                
                for nn=1:length(selected)    
                    n=selected(nn);      
                    plot(g(nn).^2,log( FC(1:length(L),n) ),col(nn,:),'markersize',13,'linewidth',1.5),
                end
                FCres0=FCres;
                FCres0(2)=FCres(2)/(1e6*1e4);
                g=0:max(g)/(5):max(g)+max(g)/(5);
                AA=strainfield_fit(FCres0,L);
                
                
                for n=1:nmax
                    plot(g.^2,log(AA(n,:)),'k:','linewidth',1.2)
                end
                clear global g
                
                legend(num2str(dsettings(1,1).index(selected,:)));
                title('Warren-Averbach plot, Increasing Fourier length downwards','fontsize',17)
                ylabel('log of Fourier Coefficiients','fontsize',17)
                xlabel('g(=1/d)-sq (Armstrong metres^-^1','fontsize',17)
                legend(num2str(dsettings(1,1).index(selected,:)),'Location','SouthWest');
                
        else
            nnf=1;
            
            FCvals=1:1:15;
            L(FCvals)
            FC=FC(FCvals,:);
            for nn=1:length(selected)    
                n=selected(nn);
                if nn>length(col);nnf=1;end
                plot(C(nn)*g(nn).^2,log( FC(1,n) ),col(nnf,:),'markersize',10,'linewidth',3),if nn==1;hold;end
                nnf=nnf+1;
            end
            nnf=1;
            for nn=1:length(selected)    
                if nn>length(col);nnf=1;end
                n=selected(nn);      
                plot(C(nn)*g(nn).^2,log( FC(:,n) ),col(nnf,:),'markersize',10,'linewidth',3),%1:length(L)
                nnf=nnf+1;
            end

            lnAA =allF_tsf(all_I, L);
            lnAA=lnAA(FCvals,:);
%             colr={'k','b','r','g','c','y','m','k','b','r','g','c','y','m','k','b','r','g','c','y','m'};
            for n=1:length(lnAA)
                plot(C.*g.^2,lnAA(n,:),'k','markersize',10,'linewidth',3)
            end

            title('Warren-Averbach plot, Increasing Fourier length downwards','fontsize',15)
            ylabel('log of Fourier Coefficiients','fontsize',17)
            xlabel('g(=1/d)-sq','fontsize',17)
            legend(num2str(dsettings(1,1).index(selected,:)),'Location','WestOutside');
            set(gca,'fontsize',17)
        end
    case 6
        hexcub=str2num( dsettings(1,1).cstruct(1) );
        plot(L, exp( all_I(:,2) ) ,'ok'),hold
%         plot(L, exp(-L/FCres(2) ) )
        var=FCres(5);
        if hexcub==4;
            plot(L,exp(-L/FCres(2) )) ;
        else
%         plot(L,ASlognormSc([FCres(2),var],L) )
            plot(L,exp(-L/FCres(2) )) ;
        end
        
        title('Size Fourier Coefficients','fontsize',15)
        ylabel('Size Fourier Coefficiients','fontsize',15)
        xlabel('Fourier length L','fontsize',15)
        ylim([0 1.2])
        xlim([0 nmax*a3*1.3])
    case 7
        
        plot(L.^2, exp(- all_I(:,3) ) ,'ok'),hold
        Re=FCres(4)/ ( FCres(3) * 1e-4 )^.5;
        XL_check=FCres(3)*1e-4*log( Re./L ) ;XL_check(1)=1;
        XL_check2=Wilkens3( [Re,FCres(3)*1e-04],L ) ;XL_check2(1)=1;
        plot(L.^2,exp(-XL_check.*L.^2),'g')
        plot(L.^2,exp(-XL_check2.*L.^2'),'r')
        plot(L.^2,exp(-g(5)^2*XL_check2.*L.^2'),'r')
        
%         ylim([0 1])
        legend('raw data','log','Wilkens','Location','NorthEast')
        
        title('Strain Fourier Coefficients','fontsize',15)
        ylabel('Strain Fourier Coefficiients','fontsize',15)
        xlabel('Fourier length L','fontsize',15)
%         xlim([0 800])
%         ylim([0 1])
%         if max(exp(- all_I(:,3) ))>1
%             ylim([0 1.1])
%             if max(exp(- all_I(:,3) ))>1.2
%             ylim([0 1.5])
%             end
%         end
        
    case 8
        XL_m=( all_I(:,3) )./L.^2';
        Re=FCres(4)/ ( FCres(3) * 1e-4 )^.5;
        XL_check=FCres(3)*1e-4*log(Re./L ) ;XL_check(1)=1;
        XL_check2=Wilkens3( [Re,FCres(3)*1e-04],L ) ;XL_check2(1)=1;
        semilogx((L),XL_m,'ok','markersize',10,'linewidth',3),hold
        plot((L),XL_check,'g','markersize',10,'linewidth',3)
        plot((L), XL_check2,'r--','markersize',10,'linewidth',3)
        set(gca,'fontsize',17)
        legend('raw data','log','Wilkens','Location','NorthEast')
        
%         ylim([min(XL_check(2:end))-1e-5 max(XL_check(2:end))+3e-5])
        titlecell{1,1}='Krivoglaz-Wilkens plot ';
        titlecell{1,2}='--gradient-->rho(dislocations)---intercept-->rho*log(Re) (M=Re*rho^.5)';
        title(titlecell,'fontsize',15)
        ylabel('Strain coefficients divided by L^2','fontsize',15)
        xlabel('Fourier length L','fontsize',15)
        grid
     case 9 %%IB
        if type(6)==3

                            g1=g;
                FCres0=FCres;
                FCres0(2)=FCres(2)/(1e6*1e4);
                g=0:max(g)/(4):max(g)+max(g)/(5);
                L=0:1:length(FC)-1;L=L*a3;
                AA=strainfield_fit(FCres0,L);
                for n=1:length(g)
                IB(n)=a3/sum(AA(1:nmax,n));
                
                end
                for n=1:length(selected)
                    IBm(n)=a3./sum(FC(1:nmax,selected(n))  );
                end
                
                if ishold==1;hold;end
                plot(g1,IBm,'o'),hold
                plot(g,IB,'-.')
                title('WH plot using FCs only--update later','fontsize',15)
                ylabel('IB','fontsize',15)
                xlabel('g','fontsize',15)
                clear global g
        else
            
                col=['ok';'sk';'<k';'>k';'^k';'pk';'ob';'sb';'<b';'>b';'^b';'pb'];
                IN=FCres(1:4);
                IN(3)=FCres(3)/(1e20*1e-16);
        
                AA=exp(allF_log(IN,L));
                AA(1,:)=1;
                for n=1:length(g)
                IB(n)=a3/sum(AA(1:nmax,n));
                
                end
                for n=1:length(selected)
                    IBm(n)=a3./sum(FC(1:nmax,selected(n))  );
                end
                
                if ishold==1;hold;end
                
                for n=1:length(g)
                plot(g(n).*C(n).^.5,IBm(n),col(n,:)),if n==1;hold;end
                end
                plot(g.*C.^.5,IB,'.-r')
                title('WH plot using FCs only--update later','fontsize',15)
                ylabel('IB','fontsize',15)
                xlabel('g*sqrt(C)','fontsize',15)
                legend(num2str(dsettings(1,1).index(selected,:)),'Location','SouthEast')
            
        end
        
end


%     clear global g





    function [lnAA lam]=allF_tsf(lam, L)
                
                for nn=1:length(L)
%                     C=0.2*(1-lam(nn,1)*H2);
                    lnAA(nn,:) = (lam(nn,2)) - B*real(lam(nn,3))*g.^2.*C ;%indivF(lam(nn,:), L(nn));
                end
    end

    function [lnFC lam]=allF_lin(lam, L)
            for nn=1:length(L)
                lnFC(nn,:) =log( exp(lam(nn,2)) - exp(lam(nn,2))*B*real(lam(nn,3))*g.^2.*C );
            end
            
    end 
function [lnAA lam]=indivF(lam, L)
                
        
        q=lam(1);
        C=0.2*(1-q*H2)  ;      
             
           
                lnAA = (lam(2)) - B*real(lam(3))*g.^2.*C ;
%                 if min(C)<0;lnAA=inf*lnAA;
%                 end
end 

    function [lnAA lam]=allF_hex(lam, L)   
    same=0;
            if same==1
                lam(4)=0;lam(1)=0;C=1;
            else
%                 l=dsettings(1,1).index(selected,3)';
%             x=(2/3)*((l./(g*0.295*10)).^2);
%             C=(1+lam(1,1)*x + lam(1,4)*x.^2)  ;      
            end
            for nn=1:length(L)
            lnAA(nn,:) = (lam(nn,2)) - B*real(lam(nn,3))*g.^2.*C ;
            end
    end 

    function [lnAA lam]=allF_log(lam, L)
         
%                 C=0.2*(1-lam(1)*H2);
                for na=1:length(L)
                lnAA(na,:) = (  (- L(na)*1/(lam(2)) ) - L(na)^2*B*lam(3)*log( (lam(4)/lam(3).^.5) /L(na))*g.^2.*C    );
                end
    end


    function [lnAA lam]=allF_Wilk(lam, L)
         
%                 C=0.2*(1-lam(1)*H2);
                for na=1:length(L)       
                lnAA(na,:)=-L(na)/lam(2) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C;
                end
    end

%     function [lnAA lam]=logalt(lam, g)
%         
%         xx=1;
%         for na=1:length(lam)
%                 lnAS=lam(na,1);
%                 lnAD=lam(na,2);
%                 lnAA(na,:) = (lnAD*(B*C)) + lnAS*(g(xx)./g) ;
%         end
%     end

    function [lnAA lam]=logalt(lam, g)
       
                lnAS=lam(1);
                lnAD=lam(2);
                lnAA = (lnAD*(B*C)) + lnAS*(g(1)./g) ;
    end


function [lnAA lam]=allF_inter(lam, L)
             gs=lam(2);mss=lam(5);
             lam(2)=mss;
             lam(5)=gs;
             lam(3)=lam(3)*1e-4;
   
    OUT(2)=gs;OUT(5)=mss;
            lnAA=zeros(length(L),length(g));
          
           for na=1:length(L)       
                lnAA(na,:)= (-L(na)/lam(5) )-L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  - 2*pi^2*g.^2*L(na)^2*lam(2)^2;
           end
           
                if min(C)<0;lnAA=inf*lnAA;
                end
end
    


function [AA_ lam]=allF_together_FC_lognorm(lam, L)
        
%              lam(2)=lam(2)*1e4;  
        
        
             
          
               
           
                for na=1:length(L) 
                    if length(lam)>6
                        if lam(7)==0
                        AA_(na,:)=exp( log(ASlognormSc([lam(2),lam(6)],L(na))) );
                        else
    %                     AA_(na,:)=exp( log(ASlognormSc([lam(2),lam(6)],L(na))) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );
                        AA_(na,:)=exp( -L(na)/lam(2)  - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );

                        end

                    else
%                     AA_(na,:)=exp( log(ASlognormSc([lam(2),lam(6)],L(na))) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );
%                     AA_(na,:)=exp( -L(na)/lam(2)  - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );
                    AA_(na,:)=exp( log(ASlognormSc([lam(2),lam(5)],L(na))) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );
                       

                
                    end

                end
                
                if min(C)<0;AA_=inf*AA_;
                end
end


function [AA_ lam]=allF_together_FC_lognorm_lin(lam, L)
        
%              lam(2)=lam(2)*1e4;  
        
          
        
          
             
          
              
           
                for na=1:length(L) 
                    
                    AA_(na,:)=(   exp(-L(na)/lam(2) )*(1 - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  ));
                   

                end
                
                if min(C)<0;AA_=inf*AA_;
                end
end


end