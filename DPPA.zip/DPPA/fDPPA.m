function varargout = fDPPA(varargin)

% FDPPA 
%      used to fit diffraction spectra and prepare it for analysis by fourierBCC_m methods
% 

% Edit the above text to modify the response to help fDPPA

% Last Modified by GUIDE v2.5 17-Mar-2016 23:22:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fDPPA_OpeningFcn, ...
                   'gui_OutputFcn',  @fDPPA_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fDPPA is made visible.
function fDPPA_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fDPPA (see VARARGIN)

% Choose default command line output for fDPPA
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% UIWAIT makes fDPPA wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/phases.mat'],'dsettings')
% load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/genset.mat'])

set(handles.results_p,'visible','off');
results_b_Callback(hObject, eventdata, handles)
set(handles.sampleid2_t,'string',identa)

% plotfit_b_Callback(hObject, eventdata, handles)

% --- Outputs from this function are returned to the command line.
function varargout = fDPPA_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in load_b.
function load_b_Callback(hObject, eventdata, handles)

% hObject    handle to load_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data=[];
load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')

[file path] = uigetfile({'*.dat';'*.asc';'*.UDF';'*.udf';'*.txt';'*.xy'},'Select File to open')
if file(end-2:end)=='udf'  | file(end-2:end)=='UDF'
    if file(end-2:end)=='udf' 
            perl([cd,'/udfcon_lc.pl'],[path,file(1:end-4),'.udf']); 
    elseif file(end-2:end)=='UDF' 

        perl([cd,'/udfcon.pl'],[path,file(1:end-4),'.UDF']);
    end

    filenomdat=[path,file(1:end-4),'.dat']
    data=load(filenomdat);
    [tube identa]=importfile([path,file]);
    
    if strcmp(tube,'Cu')==1  
        wavelen=0.5*(1.54056+1.54439);%%
    elseif strcmp(tube,'Co')==1
        wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
    end
    set(handles.alpha2_b,'value',1);
    alpha2=0;
elseif file(end-2:end)=='asc'  | file(end-2:end)=='ASC'
    
    fid=fopen([path, file]);
    tex = textscan(fid, '%q', 'delimiter', '\n');h=1;c=0;
%     data=zeros(size(tex{1}),7
    h=1;c=0;
    for n=1:size(tex{1});
        if strcmp(tex{1}{n}(1),'#')==0;
            if h==1;c=c+1;end;
            dat{c}(h,:)=str2num(char(tex{1}{n}));h=h+1;
        else h=1;
        end;
    end
    data=dat{1};
            wavelen=0.5*(1.54056+1.54439);%%
            tube='Cu';alpha2=0;
            set(handles.alpha2_b,'value',1);
% %     data(:,1)=1e3./( data(:,1)/48.227 );
% %     wavelen= 1;
% %             set(handles.alpha2_b,'value',0);
% %             alpha2=1;
            data=sortrows(data);
%             ident=[file(1:end-4),' 2'];
        identa=[file(1:end-4)];
        
else

    wav=menu('Enter Wavelength in A:   ','Copper with alpha2','Cobalt with alpha2','(without alpha2) Enter value in Armstrongs:     ');
    switch wav
        case 1
            wavelen=0.5*(1.54056+1.54439);%%
            tube='Cu';alpha2=0;
            set(handles.alpha2_b,'value',1);
        case 2
            wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
            tube='Co';alpha2=0;
            set(handles.alpha2_b,'value',1);
        case 3
            wavelen= input('enter wavelength in A:  ');
            set(handles.alpha2_b,'value',0);
            alpha2=1;
    end
%     alpha2=menu('Does the tube include alpha2 ?','No','Yes')-1;
        if file(end-2:end)=='.xy'
        da=importdata([path,file]);
        data=da.data;
    else
    data=load([path,file]);
        end
    if size(data,2)>2
        val=input(['Select column(s) to use, of ',num2str(size(data,2)),'    ']);
        data(:,2)=sum(data(:,val),2)';data=data(:,1:2);
    else
    data=data(:,1:2);
    end
    
%     data(:,1)=2*sin(0.5*data(:,1)*pi/180)/wavelen;
    
    identa=input('Enter Sample name:   ','s');
end    

val=2;%input('Interpolate, 1- no, 2- yes,    ');

switch val
    case 1
        data(:,1)=2*sin(pi*data(:,1)/360)/wavelen;
    case 2
        data=tsinterpl(data,wavelen);
end
axes(handles.axes1),if ishold==1;hold;end
semilogy(data(:,1),data(:,2),'.')
set(handles.sampleid2_t,'string',identa)


set(handles.wav_t,'string',num2str(wavelen))

save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
save([cd,'/0. variables/data.mat'],'data')

% --- Executes on button press in kscale_b.
function kscale_b_Callback(hObject, eventdata, handles)
% hObject    handle to kscale_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function name_t_Callback(hObject, eventdata, handles)
% hObject    handle to name_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of name_t as text
%        str2double(get(hObject,'String')) returns contents of name_t as a double


load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
ident=get(hObject,'String');
save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
% --- Executes during object creation, after setting all properties.
function name_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to name_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lat1_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat1_t as text
%        str2double(get(hObject,'String')) returns contents of lat1_t as a double

lat1 = get(hObject,'String') ;
load([cd,'/0. variables/phases.mat'],'ddsettings');
val=get(handles.phase_l,'value');
ddsettings(val).lat1=lat1;

xp=[];
for n=1:length(ddsettings)
    csymm=str2double(ddsettings(1,n).cstruct(1));
    if csymm==2 || csymm==3; sym='cub';elseif csymm==4 sym='hex';end
    if strcmp(class(ddsettings(1,n).lat1),'double')==1
        lat1=ddsettings(1,n).lat1;
    else
        lat1=str2double(ddsettings(1,n).lat1);
    end
    if strcmp(class(ddsettings(1,n).lat2),'double')==1
        lat2=ddsettings(1,n).lat2;
    else
        lat2=str2double(ddsettings(1,n).lat2);
    end
 xp=[xp;1./dspacing(ddsettings(1,n).index,sym,ddsettings(1,1).lambda,lat1,lat2)'];
 ddsettings(n).d=1./xp;
end


save([cd,'/0. variables/phases.mat'],'ddsettings');

% --- Executes during object creation, after setting all properties.
function lat1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lat2_t_Callback(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lat2_t as text
%        str2double(get(hObject,'String')) returns contents of lat2_t as a double

lat2 = get(hObject,'String') ;
load([cd,'/0. variables/phases.mat'],'ddsettings');
val=get(handles.phase_l,'value');
ddsettings(val).lat2=lat2;
save([cd,'/0. variables/phases.mat'],'ddsettings');



xp=[];
for n=1:length(ddsettings)
    csymm=str2double(ddsettings(1,n).cstruct(1));
    if csymm==2 || csymm==3; sym='cub';elseif csymm==4 sym='hex';end
    if strcmp(class(ddsettings(1,n).lat1),'double')==1
        lat1=ddsettings(1,n).lat1;
    else
        lat1=str2double(ddsettings(1,n).lat1);
    end
    if strcmp(class(ddsettings(1,n).lat2),'double')==1
        lat2=dsettings(1,n).lat2;
    else
        lat2=str2double(dsettings(1,n).lat2);
    end
 xp=[xp;1./dspacing(dsettings(1,n).index,sym,dsettings(1,1).lambda,lat1,lat2)'];
 dsettings(n).d=1./xp;
end


save([cd,'/0. variables/phases.mat'],'dsettings');

% --- Executes during object creation, after setting all properties.
function lat2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function wav_t_Callback(hObject, eventdata, handles)
% hObject    handle to wav_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wav_t as text
%        str2double(get(hObject,'String')) returns contents of wav_t as a double


load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
wavelen=get(hObject,'String');
save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')

% --- Executes during object creation, after setting all properties.
function wav_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wav_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in symm_l.
function symm_l_Callback(hObject, eventdata, handles)
% hObject    handle to symm_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns symm_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from symm_l
contents = get(hObject,'String') ;
cstruct=contents{get(hObject,'Value')};
load([cd,'/0. variables/phases.mat'],'dsettings');
val=get(handles.phase_l,'value');
dsettings(val).cstruct=cstruct;
save([cd,'/0. variables/phases.mat'],'dsettings');


% --- Executes during object creation, after setting all properties.
function symm_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to symm_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in alpha2_b.
function alpha2_b_Callback(hObject, eventdata, handles)
% hObject    handle to alpha2_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of alpha2_b

load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
if get(hObject,'value')==1;alpha2=0;else alpha2=1;end
save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')

% --- Executes on selection change in phase_l.
function phase_l_Callback(hObject, eventdata, handles)
% hObject    handle to phase_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns phase_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from phase_l

phase=get(hObject,'value');
load([cd,'/0. variables/phases.mat'],'dsettings')

if phase==1
    set(handles.plusfind_b,'visible','off')
else
    set(handles.plusfind_b,'visible','on')
end

set(handles.lat1_t,'string',dsettings(1,phase).lat1)
set(handles.lat2_t,'string',dsettings(1,phase).lat2)
set(handles.symm_l,'value',str2double(dsettings(1,phase).cstruct(1)))
set(handles.index_l,'string',num2str(dsettings(1,phase).index))

% --- Executes during object creation, after setting all properties.
function phase_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phase_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadset_b.
function loadset_b_Callback(hObject, eventdata, handles)

% hObject    handle to loadset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')

instr_or_set=0;%get(handles.sett_I_b,'value');

if instr_or_set==0
    
    [file path] = uigetfile({'*.mat'},'Select File to open');
    load([path,file]);
    if size(wavelen,1)~=0
    dsettings(1,1).lambda=wavelen;
    end
    set(handles.name_t,'string',dsettings(1,1).id)
    set(handles.wav_t,'string',dsettings(1,1).lambda)
    set(handles.lat1_t,'string',dsettings(1,1).lat1)
    set(handles.lat2_t,'string',dsettings(1,1).lat2)
    set(handles.symm_l,'value',str2num(dsettings(1,1).cstruct(1)))
    if dsettings(1,1).alpha2==0
    set(handles.alpha2_b,'value',1);else set(handles.alpha2_b,'value',0);end
    alpha2=dsettings(1,1).alpha2;
    set(handles.index_l,'string',num2str(dsettings(1,1).index))
    if length(dsettings)==2
    set(handles.phase_l,'string',[dsettings(1,1).name;dsettings(1,2).name])
    else
        
    set(handles.phase_l,'string',[dsettings(1,1).name])
    end
    save([cd,'/0. variables/phases.mat'],'dsettings')
else
    [file path] = uigetfile({'*.mat'},'Select File to open');
    load([path,file]);
    if exist('aabcg_I')==0 || size(aabcg_I,1)==0;aabcg_I=zeros(2,length(aa_I)-1);end
    save([cd,'/0. variables/data_I.mat'],'data_I')
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end
    
set(handles.phase_l,'value',1)
    



% --- Executes on button press in saveset_b.
function saveset_b_Callback(hObject, eventdata, handles)

% hObject    handle to saveset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')

direc=cd;
instr_or_set=get(handles.sett_I_b,'value');
if instr_or_set==0
    [  name path] = uiputfile('','Select folder to save in',[direc,'/1. dsettings/',get(handles.name_t,'string')]);
    save([path,'/',name],'dsettings')
else
    [  name path] = uiputfile('','Select folder to save in',[direc,'/4. Instrumental/',get(handles.name_t,'string')]);
    save([path,'/',name],'data_I','aa_I','aabcg_I')
end
% --- Executes on selection change in index_l.
function index_l_Callback(hObject, eventdata, handles)
  
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns index_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from index_l
val=get(hObject,'value');
phase=get(handles.phase_l,'value');
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'],'data')

plotindex_b_Callback(hObject, eventdata, handles)

plot([1/dsettings(1,phase).d(val), 1/dsettings(1,phase).d(val)],[(min(abs(data(:,2)))+1)*.6, max(data(:,2))],'-ko')
adjtth=abs( data(:,1)-1/dsettings(1,phase).d(val) - 0.2 );
maxpos=find(adjtth==min(adjtth));
adjtth=abs( data(:,1)-1/dsettings(1,phase).d(val) + 0.2 );
minpos=find(adjtth==min(adjtth));
Iminmax=data(minpos:maxpos,2);
min0=(min(Iminmax));

max0=(max(Iminmax));

ylim([min0*.8 ,max0*1.2])
xlim([1/dsettings(1,phase).d(val)-.2, 1/dsettings(1,phase).d(val)+0.2])
% --- Executes during object creation, after setting all properties.
function index_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function index_t_Callback(hObject, eventdata, handles)
% hObject    handle to index_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of index_t as text
%        str2double(get(hObject,'String')) returns contents of index_t as a double


% --- Executes during object creation, after setting all properties.
function index_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in addindex_b.
function addindex_b_Callback(hObject, eventdata, handles)

% hObject    handle to addindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 load([cd,'/0. variables/phases.mat'],'dsettings')
 
nostruct=get(handles.symm_l,'value');
phase=get(handles.phase_l,'value');
index_all=str2num( get(handles.index_l,'string') );


indexadd=str2num( get(handles.index_t,'string') );


if isempty(indexadd)==1;indexadd=[0 0 0];end
index_all=[index_all;indexadd];
set(handles.index_l,'string',num2str(index_all) )
dsettings(phase).index=index_all;
save([cd,'/0. variables/phases.mat'],'dsettings')

% --- Executes on button press in minusindex_b.
function minusindex_b_Callback(hObject, eventdata, handles)
% hObject    handle to minusindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/phases.mat'],'dsettings')
index_all=str2num( get(handles.index_l,'string') );
indexval=get(handles.index_l,'value');
len=size(index_all,1);
phaseno=get(handles.phase_l,'value');
m=1;
for n=1:len
    if n~=indexval
    index_all2(m,:)=index_all(n,:);
    m=m+1;
    end
end
set(handles.index_l,'value',1)

set(handles.index_l,'string',num2str(index_all2) )
dsettings(phaseno).index=index_all2;
save([cd,'/0. variables/phases.mat'],'dsettings')


% --- Executes on button press in plotindex_b.
function plotindex_b_Callback(hObject, eventdata, handles)

% hObject    handle to plotindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/phases.mat'])
figure(10)
xp=[];
for n=1:length(dsettings)
    csymm=str2double(dsettings(1,n).cstruct(1));
    if csymm==2 || csymm==3; sym='cub';elseif csymm==4 sym='hex';end
    if strcmp(class(dsettings(1,n).lat1),'double')==1
        lat1=dsettings(1,n).lat1;
    else
        lat1=str2double(dsettings(1,n).lat1);
    end
    if strcmp(class(dsettings(1,n).lat2),'double')==1
        lat2=dsettings(1,n).lat2;
    else
        lat2=str2double(dsettings(1,n).lat2);
    end
 xp=[xp;1./dspacing(dsettings(1,n).index,sym,dsettings(1,1).lambda,lat1,lat2)'];
%     xp=[xp,1./dsettings(1,n).d];
end
% axes(handles.axes1)
if ishold==1
    hold
end
logplot=get(handles.logplot_b,'value');
if logplot==1

    semilogy(data(:,1),data(:,2)),hold
else
    plot(data(:,1),data(:,2)),hold
end
    sizxp1=size(dsettings(1,1).index,1);
    for n=1:sizxp1
    plot([xp(n),xp(n)],[(min(abs(data(:,2)))+1)*.6;max(data(:,2))*3],'sb--')
    end
    for n=sizxp1+1:length(xp)
    plot([xp(n),xp(n)],[(min(abs(data(:,2)))+1)*.6;max(data(:,2))*3],'sr-')
    end

    
% --- Executes on button press in settings_b.
function settings_b_Callback(hObject, eventdata, handles)

% hObject    handle to dsettings_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    set(handles.index_p,'visible','on');
    set(handles.selectp_l,'visible','off');
    set(handles.results_p,'visible','off');
    set(handles.lat_p,'visible','on');
    
    
    load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
    load([cd,'/0. variables/phases.mat'],'dsettings')
    if exist('dsettings','var')==1 && exist('alpha2','var')==1
        set(handles.name_t,'string',identa);
        set(handles.wav_t,'string',wavelen);index=cell(1,2);phases=cell(1,2);
        for n=1:length(dsettings);phases{n}=dsettings(n).name;end
            set(handles.phase_l,'value',1);set(handles.index_l,'value',1)
            set(handles.phase_l,'string',phases);set(handles.index_l,'string',num2str(dsettings(n).index));
            set(handles.lat1_t,'string',dsettings(1).lat1);set(handles.lat2_t,'string',dsettings(1).lat2);
            set(handles.symm_l,'value',str2double(dsettings(1).cstruct(1)));
        if alpha2==1;set(handles.alpha2_b,'value',0);else set(handles.alpha2_b,'value',1);end 
        
    
        
    end

% --- Executes on button press in update_b.
function update_b_Callback(hObject, eventdata, handles)

% hObject    handle to update_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/phases.mat'],'dsettings')
dsettings(1,1).lambda=str2num(get(handles.wav_t,'string'));
dsettings(1,1).id=(get(handles.name_t,'string'));
phase=get(handles.phase_l,'value');

dsettings(1,phase).lat1=str2num(get(handles.lat1_t,'string'));
dsettings(1,phase).lat2=str2num(get(handles.lat2_t,'string'));
symm=(get(handles.symm_l,'string'));
dsettings(1,phase).cstruct=symm{get(handles.symm_l,'value'),1};
dsettings(1,phase).index=str2num( get(handles.index_l,'string') );

for n=1:length(dsettings)
    csymm=str2num(dsettings(1,n).cstruct(1));if csymm==2 || csymm==3; sym='cub';else sym='hex';end
    
    for nn=1:size(dsettings(1,n).index,1)
        noindex=sum(abs( dsettings(1,n).index(nn,:)) ); 
        if noindex~=0
            dsettings(1,n).d(nn)=dspacing(dsettings(1,n).index(nn,:),sym,dsettings(1,1).lambda,dsettings(1,n).lat1,dsettings(1,n).lat2);
        end
    end
    dsettings(1,n).xp=1./dsettings(1,n).d;
end

save([cd,'/0. variables/phases.mat'],'dsettings')



% --- Executes on button press in bcg_b.
function bcg_b_Callback(hObject, eventdata, handles)

% hObject    handle to bcg_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'],'bcg2peak','wavelen','alpha2')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
dsettings(1).bcg2peak=bcg2peak;
dsettings(1).lambda=wavelen;

dsettings(1).alpha2=alpha2;
if size(dsettings,1)==0
    set(handles.error_p,'visible','on')
    set(handles.error_t,'string','no dsettings')
    
    
else
[aa bcg]=tsxrppa_fit(data, dsettings);
aa(1:3,end+1)=bcg;
end

save([cd,'/0. variables/fit.mat'],'aa','aabcg')
function xp_t_Callback(hObject, eventdata, handles)

% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I_t as text
%        str2double(get(hObject,'String')) returns contents of I_t as a double
load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/fit.mat'])

datinstr=get(handles.data_instr_b,'value');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');
    if datinstr==1
        if val==2
            peakval=length(dsettings(1,1).d)+peakval;
        end
        aa(1,peakval)=str2num( get(hObject,'string') );
    else
        aa_I(1,peakval)=str2num( get(hObject,'string') );
    end
save([cd,'/0. variables/fit.mat'],'aa','aabcg')
% --- Executes during object creation, after setting all properties.
function xp_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xp_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function I_t_Callback(hObject, eventdata, handles)

% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I_t as text
%        str2double(get(hObject,'String')) returns contents of I_t as a double
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/phases.mat'],'dsettings')
val=get(handles.phaseres_l,'value');
datinstr=get(handles.data_instr_b,'value');
peakval=get(handles.indexres_l,'value');
if datinstr==1
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(2,peakval)=str2num( get(hObject,'string') );
else
    aa_I(2,peakval)=str2num( get(hObject,'string') );
    
end
save([cd,'/0. variables/fit.mat'],'aa','aabcg')
save([cd,'/0. variables/phases.mat'],'dsettings')

% --- Executes during object creation, after setting all properties.
function I_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fw_t_Callback(hObject, eventdata, handles)

% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I_t as text
%        str2double(get(hObject,'String')) returns contents of I_t as a double
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/phases.mat'])

val=get(handles.phaseres_l,'value');
datinstr=get(handles.data_instr_b,'value');
peakval=get(handles.indexres_l,'value');
if datinstr==1
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(3,peakval)=str2num( get(hObject,'string') );
else
    aa_I(3,peakval)=str2num( get(hObject,'string') );
    
end

save([cd,'/0. variables/fit.mat'],'aa','aabcg')
% --- Executes during object creation, after setting all properties.
function fw_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fw_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function neta_t_Callback(hObject, eventdata, handles)

% hObject    handle to I_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I_t as text
%        str2double(get(hObject,'String')) returns contents of I_t as a double
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/phases.mat'],'dsettings')

datinstr=get(handles.datainstr_b,'value');
val=get(handles.phaseres_l,'value');
peakval=get(handles.indexres_l,'value');
if datinstr==1
    if val==2
        peakval=length(dsettings(1,1).d)+peakval;
    end
    aa(4,peakval)=str2num( get(hObject,'string') );
else
    aa_I(4,peakval)=str2num( get(hObject,'string') );
    
end
indexres_l_Callback(hObject, eventdata, handles)
save([cd,'/0. variables/fit.mat'],'aa','aabcg')
save([cd,'/0. variables/phases.mat'],'dsettings')

% --- Executes during object creation, after setting all properties.
function neta_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to neta_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in indexres_l.
function indexres_l_Callback(hObject, eventdata, handles)
   
% hObject    handle to indexres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns indexres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indexres_l

load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'],'bcg2peak','wavelen','alpha2')

val=get(handles.phaseres_l,'value');
peakno=get(handles.indexres_l,'value');
datorI=get(handles.data_instr_b,'value');

if val==2 && datorI==1
    peakno=length(dsettings(1,1).d)+peakno;
end
axes(handles.axes1)
% figure(10) 
    if datorI==1
        load([cd,'/0. variables/fit.mat'],'aa','aabcg')
        load([cd,'/0. variables/data.mat'],'data')
        if ishold==1;
            hold;end
            logplot=get(handles.logplot_b,'value');

        if logplot==1
            semilogy(data(:,1),data(:,2),'.'),hold
        else
            plot(data(:,1),data(:,2),'.'),
            hold    
        end
        
            IIfit=pv_tv_aa(aa(:,:),data(:, 1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
            plot(data(:,1),IIfit,'m')
            lam0=aa;lam0(:,peakno)=zeros(size(aa(:,1)));
            IIfit=+ pv_tv_aa(lam0,data(:, 1))+ pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
            plot(data(:,1),IIfit,'g')
%             IIfit=pv_tv_aa(aa(:,:),data(:, 1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
%             plot(data(:,1),IIfit,'m')
            IIfit= data(:,2) - pv_tv_aa(lam0,data(:, 1));%- pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
            plot(data(:,1),IIfit,'k')
            
            if logplot~=1
                IIfit=pv_tv_aa(aa(:,:),data(:, 1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
                plot(data(:,1),data(:,2)-IIfit,'-r.')
                plot(data(:,1),data(:,2)*0,'k:')
            end
        
    else
        load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        load([cd,'/0. variables/data_I.mat'],'data_I')
        if ishold==1;
            hold;end
            logplot=get(handles.logplot_b,'value');

        if logplot==1
            semilogy(data_I(:,1),data_I(:,2),'.'),hold
        else
            plot(data_I(:,1),data_I(:,2),'.'),
            hold    
        end
        
            IIfit=pv_tv_aa(aa_I(:,:),data_I(:, 1))+pv_tv_aa([aabcg_I(:,peakno);0;0],data_I(:, 1)) ;
            plot(data_I(:,1),IIfit,'m')
            lam0=aa_I;lam0(:,peakno)=zeros(size(aa_I(:,1)));
            IIfit=+ pv_tv_aa(lam0,data_I(:, 1))+ pv_tv_aa([aabcg_I(:,peakno);0;0],data_I(:, 1)) ;
            plot(data_I(:,1),IIfit,'g')
%             IIfit=pv_tv_aa(aa(:,:),data(:, 1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
%             plot(data(:,1),IIfit,'m')
            IIfit= data_I(:,2) - pv_tv_aa(lam0,data_I(:, 1));%- pv_tv_aa([aabcg(:,peakno);0;0],data(:, 1)) ;
%             plot(data_I(:,1),IIfit,'k')
            if logplot~=1
            IIfit=pv_tv_aa(aa_I(:,:),data_I(:, 1))+pv_tv_aa([aabcg_I(:,peakno);0;0],data_I(:, 1)) ;
            plot(data_I(:,1),data_I(:,2)-IIfit,'-r.')
            end
        
    end


datainstr=get(handles.data_instr_b,'value');
if datainstr==1

    



        set(handles.xp_t,'string', num2str(aa(1,peakno)))
        set(handles.I_t,'string', num2str(aa(2,peakno)))
        set(handles.fw_t,'string', num2str(aa(3,peakno)))
        set(handles.neta_t,'string', num2str(aa(4,peakno)))
        set(handles.bcgI1_t,'string', num2str(aabcg(1,peakno)))
        set(handles.bcgI2_t,'string', num2str(aabcg(2,peakno)))
        
        if aa(1,peakno)~=0
%         axes(handles.axes1)
        adjtth=abs( data(:,1)-aa(1,peakno) +bcg2peak);
        peak_posmin=find(adjtth==min(adjtth));
        adjtth=abs( data(:,1)-aa(1,peakno) -bcg2peak);
        peak_posmax=find(adjtth==min(adjtth));
        if logplot==1
        xlim([aa(1,peakno)-bcg2peak aa(1,peakno)+bcg2peak])
        ylim([min(data(peak_posmin:peak_posmax,2))*0.9 max(data(peak_posmin:peak_posmax,2))*1.1])
        
        else
        xlim([aa(1,peakno)-bcg2peak aa(1,peakno)+bcg2peak])
        end
%         ylim([min(data(peak_posmin:peak_posmax,2))*0.9 max(data(peak_posmin:peak_posmax,2))*1.1])
        end
else
    pno1=peakno;
    
%         figure(1)


        set(handles.xp_t,'string', num2str(aa_I(1,peakno)))
        set(handles.I_t,'string', num2str(aa_I(2,peakno)))
        set(handles.fw_t,'string', num2str(aa_I(3,peakno)))
        set(handles.neta_t,'string', num2str(aa_I(4,peakno)))
        set(handles.bcgI1_t,'string', num2str(aabcg_I(1,pno1)))

        set(handles.bcgI2_t,'string', num2str(aabcg_I(2,pno1)))
        
        
        if aa_I(1,peakno)~=0
        adjtth=abs( data_I(:,1)-aa_I(1,peakno) +bcg2peak);
        peak_posmin=find(adjtth==min(adjtth));
        adjtth=abs( data_I(:,1)-aa_I(1,peakno) -bcg2peak);
        peak_posmax=find(adjtth==min(adjtth));
        szfit=str2num( get(handles.sizfit_t,'string') );
        if logplot==1
        xlim([aa_I(1,peakno)-szfit aa_I(1,peakno)+szfit])
        else
        xlim([aa_I(1,peakno)-szfit aa_I(1,peakno)+szfit])
        end
        ylim([min(data_I(peak_posmin:peak_posmax,2))-max(data_I(peak_posmin:peak_posmax,2))*.05 max(data_I(peak_posmin:peak_posmax,2))*1.1])
        end
%         ylim([-.5e4 4.7e4])
        xlabel('K','fontsize',17)
        ylabel('Intensity- arbitary units','fontsize',17)
        set(gca,'fontsize',15)
        
end

legend('Raw data','Fit of all')%,'Fit of rest','Data to use')

% --- Executes during object creation, after setting all properties.
function indexres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indexres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in results_b.
function results_b_Callback(hObject, eventdata, handles)

% hObject    handle to results_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'],'data')
if size(dsettings,1)==0 
    set(handles.error_p,'visible','on')
    set(handles.error_t,'string','no dsettings')
    set(handles.uipanel20,'visible','on')

else

    newq=menu('new aa?','yes','no')
    if newq==1
        aa=zeros(4,length(dsettings(1,1).d)+1);
        if length(dsettings)==2
            aa=zeros(4,length(dsettings(1,1).d)+length(dsettings(1,2).d)+1);
        end
%         aabcg=zeros( 2,length(dsettings(1,1).d) );
        xxx=1;
        for x=1:length(dsettings)
            
            
            if str2double(dsettings(x).cstruct(1))==3 || str2double(dsettings(x).cstruct(1))==2
            crys='cub';
            elseif str2double(dsettings(x).cstruct(1))==4
            crys='hex';
            end        
            if strcmp(class(dsettings(1,x).lat1),'double')==1
                lat1=dsettings(1,x).lat1;
            else
                lat1=str2double(dsettings(1,x).lat1);
            end
            if strcmp(class(dsettings(1,x).lat2),'double')==1
                lat2=dsettings(1,x).lat2;
            else
                lat2=str2double(dsettings(1,x).lat2);
            end
    


            for xx=1:length(dsettings(1,x).index)
                xx
                aa(1,xxx)=1./dspacing(dsettings(x).index(xx,:),crys,1,lat1,lat2  );
%               aa(1,xxx)=1/dsettings(1,x).d(xx);
              if size(data,1)~=0
              adjtth=abs( data(:,1) - aa(1,xx) - 1e-03);
              maxpos=find(adjtth==min(adjtth));
              adjtth=abs( data(:,1) - aa(1,xx) + 1e-03);
              minpos=find(adjtth==min(adjtth));
              aa(2,xxx)=max(data(minpos:maxpos,2));
              end
              aa(3,xxx)=1e-03;
              
              aa(4,xxx)=.4;
              xxx=xxx+1;
            end

        end
        aabcg=0*aa(1:2,1:end-1); 
        save([cd,'/0. variables/fit.mat'],'aa','aabcg')

        
    end
               

visi=get(handles.results_p,'visible');
if strcmp(visi,'off')
    set(handles.data_instr_b,'value',1);
    set(handles.results_p,'visible','on');
    set(handles.indexres_l,'value',1);
    set(handles.indexres_l,'string',num2str(dsettings(1,1).index) )
    set(handles.xp_t,'string', num2str(aa(1,1)))
    set(handles.index_p,'visible','off');
    set(handles.selectp_l,'visible','off');
    for n=1:length(dsettings)
        phases{n}=dsettings(1,n).name;
    end
        
    set(handles.phaseres_l,'string',phases)
    set(handles.phaseres_l,'value',1)
    set(handles.I_t,'string', num2str(aa(2,1)))
    set(handles.fw_t,'string', num2str(aa(3,1)))
    set(handles.neta_t,'string', num2str(aa(4,1)))
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
    
else
    set(handles.results_p,'visible','off');
end
end

if size(data,1)~=0
plotfit_b_Callback(hObject, eventdata, handles)
end


% --- Executes on selection change in phaseres_l.
function phaseres_l_Callback(hObject, eventdata, handles)

% hObject    handle to phaseres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns phaseres_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from phaseres_l
load([cd,'/0. variables/phases.mat'],'dsettings')
val=get(hObject,'value');

set(handles.indexres_l,'value',1)
set(handles.indexres_l,'string',num2str(dsettings(1,val).index))

% --- Executes during object creation, after setting all properties.
function phaseres_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phaseres_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg1_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg1_t as text
%        str2double(get(hObject,'String')) returns contents of bcg1_t as a double



% --- Executes during object creation, after setting all properties.
function bcg1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg3_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg3_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg3_t as text
%        str2double(get(hObject,'String')) returns contents of bcg3_t as a double


% --- Executes during object creation, after setting all properties.
function bcg3_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg3_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcg2_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcg2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcg2_t as text
%        str2double(get(hObject,'String')) returns contents of bcg2_t as a double


% --- Executes during object creation, after setting all properties.
function bcg2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcg2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in updatefit_b.
function updatefit_b_Callback(hObject, eventdata, handles)

% hObject    handle to updatefit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in instr_b.
function instr_b_Callback(hObject, eventdata, handles)
% hObject    handle to instr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if get(handles.instr_b,'value')==1
    set(handles.index_p,'visible','on');
    set(handles.selectp_l,'visible','on');
    set(handles.lat_p,'visible','off');
    set(handles.sett_I_b,'value',1)
    set(handles.sett_I_b,'string','Instrumental')
    
% else
%     set(handles.index_p,'visible','off')
%     set(handles.selectp_l,'visible','off');
% set(handles.lat_p,'visible','on');
% set(handles.sett_I_b,'value',0)
% end

% --- Executes on button press in findpks_b.
function findpks_b_Callback(hObject, eventdata, handles)

% hObject    handle to findpks_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1)
if ishold==1;hold;end
semilogy(data_I(:,1),data_I(:,2)),hold
but=2;n=1;xp=[];
while but~=3
[xp_I(n) y(n) but]=ginput(1);
n=n+1;
end
xp_I=sort(xp_I(1:end-1));
if ishold~=1;hold;end
    
for n=1:length(xp_I)
    plot([xp_I(n) xp_I(n)], [min(data_I(:,2)), max(data_I(:,2))],'r')
end
    
instr.d=1./xp_I;
instr.bcg2peak=0.022;
instr.lambda=get(handles.wav_t,'string');
if get(handles.alpha2_b,'value')==0
    instr.alpha2=1;
else
    instr.alpha2=0;
end


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Si_b.
function Si_b_Callback(hObject, eventdata, handles)

% hObject    handle to Si_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/data_I.mat'],'data_I')

[file path] = uigetfile({'*.UDF';'*.dat';'.txt'},'Select File to open')

if file(end-2:end)=='UDF' | file(end-2:end)=='udf' 
    
    perl('/Applications/MATLAB74/work/1.tsfit/udfcon.pl',[path,file(1:end-4),'.UDF']);
     filenomdat=[path,file(1:end-4),'.dat']
    [data_I]=load(filenomdat);
    [tube identa]=importfile([path,file]);
    
    if strcmp(tube,'Cu')==1  
        wavelen=0.5*(1.54056+1.54439);%%
    elseif strcmp(tube,'Co')==1
        wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
    end
    set(handles.alpha2_b,'value',1);
else

    wav=menu('Enter Wavelength','Copper','Cobalt','Enter value in Armstrongs');
    switch wav
        case 1
            wavelen=0.5*(1.54056+1.54439);%%
        case 2
            wavelen= 0.5*(1.78897+ 1.79285);%%in Armstrongs
        case 3
            wavelen= input('enter wavelength');
    end
    identa=['standard',num2str(wavelen)];
    [data_I]=load([path,file]);
end    

data_I=tsinterpl(data_I,wavelen);
axes(handles.axes1),if ishold==1;hold;end
semilogy(data_I(:,1),data_I(:,2))
set(handles.name_t,'string',identa)
set(handles.wav_t,'string',num2str(wavelen))




% --- Executes on button press in sett_I_b.
function sett_I_b_Callback(hObject, eventdata, handles)
% hObject    handle to sett_I_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObje_ct,'Value') returns toggle state of sett_I_b







function error_t_Callback(hObject, eventdata, handles)
% hObject    handle to error_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of error_t as text
%        str2double(get(hObject,'String')) returns contents of error_t as a double


% --- Executes during object creation, after setting all properties.
function error_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to error_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in error_b.
function error_b_Callback(hObject, eventdata, handles)
% hObject    handle to error_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

fiton=get(handles.selectp_l,'visible');

if strcmp(fiton,'on')==1
    set(handles.index_p,'visible','on')
    set(handles.error_p,'visible','off')
else
    
    set(handles.error_p,'visible','off')

end
% --- Executes on button press in done_b.
function done_b_Callback(hObject, eventdata, handles)
% hObject    handle to done_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.index_p,'visible','off');
set(handles.selectp_l,'visible','off');


% --- Executes on button press in doneres_b.
function doneres_b_Callback(hObject, eventdata, handles)

% hObject    handle to doneres_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.results_p,'visible','off');


% --- Executes on button press in fitSi_b.
function fitSi_b_Callback(hObject, eventdata, handles)

% hObject    handle to fitSi_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if size(instr,1)==0
    set(handles.error_p,'visible','on')
    set(handles.index_p,'visible','off')
    set(handles.error_t,'string','No Standard or peaks Selected')
else
    [aa_I bcg_I]=tsxrppa_fit(data_I, instr);
    aa_I(1:3,end+1)=bcg_I;
    aabcg_I=zeros(2,size(aa_I,2)-1);
end


% --- Executes on button press in findpks2_b.
function findpks2_b_Callback(hObject, eventdata, handles)

% --- Executes on button press in findpksend_b.
function findpksend_b_Callback(hObject, eventdata, handles)
% hObject    handle to findpksend_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox4.
function listbox4_Callback(hObject, eventdata, handles)
% hObject    handle to listbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox4


% --- Executes during object creation, after setting all properties.
function listbox4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in savefit_b.
function savefit_b_Callback(hObject, eventdata, handles)

% hObject    handle to savefit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% load('/Applications/MATLAB74/work/4. Steel Fit/fit_data/steel_fit.mat')

% [ path] = uigetdir('/Applications/MATLAB74/work/4. Steel Fit/data','Select folder to save in');
load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/data_I.mat'],'data_I')
load([cd,'/0. variables/phases.mat'])

[FileName,PathName] = uiputfile('*.mat','Select the Fit file',[cd]);
filq=exist( [PathName,FileName]);
id=get(handles.sampleid2_t,'string');
if filq~=0
load([PathName,FileName],'fita')
sizfit=length(fita);
else
    dotsq=find(FileName=='.');
    if isempty(dotsq)==0
        FileName=FileName(1:dotsq-1);
        
    end
    FileName=[FileName,'_fit'];
    sizfit=0;
    val_old=1;
    fita=[];
end


for n=1:length(fita)
noms=fita(1,n).name;
ifind=strcmp(noms,id);
val_old=sizfit+1;
if ifind~=0
    val_old=n;
    break
end
end


    
fita(1,val_old).instr=tube;
fita(1,val_old).alpha2=alpha2;
fita(1,val_old).data_I=data_I;
fita(1,val_old).aa_I=aa_I;
fita(1,val_old).aa=aa;
fita(1,val_old).data=data;
fita(1,val_old).aabcg_I=aabcg_I;
fita(1,val_old).aabcg=aabcg;

% mval=menu('Create or reference dsettings file','create','refer');
% if mval==1
%     [FileN,PathN] = uiputfile('*.mat','Select the Fit file',[cd]);
%     save([PathN,FileN],'dsettings')
% elseif mval==2
%     [FileN,PathN] = uigetfile('*.mat','Select the Fit file',[cd]);
% end
% fita(1,val_old).FileN=FileN;
% fita(1,val_old).PathN=PathN;    

if size(id)~=0
    fita(1,val_old).name=get(handles.sampleid2_t,'string');
else
    id=input('Enter name:     ','s');
    fita(1,val_old).name=id;
end
id
val=input('Enter a numerical value? \n');
fita(1,val_old).val=val;
save([PathName,FileName],'fita')

% --- Executes on button press in fourierBCC_m_b.
function fourier_m_Callback(hObject, eventdata, handles)
     
% hObject    handle to fourierBCC_m_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/fit_I.mat'])
load([cd,'/0. variables/data_I.mat'])

valmenu=menu('use current data?','yes','no');
if valmenu==2
    
[file path] = uigetfile('','Select File containing batch data',[cd,'/2. data/hrpd/1.hrpd batch']);
load([cd,'/0. variables/phases.mat'],'dsettings')
load([path,file]);
for n=1:length(fita)
    nom{n}=fita(n).name;
end


filnom=menu('Select File',nom);
filnomI=menu('Select Instrumental File',nom);
data=fita(filnom).data;
aa=fita(filnom).aa;
aabcg=fita(filnom).aabcg;
data_I=fita(filnomI).data;
aa_I=fita(filnomI).aa;
aabcg_I=fita(filnomI).aabcg;

end

load([cd,'/0. variables/phases.mat'],'dsettings')

aDPPA;


function fgs_t_Callback(hObject, eventdata, handles)
% hObject    handle to fgs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fgs_t as text
%        str2double(get(hObject,'String')) returns contents of fgs_t as a double


% --- Executes during object creation, after setting all properties.
function fgs_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fgs_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frho_t_Callback(hObject, eventdata, handles)
% hObject    handle to frho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frho_t as text
%        str2double(get(hObject,'String')) returns contents of frho_t as a double


% --- Executes during object creation, after setting all properties.
function frho_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frho_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fM_t_Callback(hObject, eventdata, handles)
% hObject    handle to fM_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fM_t as text
%        str2double(get(hObject,'String')) returns contents of fM_t as a double


% --- Executes during object creation, after setting all properties.
function fM_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fM_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fq_t_Callback(hObject, eventdata, handles)
% hObject    handle to fq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fq_t as text
%        str2double(get(hObject,'String')) returns contents of fq_t as a double


% --- Executes during object creation, after setting all properties.
function fq_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in fplot_l.
function fplot_l_Callback(hObject, eventdata, handles)
% hObject    handle to fplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns fplot_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from fplot_l


% --- Executes during object creation, after setting all properties.
function fplot_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fplot_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5


% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in fdone_b.
function fdone_b_Callback(hObject, eventdata, handles)
% hObject    handle to fdone_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% % --- Executes on button press in loadfiterror_b.
% function loadfiterror_b_Callback(hObject, eventdata, handles)
% 
% % hObject    handle to loadfiterror_b (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% [file path] = uigetfile({'*.mat'},'Select File to open')
% load([path,file]);
% ;

% --- Executes on button press in plusfind_b.
function plusfind_b_Callback(hObject, eventdata, handles)

% hObject    handle to plusfind_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat')


index_all=str2num( get(handles.index_l,'string') );
    nn=get(handles.phase_l,'value');
    indexlen=size(index_all,1);
    [x y]=ginput(1);
    dsettings(1,nn).d(indexlen+1)=1/x;
    dsettings(1,nn).index(indexlen+1,:)=[0 0 0];
    indexadd=[0 0 0];
    index_all=[index_all;indexadd];
    set(handles.index_l,'string',num2str(index_all) )




save('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat','dsettings')

% --- Executes on button press in WH_b.
function WH_b_Callback(hObject, eventdata, handles)

% hObject    handle to WH_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.WH_p,'visible', 'on' )
set(handles.variance_act_p,'visible', 'off' )
set(handles.variance_p,'visible', 'on' )

set(handles.uipanel20,'visible','off')
set(handles.results_p,'visible','on');
set(handles.index_p,'visible','off');
set(handles.selectp_l,'visible','off');



function gsWH_t_Callback(hObject, eventdata, handles)
% hObject    handle to gsWH_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gsWH_t as text
%        str2double(get(hObject,'String')) returns contents of gsWH_t as a double


% --- Executes during object creation, after setting all properties.
function gsWH_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gsWH_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function strainWH_t_Callback(hObject, eventdata, handles)
% hObject    handle to strainWH_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of strainWH_t as text
%        str2double(get(hObject,'String')) returns contents of strainWH_t as a double


% --- Executes during object creation, after setting all properties.
function strainWH_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to strainWH_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function WHq_t_Callback(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WHq_t as text
%        str2double(get(hObject,'String')) returns contents of WHq_t as a double


% --- Executes during object creation, after setting all properties.
function WHq_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox6.
function listbox6_Callback(hObject, eventdata, handles)
% hObject    handle to listbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox6


% --- Executes during object creation, after setting all properties.
function listbox6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in WHdone_b.
function WHdone_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHdone_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.WH_p,'visible','off')
set(handles.variance_p,'visible','off')


set(handles.uipanel20,'visible','on')
% set(handles.results_p,'visible','off');
% set(handles.index_p,'visible','on');
% set(handles.selectp_l,'visible','on');


% --- Executes on button press in pushbutton42.
function pushbutton42_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton42 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadfitmenu_b.
function loadfitmenu_b_Callback(hObject, eventdata, handles)

% hObject    handle to loadfitmenu_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% aabcg=0*aabcg;

[FileName,PathName] = uigetfile('*.mat','Select the Fit file',[cd])
save([cd,'/0. variables/load_fnames.mat'],'FileName','PathName')
 load([PathName,FileName],'fita')

for n=1:length(fita)
nom{n}=fita(1,n).name;
end
set(handles.load_l,'value',1)
set(handles.load_l,'string',nom)



% sel=menu('select fit data to load',nom);

% % --- Executes on button press in fitindiv_b.
% function fitindiv_b_Callback(hObject, eventdata, handles)
% % hObject    handle to fitindiv_b (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox7.
function listbox7_Callback(hObject, eventdata, handles)
% hObject    handle to listbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox7 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox7


% --- Executes during object creation, after setting all properties.
function listbox7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox9.
function listbox9_Callback(hObject, eventdata, handles)
% hObject    handle to listbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox9 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox9


% --- Executes during object creation, after setting all properties.
function listbox9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton47.
function pushbutton47_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton47 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function bcgI2_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcgI2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcgI2_t as text
%        str2double(get(hObject,'String')) returns contents of bcgI2_t as a double
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/data_I.mat'])
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')


datainstr=get(handles.data_instr_b,'value');
peakno=get(handles.indexres_l,'value');
val=get(handles.phaseres_l,'value');
if val==2 && datainstr==1
    peakno=length(dsettings(1,1).d)+peakno;
end

switch datainstr
    case 1
         
         aabcg(2,peakno)=str2num(get(hObject,'string'));
    case 2
         
end

save([cd,'/0. variables/fit.mat'],'aa','aabcg')
indexres_l_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function bcgI2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcgI2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bcgI1_t_Callback(hObject, eventdata, handles)
% hObject    handle to bcgI1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bcgI1_t as text
%        str2double(get(hObject,'String')) returns contents of bcgI1_t as a double
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/data_I.mat'])
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')


datainstr=get(handles.data_instr_b,'value');
peakno=get(handles.indexres_l,'value');
val=get(handles.phaseres_l,'value');
if val==2 && datainstr==1
    peakno=length(dsettings(1,1).d)+peakno;
end


switch datainstr
    case 1
         
         aabcg(1,peakno)=str2num(get(hObject,'string'));
    case 2
         
end

save([cd,'/0. variables/fit.mat'],'aa','aabcg')
indexres_l_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function bcgI1_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bcgI1_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in data_instr_b.
function data_instr_b_Callback(hObject, eventdata, handles)

% hObject    handle to data_instr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns data_instr_b contents as cell array
%        contents{get(hObject,'Value')} returns selected item from data_instr_b

data_instr=get(hObject,'value');
load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/fit_I.mat'])

set(handles.indexres_l,'value',1)
if data_instr==1
    set(handles.indexres_l,'string',num2str(dsettings(1,1).index) )
    set(handles.xp_t,'string', num2str(aa(1,1)))
    for n=1:length(dsettings)
        phases(n,:)=dsettings(1,n).name;
    end
        
    set(handles.phaseres_l,'string',phases)
    set(handles.I_t,'string', num2str(aa(2,1)))
    set(handles.fw_t,'string', num2str(aa(3,1)))
    set(handles.neta_t,'string', num2str(aa(4,1)))
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
else
    
    set(handles.indexres_l,'string',num2str(aa_I(1,1:end-1)') )
    set(handles.xp_t,'string', num2str(aa_I(1,1)))
    
        
    set(handles.phaseres_l,'string','instrumental')
    set(handles.I_t,'string', num2str(aa_I(2,1)))
    set(handles.fw_t,'string', num2str(aa_I(3,1)))
    set(handles.neta_t,'string', num2str(aa_I(4,1)))
    set(handles.bcg1_t,'string',num2str(aa_I(1,end)))
    set(handles.bcg2_t,'string',num2str(aa_I(2,end)))
    set(handles.bcg3_t,'string',num2str(aa_I(3,end)))
    
end
plotfit_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function data_instr_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to data_instr_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in indivfit_b.
function indivfit_b_Callback(hObject, eventdata, handles)

% hObject    handle to refit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% plotraw_b_Callback(hObject, eventdata, handles)
% delK=0.025;

load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'],'alpha2','tube')



fitleft=get(handles.selindivfit_b,'value');

n=get(handles.indexres_l,'value');
datainstr=get(handles.data_instr_b,'value');

val=get(handles.phaseres_l,'value');
if val==2 && datainstr==1
    n=length(dsettings(1,1).d)+n;
end

fitsiz=str2num( get(handles.sizfit_t,'string') );

if datainstr ==2
load([cd,'/0. variables/data_I.mat'],'data_I')
        load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        
        
%         if size(aa,1)>4
%         aa(5:6,n)=aa(3:4,n);
%         end
        
        incretth=data_I(2,1)-data_I(1,1);
        incretth=double( int16(incretth/1e-5 ))*1e-05;
        posdelK=fitsiz/incretth;
        aa2=aa_I;
        adjtth=abs(data_I(:,1)-aa_I(1,n));
        peakpos=find(adjtth==min(adjtth));
        clear adjtth
        I=data_I(:,2) ;
 
        posb4=peakpos-posdelK;if posb4<1;posb4=1 ;end
        posa4=peakpos+posdelK;if posa4>size(data_I,1);posa4=size(data_I,1);end
%         end
        I=I(posb4:posa4);

        delxp=abs( aa_I(1,:)-aa_I(1,n) );    
        aapos=find( delxp<fitsiz );
        lenaa=size(aa_I,2);

        fpos=find(aapos==n);%which peak is changing
 
        
        aapos(end+1)=lenaa;
        tth=data_I((posb4:posa4), 1);
        I  =  I + pv_tv_aa([aa2(:,aapos(1:end-1)),zeros(size(aa_I(:,1)))],data_I((posb4:posa4), 1)) -  pv_tv_aa(aa2(:,:),data_I((posb4:posa4), 1));
        %I = intensity + fit_of_close(inc_bcg) - fit_of_all(inc_bcg) 
        aa_I(1:4,lenaa)=[I(1) 0 0 fpos]';
        lam0=aa_I(:,aapos);
        aa_I(1:2,end)=aabcg_I(:,aapos(fpos(1)));
        
        aa_I(:,aapos)=onepeak(tth, I, aa_I(:,aapos));
        
%         aa(5:6,:)=aa(3:4,:);
%         aa(:,end)=0*aa(:,end);
        aapeak=aa_I(:,aapos);
        IIfit=pv_tv_aa(aapeak,data_I((posb4:posa4), 1));
        if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');
        if logplot==0
            plot(data_I(posb4:posa4,1),I),hold
        else
            semilogy(data_I(posb4:posa4,1),I),hold
        end
        plot(tth,IIfit,'m')
        aabcg_I(:,n)=aa_I(1:2,lenaa);

        aa_I(1:4,end)=aa2(1:4,end);

        
        save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

else
        
        load([cd,'/0. variables/data.mat'],'data')
        load([cd,'/0. variables/fit.mat'],'aa','aabcg')
        
        
%         if size(aa,1)>4
%         aa(5:6,n)=aa(3:4,n);
%         end
        
        incretth=data(2,1)-data(1,1);
        incretth=double( int16(incretth/1e-5 ))*1e-05;
        posdelK=fitsiz/incretth;
        aa2=aa;
        adjtth=abs(data(:,1)-aa(1,n));
        peakpos=find(adjtth==min(adjtth));
        clear adjtth
        I=data(:,2) ;
        
%      
        posb4=peakpos-posdelK;if posb4<1;posb4=1 ;end
        posa4=peakpos+posdelK;if posa4>size(data,1);posa4=size(data,1);end
%         end
        I=I(posb4:posa4);

        delxp=abs( aa(1,:)-aa(1,n) );    
        aapos=find( delxp<fitsiz );
        lenaa=size(aa,2);

        fpos=find(aapos==n);%which peak is changing
 
        
        aapos(end+1)=lenaa;
        tth=data((posb4:posa4), 1);
        I  =  I + pv_tv_aa([aa2(:,aapos(1:end-1)),zeros(size(aa(:,1)))],data((posb4:posa4), 1)) -  pv_tv_aa(aa2(:,:),data((posb4:posa4), 1));
        %I = intensity + fit_of_close(inc_bcg) - fit_of_all(inc_bcg) 
        aa(1:4,lenaa)=[I(1) 0 0 fpos]';
        lam0=aa(:,aapos);
        aa(1:2,end)=aabcg(:,aapos(fpos(1)));
        
        aa(:,aapos)=onepeak(tth, I, aa(:,aapos));
        
%         aa(5:6,:)=aa(3:4,:);
%         aa(:,end)=0*aa(:,end);
        aapeak=aa(:,aapos);
        IIfit=pv_tv_aa(aapeak,data((posb4:posa4), 1));
        if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');
        if logplot==0
            plot(data(posb4:posa4,1),I),hold
        else
            semilogy(data(posb4:posa4,1),I),hold
        end
        plot(tth,IIfit,'m')
        aabcg(:,n)=aa(1:2,lenaa);

        aa(1:4,end)=aa2(1:4,end);

        
        save([cd,'/0. variables/fit.mat'],'aa','aabcg')
        
end
% --- Executes on button press in bcgspline_b.
function bcgspline_b_Callback(hObject, eventdata, handles)

% hObject    handle to bcgspline_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'],'bcg2peak')

datainstr=get(handles.data_instr_b,'value');
if datainstr==1
%     bcg2peak=dsettings(1,1).bcg2peak;
    xp=aa(1,:);
    logplot=get(handles.logplot_b,'value');
    if size(aa,2)==4
    aa(:,size(aa,2))=steel_bcg(data(:,1), data(:,2), xp, bcg2peak,logplot);
    else
    aa(1:4,size(aa,2))=steel_bcg(data(:,1), data(:,2), xp, bcg2peak,logplot);
    end
    set(handles.bcg1_t,'string',num2str(aa(1,end)))
    set(handles.bcg2_t,'string',num2str(aa(2,end)))
    set(handles.bcg3_t,'string',num2str(aa(3,end)))
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
else
    load([cd,'/0. variables/data_I.mat'],'data_I')
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
%     bcg2peak=dsettings(1,1).bcg2peak;
    xp=aa_I(1,:);
    logplot=get(handles.logplot_b,'value');
    aa_I(:,size(aa_I,2))=steel_bcg(data_I(:,1), data_I(:,2), xp, bcg2peak,logplot);
    set(handles.bcg1_t,'string',num2str(aa_I(1,end)))
    set(handles.bcg2_t,'string',num2str(aa_I(2,end)))
    set(handles.bcg3_t,'string',num2str(aa_I(3,end)))
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end

function sizfit_t_Callback(hObject, eventdata, handles)
% hObject    handle to sizfit_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sizfit_t as text
%        str2double(get(hObject,'String')) returns contents of sizfit_t as a double


% --- Executes during object creation, after setting all properties.
function sizfit_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sizfit_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plotfit_b.
function plotfit_b_Callback(hObject, eventdata, handles)

% hObject    handle to plotfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% figure(2)
load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/data.mat'],'data')
datorI=get(handles.data_instr_b,'value');
% figure
if datorI==1
    if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');

    if logplot==1
        semilogy(data(:,1),data(:,2),'k:'),hold
    else
        plot(data(:,1),data(:,2)),hold    
    end
    IIfit=pv_tv_aa(aa(:,:),data(:, 1)) ;
    plot(data(:,1),IIfit,'k')
    
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    load([cd,'/0. variables/data_I.mat'],'data_I')
    if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');

    if logplot==1
        semilogy(data_I(:,1),data_I(:,2)),hold
    else
        plot(data_I(:,1),data_I(:,2)),hold    
    end
    IIfit=pv_tv_aa(aa_I(:,:),data_I(:, 1)) ;
    plot(data_I(:,1),IIfit,'m')
end
% --- Executes on button press in logplot_b.
function logplot_b_Callback(hObject, eventdata, handles)
% hObject    handle to logplot_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of logplot_b


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6


% --- Executes on button press in fitrange_b.
function fitrange_b_Callback(hObject, eventdata, handles)

% hObject    handle to fitrange_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/data_I.mat'],'data_I')

plotfit_b_Callback(hObject, eventdata, handles)

[x y but]=ginput(2);
x=sort(x);

datainstr=get(handles.data_instr_b,'value');
if datainstr==1
    adjtth=abs(data(:,1)-x(1));
    minpos=find(adjtth==min(adjtth));
    adjtth=abs(data(:,1)-x(2));
    maxpos=find(adjtth==min(adjtth));
    data=data(minpos:maxpos,:);
else
    adjtth=abs(data_I(:,1)-x(1));
    minpos=find(adjtth==min(adjtth));
    adjtth=abs(data_I(:,1)-x(2));
    maxpos=find(adjtth==min(adjtth));
    data_I=data_I(minpos:maxpos,:);
end

plotfit_b_Callback(hObject, eventdata, handles)
save([cd,'/0. variables/data.mat'],'data')

% --- Executes on button press in kpos_b.
function kpos_b_Callback(hObject, eventdata, handles)
% hObject    handle to kpos_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of kpos_b

load([cd,'/0. variables/phases.mat'],'dsettings')



val=get(handles.indexres_l,'value');
datainstr=get(handles.data_instr_b,'value');
phase=get(handles.phaseres_l,'value');
if datainstr==1
    load([cd,'/0. variables/fit.mat'],'aa','aabcg')
    if phase==2
        val=val+length(dsettings(1,1).d);
    end
    [x y but]=ginput(1);
    aa(1,val)=x;
    aa(2,val)=y;
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
else
    load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    [x y but]=ginput(1);
    aa_I(1,val)=x;
    aa_I(2,val)=y;
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
end
    
   plotfit_b_Callback(hObject, eventdata, handles);
   set(hObject,'value',0)


% --- Executes on button press in bcgindi_b.
function bcgindi_b_Callback(hObject, eventdata, handles)
 
% hObject    handle to bcgindi_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of bcgindi_b

load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/data_I.mat'])
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')


datainstr=get(handles.data_instr_b,'value');
peakno=get(handles.indexres_l,'value');
val=get(handles.phaseres_l,'value');
if val==2 && datainstr==1
    peakno=length(dsettings(1,1).d)+peakno;
end

[x y]=ginput(1);
switch datainstr
    case 1
        mnuu=1
%          mnuu=menu('choose','up and down','a line');
         if mnuu==1
             lam0=aa;
             lam0(:,peakno)=zeros(size( lam0(:,peakno)));
             IFT=pv_tv_aa(lam0,data(:,1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:,1));
             %fit of everything but the peak including bcg indi
             adjtth=abs(data(:,1)-aa(1,peakno));
             peakpos=find(adjtth==min(adjtth));
             aabcg(1,peakno)=y-IFT(peakpos)+aabcg(1,peakno);
         else
             lam0=aa;
             lam0(:,peakno)=zeros(size( lam0(:,peakno)));
             IFT=pv_tv_aa(lam0,data(:,1))+pv_tv_aa([aabcg(:,peakno);0;0],data(:,1));
             adjtth=abs(data(:,1)-aa(1,peakno));
             peakpos=find(adjtth==min(adjtth));
             aabcg(1,peakno)=y-IFT(peakpos)+aabcg(1,peakno);
         end
    case 2
         lam0=aa_I;
         lam0(:,peakno)=zeros(size( lam0(:,peakno)));
         IFT=pv_tv_aa(lam0,data_I(:,1))+pv_tv_aa([aabcg_I(:,peakno);0;0],data_I(:,1));
         adjtth=abs(data_I(:,1)-aa_I(1,peakno));
         peakpos=find(adjtth==min(adjtth));
         aabcg_I(1,peakno)=y-IFT(peakpos)+aabcg_I(1,peakno);
end

save([cd,'/0. variables/fit.mat'],'aa','aabcg')
save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
indexres_l_Callback(hObject, eventdata, handles)


% --- Executes on button press in selindivfit_b.
function selindivfit_b_Callback(hObject, eventdata, handles)
% hObject    handle to selindivfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selindivfit_b


% --- Executes on button press in FW_IB_b.
function FW_IB_b_Callback(hObject, eventdata, handles)


% --- Executes on button press in mwh_wh_b.
function mwh_wh_b_Callback(hObject, eventdata, handles)
% hObject    handle to mwh_wh_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mwh_wh_b


% --- Executes on button press in plotWH_b.
function plotWH_b_Callback(hObject, eventdata, handles)
modq=get(handles.mwh_wh_b,'value');
load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/fit_I.mat'])
load([cd,'/0. variables/phases.mat'])

load([cd,'/0. variables/phases.mat'])
axes(handles.axes1),if ishold==1;hold;end
% lenaa=length(aa)-1;
FWq=get(handles.FW_IB_b,'value');

index=num2str(dsettings(1).index);
inda=get(handles.WHselected_l,'string');
h=1;
for n=1:size(inda,1)
    for m=1:size(index,1)
        index_=index(m,find(index(m,:)~=' '));
        inda_=inda(n,find(inda(n,:)~=' '));
       if strcmp(inda_,index_)==1
           select(h)=m;
           h=h+1;
           break
       end
    end
    
end

if FWq==0
    if size(aa,1)==6
    aa(3,select)=0.5*(aa(3,select)+aa(5,select));
    end
    fw_r=(aa(3,select).^2-aa_I(3,1).^2).^.5;
    textFW='real FW';
else
    if size(IB_,1)~=0
        fw_r=IB_;
        textFW='real IB';
    else
         if size(aa,1)==6
            aa(3,select)=0.5*(aa(3,select)+aa(5,select));
         end
    
        fw_r=(aa(3,select).^2-aa_I(3,1).^2).^.5;
        textFW='real FW not IB';
    end
end

if modq==0
    plot(aa(1,select),fw_r,'o','markersize',5,'linewidth',5)
    title(['WH PLOT',textFW],'fontsize',20)
else
    
    q=str2num(get(handles.WHq_t,'string'));
    if strcmp(dsettings(1).cstruct(1),'4')==1
        q2=str2num(get(handles.q2_t,'string'));
        l=dsettings(1).index(select,3);
        xXx=(2/3)*((l./(aa(1,select)'*2.95)).^2);
        C=(1+q*xXx + q2*xXx.^2)'  ;  
    else
        H2=Hsq(dsettings(1,1).index(select,:));
        C=0.3*(1-q*H2);
    end
    texta=['MOD WH PLOT: ',textFW];
    
    
    plot(aa(1,select).^2.*C,fw_r,'om','markersize',5,'linewidth',5)
    title(texta,'fontsize',20)
end

function sampleid2_t_Callback(hObject, eventdata, handles)

% hObject    handle to sampleid2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampleid2_t as text
%        str2double(get(hObject,'String')) returns contents of sampleid2_t as a double
load([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')
ident=get(hObject,'String');
save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')


% --- Executes during object creation, after setting all properties.
function sampleid2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampleid2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in asymm_b.
function asymm_b_Callback(hObject, eventdata, handles)
 
% hObject    handle to asymm_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of asymm_b
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
value=get(hObject,'Value');
if value==1
    if value==1 && size(aa,1)==4
        aa(5:6,:)=aa(3:4,1:end);
        
    end
    if value==1 && size(aa_I,1)==4
        aa_I(5:6,:)=aa_I(3:4,1:end);
    end
else
    aa=aa(1:4,:);
    aa_I=aa_I(1:4,:);
    
end

instr=get(handles.data_instr_b,'value');
if instr == 2
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
elseif instr == 1   
    save([cd,'/0. variables/fit.mat'],'aa','aabcg')
end


% --- Executes on button press in getIB_b.
function getIB_b_Callback(hObject, eventdata, handles)

% hObject    handle to WHfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/data_I.mat'],'data_I')
load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/WHres.mat'])
load([cd,'/0. variables/genset.mat'])

delK=bcg2peak;
index=num2str(dsettings(1).index);
inda=get(handles.WHselected_l,'string');
h=1;
for n=1:size(inda,1)
    for m=1:size(index,1)
        index_=index(m,find(index(m,:)~=' '));
        inda_=inda(n,find(inda(n,:)~=' '));
       if strcmp(inda_,index_)==1
           select(h)=m;
           h=h+1;
           break
       end
    end
    
end


[I_all]=steel_findfourier( aa,aabcg, data, aa_I,aabcg_I, data_I,35,1,dsettings);



for nnn=1:length(I_all(1,:,1))
   
        
        
        IIfit= I_all(:,nnn,1) ;        
        
        incre=5e-06;
        IB=0;
        for n=1:length(xi)-1
        IB=IB+  IIfit(n)*incre +incre*0.5* (IIfit(n+1)-IIfit(n));
        end
        IB=IB/max(IIfit);
        
        IB_(nnn)=IB;
        
        
end
IB_
plot(aa(1,select),IB_,'ok'),hold

plot(aa(1,select),aa(3,select),'or')

save([cd,'/0. variables/WHres.mat'],'IB_','WHres','fw_r')

set(handles.delK_t,'string', num2str(delK));

% --- Executes on button press in WHfit_b.
function WHfit_b_Callback(hObject, eventdata, handles)

% hObject    handle to WHfit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/fit_I.mat'])
load([cd,'/0. variables/WHres.mat'])

cubhex=str2num(dsettings(1).cstruct(1));

index=num2str(dsettings(1).index);
inda=get(handles.WHselected_l,'string');
h=1;
for n=1:size(inda,1)
    for m=1:size(index,1)
        index_=index(m,find(index(m,:)~=' '));
        inda_=inda(n,find(inda(n,:)~=' '));
       if strcmp(inda_,index_)==1
           select(h)=m;
           h=h+1;
           break
       end
    end
    
end

mwhq=get(handles.mwh_wh_b,'value');
if  mwhq==0
    for n=1:size(dsettings(1).index(:,:),1)
    dsettings(1).index(n,:)=[ 1 0 0];
    end
end


FWq=get(handles.FW_IB_b,'value');
if FWq==0
    if size(aa,1)==6
        aa(3,select)=0.5*(aa(3,select)+aa(5,select));
    end
    
    
    
    for no=1:length(select)
        k1=aa(1,select(no));
        kmink=abs( aa_I(1,:)-k1  );
        select_I(no)=find(kmink==min(kmink));
    end
    if size(aa_I,1)==6
        aa_I(3,select_I)=0.5*(aa_I(3,select_I)+aa_I(5,select_I));
    end
    
    fw_r=(aa(3,select).^2-aa_I(3,select_I).^2).^.5;
    
    if cubhex==4
        WHres=WHhcp_new(fw_r,aa(1,select)', dsettings(1,1).index(select,:) );
    else
        WHres=WH(fw_r,aa(1,select), dsettings(1,1).index(select,:) );
    end
    
else
    if exist('IB')~=1
        if size(aa,1)==6
            aa(3,select)=0.5*(aa(3,select)+aa(5,select));
        end
        IB_=(aa(3,select).^2-aa_I(3,1).^2).^.5;
    end
    if size(IB_,1)>=max(select)
        if cubhex==4
            WHres=WHhcp_new(IB_(select),aa(1,select)', dsettings(1,1).index(select,:) );
        else
            WHres=WH(IB_(select),aa(1,select), dsettings(1,1).index(select,:) );
        end
        
    else
        if size(aa,1)==6
            aa(3,select)=0.5*(aa(3,select)+aa(5,select));
        end
        fw_r=(aa(3,select).^2-aa_I(3,1).^2).^.5;
        if cubhex==4
            WHres=WHhcp_new(fw_r,aa(1,select)', dsettings(1,1).index(select,:) );
        else
            WHres=WH(fw_r,aa(1,select), dsettings(1,1).index(select,:) );
        end
    end
    
    
    
end
;
if mwhq~=0
    MWHres=WHres;
    load([cd,'/0. variables/WHres.mat'],'WHres')
    set(handles.WHq_t,'string', MWHres(1,1) )
    set(handles.variancegs_t,'string', MWHres(1,2) )
    set(handles.variancermss_t,'string', MWHres(1,3)*1e3 )
    if cubhex==4
        set(handles.q2_t,'string', MWHres(1,4) )
    end
else
    load([cd,'/0. variables/WHres.mat'],'MWHres')
    set(handles.WHq_t,'string', WHres(1,1) )
    set(handles.variancegs_t,'string', WHres(1,2) )
    const=2*sqrt(2*pi);
    set(handles.variancermss_t,'string', 1e3*WHres(1,3)/const )
    if cubhex==4
        set(handles.q2_t,'string', WHres(1,4) )
    end
end
k=aa(1,select);

save( [cd,'/0. variables/WHres.mat'],'IB_','WHres','fw_r','MWHres','k')




% --------------------------------------------------------------------
function load_m_Callback(hObject, eventdata, handles)
% hObject    handle to load_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load_b_Callback(hObject, eventdata, handles);

% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function loadsettings_m_Callback(hObject, eventdata, handles)
% hObject    handle to loaddsettings_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function loadinstr_m_Callback(hObject, eventdata, handles)
% hObject    handle to loadinstr_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function savefit_m_Callback(hObject, eventdata, handles)
% hObject    handle to savefit_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function saveinstr_m_Callback(hObject, eventdata, handles)
% hObject    handle to saveinstr_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function saveres_m_Callback(hObject, eventdata, handles)
% hObject    handle to saveres_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function settings_m_Callback(hObject, eventdata, handles)
% hObject    handle to dsettings_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
settings_b_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function instrumental_m_Callback(hObject, eventdata, handles)
% hObject    handle to instrumental_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
instr_b_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function Untitled_7_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_8_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function fit_m_Callback(hObject, eventdata, handles)
% hObject    handle to fit_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

results_b_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function WH_m_Callback(hObject, eventdata, handles)
% hObject    handle to WH_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
WH_b_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function fourierBCC_m_m_Callback(hObject, eventdata, handles)
% hObject    handle to fourierBCC_m_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fourier_b_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function Untitled_9_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_10_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in plusphase_b.
function plusphase_b_Callback(hObject, eventdata, handles)
%  
% hObject    handle to plusphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat')
LL=length(dsettings)+1;
    dsettings(1,LL).lambda=dsettings(1,1).lambda;
    dsettings(1,LL).id=dsettings(1,1).id;
    dsettings(1,LL).alpha2=dsettings(1,1).alpha2;
    NAME=input('Enter phase name \n','s');
    LEN=length(NAME);SP='      ';
    if LEN<6; NAME=[NAME,SP(1:6-LEN)];elseif LEN>6;NAME=NAME(1:6);end
    dsettings(1,LL).name=NAME;
    for n=1:LL;NOM{n}=dsettings(1,n).name;end
    set(handles.phase_l,'string',NOM)
    dsettings(1,LL).index=[0 0 0];
    dsettings(1,LL).cstruct=dsettings(1,1).cstruct;
     set(handles.index_l,'string',num2str(dsettings(1,LL).index))

save('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat','dsettings')

% --- Executes on button press in reduceset_b.
function reduceset_b_Callback(hObject, eventdata, handles)
%   
% hObject    handle to reduceset_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/data.mat'],'data')
axes(handles.axes1)
if ishold==1;hold;end
semilogy(data(:,1),data(:,2))
[x y]=ginput(2);
x=sort(x);
pos1=find(abs( data(:,1)-x(1) ) ==min( abs( data(:,1)-x(1) ) )   );
pos2=find(abs( data(:,1)-x(2) ) ==min( abs( data(:,1)-x(2) ) )   );
data=data(pos1:pos2,:);
semilogy(data(:,1),data(:,2))

dsettings2=dsettings;

MAX=max(data(:,1));MIN=min( data(:,1) );
for n=1:length(dsettings)
    h=1;
    for nn=1:length(dsettings(1,n).d)
        if nn==1;dsettings2(1,n).d=[];dsettings2(1,n).index=[];end
        k=1./dsettings(1,n).d(nn);
        if k>MIN && k<MAX
            dsettings2(1,n).d(h)=dsettings(1,n).d(nn);
            h,nn,n
            dsettings2(1,n).index(h,:)=dsettings(1,n).index(nn,:);
        h=h+1;
        end
        
    end
end
dsettings=dsettings2;
set(handles.index_l,'string',num2str(dsettings(1,1).index))
set(handles.phase_l,'value',1)


% --- Executes on button press in deleteaa_b.
function deleteaa_b_Callback(hObject, eventdata, handles)
% 
% hObject    handle to deleteaa_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa=[];


% --- Executes on selection change in popupmenu7.
function popupmenu7_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu7 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu7


% --- Executes during object creation, after setting all properties.
function popupmenu7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in manindex_b.
function manindex_b_Callback(hObject, eventdata, handles)
% hObject    handle to manindex_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat')


    index_all=str2num( get(handles.index_l,'string') );
    nn=get(handles.phase_l,'value');
    valll=get(handles.index_l,'value');
    indexlen=size(index_all,1);
    [x y]=ginput(1);
    dsettings(1,nn).d(valll)=1/x;
    dsettings(1,nn).index(valll,:)=[0 0 0];

    set(handles.index_l,'string',num2str(index_all) )




save('/Users/user/Documents/MATLAB/5. New Steelfit/0. variables/phases.mat','dsettings')


% --- Executes on button press in newphase_b.
function newphase_b_Callback(hObject, eventdata, handles)
% hObject    handle to newphase_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.phase_l,'value',1)
set(handles.index_l,'value',1)
set(handles.symm_l,'value',1)

go=input('Do you want to enter new sample details y/n ? (Will delete current details):       ','s');
if go(1)=='y' || 'Y'
    str1=input('Enter name of sample    ','s');
    dsettings(1).id=str1;
    num=input('Enter number of different crystal phases       ');
    for n=1:num
        str1=input(['Enter name of phase ',num2str(n),'   '],'s');
        dsettings(n).name=str1;
        num2=input('Enter crystal structure, 1-fcc, 2-bcc, 3-hexagonal   ');
        dsettings(n).cstruct=num2+1;
        str1=input('Enter lattice parameter   ');
        dsettings(n).lat1=str1;
        
        num3=input('Enter indices of peaks (e.g. [1 1 1;2 0 0]  ');
        dsettings(n).index=num3;
        if num2==3
            str1=input('Enter 2nd lattice parameter (c)   ','s');
            dsettings(n).lat2=str1;
            dsettings(n).d=dspacing(dsettings(n).index, 'hex', 1,dsettings(n).lat1, dsettings(n).lat2);
        else
            dsettings(n).lat2=0;
            dsettings(n).d=dspacing(dsettings(n).index, 'cub', 1,dsettings(n).lat1, dsettings(n).lat2);
        end
    end
    yorno=input('Is this okay?','s');
    if yorno(1)=='y' || 'Y'
    save([cd,'/0. variables/phases.mat'],'dsettings')
    end
end
for n=1:length(dsettings)
    phas{n}=dsettings(n).name;
    sym{n}=dsettings(n).cstruct;
end
set(handles.phase_l,'string',phas)
set(handles.phase_l,'value',1)
set(handles.symm_l,'string',sym)
set(handles.lat1_t,'string',dsettings(1).lat1)
set(handles.name_t,'string',dsettings(1).id)
set(handles.index_l,'string',num2str(dsettings(1).index))












% --- Executes on selection change in batchmenu_l.
function batchmenu_l_Callback(hObject, eventdata, handles)
% hObject    handle to batchmenu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns batchmenu_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from batchmenu_l
load([cd,'/0. variables/phases.mat'],'dsettings')
select=get(hObject,'Value');
load([cd,'/0. variables/8/hrpdbatch.mat'])
lenval=length(val{1});if lenval>11;lenval=12;end

figure(10)
%%%
detav=1;


for n=1:length(val)
    val{n}=val{n};
    for nn=1:length( val{n} )
        gs{n}(nn,:)=1./ ( IB{n}(nn,1)*( k{n}(nn,1)-k{n}(nn,5) )/(IB{n}(nn,1)-IB{n}(nn,5))  );
        
    end
    
end
% val2=val2-offset;
% val2=val2+offset+45;
% val=val-offset-45;
col={'o-';'s--';'p:';'<-.';'o-';'s--';'p:';'<-.'};

col1={'-','-','-','-','-';'--','--','--','--','--';':',':',':',':',':';'-.','-.','-.','-.','-.';'-','-','-','-','-';'--','--','--','--','--';':',':',':',':',':';'-.','-.','-.','-.','-.'};
col2={'bo';'g+';'r<';'c>';'ys';'bo';'g+';'r<';'c>';'ys'};
val2=[];
pksfit=get(handles.frstpeak_b,'value');
if pksfit==0
    pklen=5;
    strtpk=1;
else
    pklen=5+5;
    strtpk=1+5;
end
% figure(1)
if ishold==1;hold;end
switch select
    case 2%%%%%strain
        fw_k=strain;
        fila='strain';
        for bn=1:length(fw_k);
            fw_k{bn}=1e6*fw_k{bn};
%             FWZ=fw_k{bn}(1,:);
%             for bnn=1:size(fw_k{bn},1)               
%                 fw_k{bn}(bnn,:)=fw_k{bn}(bnn,:)-FWZ;
%             end
            
        end
    case 3
        fw_k=fw;
        
        fila='fw';
%         for bn=1:length(fw_k);
%             val{bn}=180-val{bn};
%             for bnn=1:size(fw_k{bn},1)
%               
%                 fw_k{bn}(bnn,:)=fw_k{bn}(bnn,:)-2*[ .15e-3  .3e-3 .15e-3 .3e-3 .2e-3 .3e-3 .1e-3 .1e-3 .3e-3 .15e-3]*cos(val{bn}(bnn)*pi/360).^2;
%             end
%             val{bn}=180-val{bn};
%         end
        
    case 4
        fw_k=neta;
        fila='neta';
    case 5
        fw_k{1}=fw{1}(:,2);%IB_k;
%         fw_k=
        fila='IBfc';
%         for n=1:length(fw_k)
%             fw_k{n}=fw_k{n}/(2*.5/0.015);
%         end
    case 6
        fw_k=beta_k;
        fila='IB';
        
    case 7
        fw_k=I;
%         fila='I'
%         for n=1:length(fw_k)
%             fw_k{n}=fw_k{n}.*beta_k{n};
%         end
        
    case 8
%         grad=fw_k
        fw_k=ASY;
        
        fila='asy';
    case 9
        
        for n=1:length(fw_k)
            fw{n}=IB{n};
            grad{n}(:,1)=( fw{n}(:,1)-fw{n}(:,5) )./(( k{n}(:,1).^2-k{n}(:,5).^2 ));
            grad{n}(:,2)=( fw{n}(:,2)-fw{n}(:,6) )./(( k{n}(:,2).^2-k{n}(:,6).^2 ));
            sz{n}(:,1)=-grad{n}(:,1).*k{n}(:,5).^2+fw{n}(:,5);
            sz{n}(:,2)=-grad{n}(:,2).*k{n}(:,5).^2+fw{n}(:,5);
        end
        pklen=2;
        strtpk=1;
        fw_k=sz;
    case 10
        
        for n=1:length(fw_k)
            fw{n}=IB{n};
            grad{n}(:,1)=( fw{n}(:,1)-fw{n}(:,5) )./(( k{n}(:,1).^2-k{n}(:,5).^2 ));
            grad{n}(:,2)=( fw{n}(:,2)-fw{n}(:,6) )./(( k{n}(:,2).^2-k{n}(:,6).^2 ));
            sz{n}(:,1)=-grad{n}(:,1).*k{n}(:,5).^2+fw{n}(:,5);
            sz{n}(:,2)=-grad{n}(:,2).*k{n}(:,5).^2+fw{n}(:,5);
        end
        pklen=2;
        strtpk=1;
        fw_k=grad;
        
    case 11
        for nn=1:size(fw{1},1)
            for m=1:size(fw{1},2)
           
                [betaC{1}(nn,m) betaG{1}(nn,m)]=PV2Voigt(fw{1}(nn,m),neta{1}(nn,m));
                
            end
        end
       
        fw_k=betaC;
        
    case 12
        for nn=1:size(fw{1},1)
            for m=1:size(fw{1},2)
           
                [betaC{1}(nn,m) betaG{1}(nn,m)]=PV2Voigt(fw{1}(nn,m),neta{1}(nn,m));
                
            end
        end
       
        fw_k=betaG;
end
       
 FWall=[];
if select==3 || select==5  || select==6   %|| select==2  
    
       
        if detav==1
            adj_m=[];
            for bbb=1:length(fw_k)
                adj{bbb}=mean(fw_k{bbb});
                for bbbc=1:size(fw_k{bbb},2)
                    fw_k{bbb}(:,bbbc)=fw_k{bbb}(:,bbbc)-adj{bbb}(bbbc);
                end
                if bbb==1
                   adj_m=adj{bbb}; 
                else
                adj_m=adj{bbb}+adj_m;
                end
            end
%            adj{3}=adj{1};
%            adj{4}=adj{2};
           adj_m=adj_m/bbb;
           for bbb=1:length(fw_k)
               for bbbc=1:size(fw_k{bbb},2)
                   fw_k{bbb}(:,bbbc)=fw_k{bbb}(:,bbbc)+adj_m(bbbc);%-adj{bbb}(bbbc);
               end
           end
            
        end
        
end
                
        if size(fw_k{n},1)>0
%             for nm=1:length(detector)
                n=1;
                if size(val{n},1)==1;
                    val{n}=val{n}';
                end
                FW=[val{n},fw_k{n}];
                FW=[val{n},fw_k{n}];
                 
%                 ang=180-FW(:,1);%new change
                    ang=FW(:,1);%new change
                FWall=[FWall;FW];
                
                FW(:,1)=ang;
                
%                 FW(:,1)=1:1:length(FW(:,1));
                
                FW=FW(:,1:end);
                FW=sortrows(FW);
                
             
                
%                 ang_val=find(ang>90 & ang<180);
%                 ang(ang_val)=180-ang(ang_val);
%                 
%                 ang_val=find(ang>180 & ang<180+90);
%                 ang(ang_val)=ang(ang_val)-180;
%                 
%                 ang_val=find(ang>270 & ang<400);
%                 ang(ang_val)=360-ang(ang_val);
                
%             if size(FW,2)>8
                    hh=1;
                    
                    
%                     strtpk=3;
%                     pklen=3;
                    
                    
                    for pp=strtpk:pklen
                        FW(:,1+pp),[char(col2(hh,:))]
                    plot(FW(:,1),FW(:,1+pp),[char(col2(hh,:))]','linewidth',2,'markersize',9),
%                       plot(FW(:,1),FW(:,1+pp),[char(col2(pp,:))]','linewidth',2,'markersize',13),
                    if ishold~=1;hold;end
                    hh=hh+1;
                    end
                
%             else
%                 plot(FW(:,1),FW(:,2:end),[char(col1{n,:}),char(col2)]),
%             end
    %     xlim([90 180])
    
    switch select
        case 2
            ylabel('Strain','fontsize',20)
        case 3
            ylabel('FW / k','fontsize',20)
        case 4
            ylabel('neta','fontsize',20)
        case 5
            ylabel('integral breadth / k','fontsize',20)
        case 6
            ylabel('integral breadth / k','fontsize',20)
        case 7
            ylabel('intensity','fontsize',20)
        case 8
            ylabel('Asymmetry','fontsize',20)
            
    end
            
                
                
                if ishold~=1;hold;end
            
        end
%         set(gca,'linewidth',3)
    
   
grid
% xlim([-4 94])

% plot([180, 180; 90 90]',[min(FW(:,3)),max(FW(:,3));min(FW(:,3)),max(FW(:,3))]')
% xlim([70 190])
title(file)

set(gca,'fontsize',20)
legend(num2str(dsettings(1).index(strtpk:pklen,:)),'Location','EastOutside')

FWall=sortrows(FWall);
npp=1;np=1;
while npp<=size(FWall,1)-1
   FWallS(np,:)=0.5*(FWall(npp,:)+FWall(npp+1,:));npp=npp+2; np=np+1;
%     FWallS(np,:)=0.5*(FWall(npp,:)+FWall(npp+1,:));npp=npp+2; np=np+1;
    
end

if get(handles.print_b,'value')==1
    % for np=1:(size(FWall,1)-1)
    %     
    %     
    %      FWallS(np,:)=0.5*(FWall(np,:)+FWall(np+1,:));
    % end

    % FWallS=[FWallS(:,1),FWallS(:,6:11)];
    h8=figure(8);
    if ishold==1;hold;end
    
    %%change for 2nd data
%     FWallS(:,1)=180- FWallS(:,1);
    
    
    % FWallS(:,1)=90-FWallS(:,1);%for Ni30
    hh=1;
    for pp=strtpk:pklen
                    plot(FWallS(:,1),FWallS(:,1+pp),[char(col1{n,hh}),char(col2(hh,:))]','linewidth',2,'markersize',9),
                    if ishold~=1;hold;end
                    hh=hh+1;

    end

    switch select
            case 2
                ylabel('Strain','fontsize',20)
            case 3
                ylabel('FW / k','fontsize',20)
            case 4
                ylabel('neta','fontsize',20)
            case 5
                ylabel('integral breadth / k','fontsize',20)
            case 6  
                ylabel('integral breadth / k','fontsize',20)
            case 7
                ylabel('intensity','fontsize',20)
            case 8
                ylabel('Asymmetry','fontsize',20)

    end

    % title(file)
    legend(num2str(dsettings.index(strtpk:pklen,:)),'Location','EastOutside')
    set(gca,'fontsize',20)
    xla={'Angle between the tensile direction'; 'and the diffraction vector g'}
    xlabel(xla)
    xlim([-4 94])
    grid

%%%%%%%%%%%%%%%%%%%%%

%     FWall(:,1)=180- FWall(:,1);
    ang=FWall(:,1);
    step1=-5:5:85;
    step2=step1+10;
    
    % step1=0:8:104;step1=step1-7;
    % step2=step1+8*2;
    
    njj=1;
    for nj=1:length(step1)
        ang_in=find(ang>= step1(nj) & ang<=step2(nj));
        if size(ang_in,1)~=0
            if length(ang_in)==1
                ang_in=[ang_in; ang_in];
            end
        ang_val{njj}=ang_in;
        njj=njj+1;
        end
    end
    FWallS=[];
    for nj=1:length(ang_val)
        nj
        FWallS(nj,:)=mean(FWall(ang_val{nj},:));
    end
    
    
    figure(88)
    if ishold==1;hold;end
    for pp=1:pklen
                    plot(FWallS(:,1),FWallS(:,1+pp),[char(col1{n,pp}),char(col2(pp,:))]','linewidth',2,'markersize',9),
                    if ishold~=1;hold;end
                    
    end
    %%%%%%%%%%%%%%%%%%
    FWmeandet=zeros(size(fw_k{1},1),size(fw_k{1},2));
        for ppp=1:size(fw_k{1},1)
           
            FWmeandet(ppp,:)=.5*(fw_k{2}(ppp,:)+fw_k{1}(ppp,:));
            valall(ppp)=0.5*(val{1}(ppp)+val{2}(ppp));
        end
        valall=180-valall;
        FWmeandet=[valall',FWmeandet];
        FWmeandet=sortrows(FWmeandet);
        figure(10)
        
        if ishold==1;hold;end
    for pp=1:pklen
                    plot(FWmeandet(:,1),FWmeandet(:,1+pp),[char(col1{n,pp}),char(col2(pp,:))]','linewidth',2,'markersize',9),
                    if ishold~=1;hold;end
                    
    end
    %%%%%%%%%%%%%%%%%
    
    switch select
            case 2
                ylabel('Strain','fontsize',20)
            case 3
                ylabel('FW / k','fontsize',20)
            case 4
                ylabel('neta','fontsize',20)
            case 5
                ylabel('integral breadth / k','fontsize',20)
            case 4
                ylabel('Asymmetry','fontsize',20)
                
    end
        
    % title(file)
    legend(num2str(dsettings.index(1:pklen,:)),'Location','EastOutside')
    set(gca,'fontsize',20)
    xlabel('Angle between the tensile direction and the diffraction vector g')
    xlim([-4 94])


    
    %%%%%%%%%%%%%%%%%%%%%%

    pkstrt=6;
    FWallS=[FWallS(:,1),FWallS(:,pkstrt+1:end)];
    h9=figure(9);
    if ishold==1;hold;end

    % FWallS(:,1)=90-FWallS(:,1);%for Ni30
    for pp=1:5
                    plot(FWallS(:,1),FWallS(:,1+pp),[char(col1{n,pp}),char(col2(pp,:))]','linewidth',2,'markersize',9),
                    if ishold~=1;hold;end

    end
    
    
        
        
    switch select
            case 2
                ylabel('Strain','fontsize',20)
            case 3
                ylabel('FW / k','fontsize',20)
            case 4
                ylabel('neta','fontsize',20)
            case 5
                ylabel('integral breadth / k','fontsize',20)
            case 6
                ylabel('integral breadth / k','fontsize',20)
            case 7
                ylabel('intensity','fontsize',20)
            case 8
                ylabel('Asymmetry','fontsize',20)

    end




    % title(file)
    legend(num2str(dsettings.index(pkstrt:end,:)),'Location','EastOutside')
    set(gca,'fontsize',20)
    xla={'Angle between the tensile direction'; 'and the diffraction vector g'};
    xlabel(xla)
    xlim([-4 94])
    grid
    
    set(h8,'PaperPositionMode','auto')
    set(h8,'InvertHardcopy','on')
    set(h8,'Papersize',[10 10 ])
    
    set(h9,'PaperPositionMode','auto')
    set(h9,'InvertHardcopy','on')
    set(h9,'Papersize',[10 10 ])
%     set(gcf,'InvertHardcopy','off');;'-loose', '-noui',
    spath=[cd,'/2. data/hdrp data/0 figures/2.fw_etc/'];
    spath=[spath,file(1:end-4),'_',fila];
    print('-f8', '-r120','-dpng', [spath,'_A'])
    print('-f9', '-r120','-dpng', [cd,'/_B'])
end



set(hObject,'Value',1)
% --- Executes during object creation, after setting all properties.
function batchmenu_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to batchmenu_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function batchres_m_Callback(hObject, eventdata, handles)
% hObject    handle to batchres_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.batchres_p,'visible','on')


% --- Executes on button press in batchdone_b.
function batchdone_b_Callback(hObject, eventdata, handles)
% hObject    handle to batchdone_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.batchres_p,'visible','off')





% --- Executes on selection change in detector_l.
function detector_l_Callback(hObject, eventdata, handles)
% hObject    handle to detector_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns detector_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from detector_l


% --- Executes during object creation, after setting all properties.
function detector_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to detector_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in indivfitasymm_b.
function indivfitasymm_b_Callback(hObject, eventdata, handles)

% hObject    handle to refit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% plotraw_b_Callback(hObject, eventdata, handles)
% delK=0.025;

load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'],'alpha2','tube')




n=get(handles.indexres_l,'value');%which peak to fit
datainstr=get(handles.data_instr_b,'value');%%Inst(2) or not(1)
val=get(handles.phaseres_l,'value');%phase 
if val==2 && datainstr==1
    n=length(dsettings(1,1).d)+n;
end

fitsiz=str2num( get(handles.sizfit_t,'string') );


        
        load([cd,'/0. variables/data.mat'],'data')
        load([cd,'/0. variables/fit.mat'],'aa','aabcg')
        
        incretth=data(2,1)-data(1,1);
        incretth=double( int16(incretth/1e-5 ))*1e-05;
        posdelK=fitsiz/incretth;
        aa2=aa;
        adjtth=abs(data(:,1)-aa(1,n));
        peakpos=find(adjtth==min(adjtth));
        clear adjtth
        I=data(:,2) ;
        
        
        %% find area to fit from size of interval given
        posb4=peakpos-posdelK;if posb4<1;posb4=1 ;end
        posa4=peakpos+posdelK;if posa4>size(data,1);posa4=size(data,1);end
        I=I(posb4:posa4);

        delxp=abs( aa(1,:)-aa(1,n) );    
        aapos=find( delxp<fitsiz );
        lenaa=size(aa,2);

        fpos=find(aapos==n);%which peak is changing
 
        aapos(end+1)=lenaa;
        tth=data((posb4:posa4), 1);
        %I={rawdata}+{fit of peak}-{fit of all}    i.e. a fit of this
        %should include aa_of peak and aabcg of peak only
        I  =  I + pv_tv_aa([aa2(:,aapos(1:end-1)),zeros(size(aa(:,1)))],data((posb4:posa4), 1)) -  pv_tv_aa(aa2(:,:),data((posb4:posa4), 1));
        
        aa(1:4,lenaa)=[I(1) 0 0 fpos]';
%         lam0=aa(:,aapos);
        aa(1:2,end)=aabcg(:,aapos(fpos(1)));
        
        %%fit data
        aaB=aa;
        if size(aa,1)~=6
        aaB(5:6,:)=aa(3:4,:);
        end
        aaB(:,aapos)=onepeak_asymm(tth, I, aaB(:,aapos));
        aa=aaB;
        
        IIfit=pv_tv_aa(aa(:,:),data((posb4:posa4), 1));
        if ishold==1;hold;end
        logplot=get(handles.logplot_b,'value');
        if logplot==0
            plot(data(posb4:posa4,1),I),hold
        else
            semilogy(data(posb4:posa4,1),I),hold
        end
        plot(tth,IIfit,'m')
        aabcg(:,n)=aa(1:2,lenaa);

        aa(1:4,end)=aa2(1:4,end);

        
        save([cd,'/0. variables/fit.mat'],'aa','aabcg')
        


% --- Executes on button press in group6_b.
function group6_b_Callback(hObject, eventdata, handles)
% hObject    handle to group6_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of group6_b


% --- Executes on button press in addI_b.
function addI_b_Callback(hObject, eventdata, handles)


% hObject    handle to loadfitmenu_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



[FileName,PathName] = uigetfile('*.mat','Select the Instrumental file',[cd,'/2. data/hrpd/1.hrpd batch/'])

load([PathName,FileName],'fita')


for n=1:length(fita)
nom{n}=fita(1,n).name;
fita(n).val=185;
end
fita_I=fita;

[FileName,PathName] = uigetfile('*.mat','Select the Fit file',[cd,'/2. data/hrpd/1.hrpd batch/'])

load([PathName,FileName],'fita')
LENF=length(fita);
fna=fieldnames(fita);
fna2=fieldnames(fita_I);
% lenF=max([length(fna),length(fna2)]);
for m=1:length(fita_I)
    n=m+LENF;
    fita(n).aa=fita_I(m).aa;
    fita(n).aabcg=fita_I(m).aabcg;
    fita(n).data=fita_I(m).data;
    fita(n).val=fita_I(m).val;
    fita(n).name=fita_I(m).name;
    fita(n).alpha2=fita_I(m).alpha2;
    fita(n).IB=fita_I(m).IB;

end

save([PathName,FileName],'fita')


% --- Executes on button press in frstpeak_b.
function frstpeak_b_Callback(hObject, eventdata, handles)
% hObject    handle to frstpeak_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of frstpeak_b


% --- Executes on button press in print_b.
function print_b_Callback(hObject, eventdata, handles)
% hObject    handle to print_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of print_b


% --- Executes on selection change in load_l.
function load_l_Callback(hObject, eventdata, handles)
% hObject    handle to load_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load_l


% --- Executes during object creation, after setting all properties.
function load_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadlist_b.
function loadlist_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadlist_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/load_fnames.mat'],'FileName','PathName')
load([PathName,FileName],'fita')
load([cd,'/0. variables/genset.mat'])

sel=get(handles.load_l,'value');
identa=fita(1,sel).name;set(handles.sampleid2_t,'string',identa)
aa=fita(1,sel).aa;
data=fita(1,sel).data;
alpha2=fita(1,sel).alpha2;
tube=fita(1,sel).instr;
% aabcg=[];
fnoms=fieldnames(fita(1,sel));
existbcg=find(strcmp(fnoms,'aabcg')==1);

intrqq=0;
existdata_I=find(strcmp(fnoms,'data_I')==1);
if existdata_I>0 && size(fita(sel).data_I,1)>0
    data_I=fita(sel).data_I;
else
    instrq_m=menu('use existing instrumental?','yes','no');
    if instrq_m ~= 1
        [file path] = uigetfile({'*.mat'},'Select Instrumental File to open');
        load([path,file]);
        if exist('aabcg_I')==0 || size(aabcg_I,1)==0;aabcg_I=zeros(2,length(aa_I)-1);end
        save([cd,'/0. variables/data_I.mat'],'data_I')
        save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
        intrqq=1;
    else
        load([cd,'/0. variables/data_I.mat'])
        load([cd,'/0. variables/fit_I.mat'])
        intrqq=1;
    end
        
end

existdata_I=find(strcmp(fnoms,'aa_I')==1);
if existdata_I>0 && size(fita(sel).aa_I,1)>0
    
    aa_I=fita(sel).aa_I;
    aabcg_I=fita(sel).aabcg_I;
else
    if intrqq==0
        [file path] = uigetfile({'*.mat'},'Select Instrumental File to open');
    load([path,file]);
    if exist('aabcg_I')==0 || size(aabcg_I,1)==0;aabcg_I=zeros(2,length(aa_I)-1);end
    save([cd,'/0. variables/data_I.mat'],'data_I')
    save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')
    intrqq=1;
    end
end


if isempty(existbcg)==1
    aabcg=zeros(2,size(aa,2)-1);
%     aabcg_I=zeros(2,size(aa_I,2)-1);
else
    
    aabcg=fita(1,sel).aabcg;
    if size(aabcg,1)==0
        aabcg=zeros(2,size(aa,2)-1);
    else
    end
%     aabcg_I=fita(1,sel).aabcg_I;
end

save([cd,'/0. variables/data.mat'],'data')
save([cd,'/0. variables/fit.mat'],'aa','aabcg')

save([cd,'/0. variables/data_I.mat'],'data_I')
save([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')

save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')

axes(handles.axes1)
if ishold==1;hold;end
semilogy(data(:,1),data(:,2)),hold

Ifit=pv_tv_aa(aa,data(:,1));
plot(data(:,1),Ifit,'m')
ylim([min(Ifit)*.9 max(Ifit)*1.3])


set(handles.sampleid2_t,'string',identa)

% --- Executes on button press in alpha2q_b.
function alpha2q_b_Callback(hObject, eventdata, handles)
% hObject    handle to alpha2q_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of alpha2q_b

load([cd,'/0. variables/genset.mat'])
val=get(hObject,'Value');
if val==1
    alpha2=0;
else
    alpha2=1;
end
save([cd,'/0. variables/genset.mat'],'bcg2peak','alpha2','wavelen','tube','identa')


% --- Executes on button press in korig_b.
function korig_b_Callback(hObject, eventdata, handles)
% hObject    handle to korig_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of korig_b

load([cd,'/0. variables/fit.mat'])
load([cd,'/0. variables/phases.mat'])

pval_=get(handles.indexres_l,'value');
sval=get(handles.phaseres_l,'value');

if sval==2;pval=pval_+length(dsettings(1).d);else pval=pval_;end

if str2double(dsettings(sval).cstruct(1))==3 || str2double(dsettings(sval).cstruct(1))==2
    crys='cub';
elseif str2double(dsettings(sval).cstruct(1))==4
    crys='hex';
end

if strcmp(class(dsettings(1,sval).lat1),'double')==1
        lat1=dsettings(1,sval).lat1;
    else
        lat1=str2double(dsettings(1,sval).lat1);
    end
    if strcmp(class(dsettings(1,sval).lat2),'double')==1
        lat2=dsettings(1,sval).lat2;
    else
        lat2=str2double(dsettings(1,sval).lat2);
    end
    
aa(1,pval)=1./dspacing(dsettings(sval).index(pval_,:),crys,1,lat1,lat2  );
save([cd,'/0. variables/fit.mat'],'aa','aabcg')
set(hObject,'value',0)




% --- Executes on button press in findvar_b.
function findvar_b_Callback(hObject, eventdata, handles)

% hObject    handle to findvar_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/phases.mat'],'dsettings')
load([cd,'/0. variables/genset.mat'])
load([cd,'/0. variables/data.mat'],'data')
load([cd,'/0. variables/fit.mat'],'aa','aabcg')
load([cd,'/0. variables/data_I.mat'],'data_I')
load([cd,'/0. variables/fit_I.mat'],'aa_I','aabcg_I')


delK=bcg2peak;

tube='es';
alpha2=1;
select=get(handles.indexres_l,'value');

sample_n=40;
menq=menu('use current I_all values? (Or create new ones from fit)  ','yes','no','just selected');
if menq==2
%     aa(:,end)=zeros(size(aa(:,1)));
%     aabcg=aabcg*0;
%     aa_I(:,end)=zeros(size(aa_I(:,1)));
%     aabcg_I=aabcg_I*0;
    
[I_all]=steel_findfourier_a23( aa,aabcg, data, aa_I,aabcg_I, data_I,sample_n,1,dsettings);
elseif menq==3
aa=[aa(:,select) ,aa(:,end)];
aabcg=aabcg(:,select);
load([cd,'/0. variables/I_all.mat'],'I_all','q')
[I_all(:,select,:)]=steel_findfourier_a23( aa,aabcg, data, aa_I,aabcg_I, data_I,sample_n,1,dsettings);    
else
    load([cd,'/0. variables/I_all.mat'],'I_all','q')
end

peakno=get(handles.indexres_l,'value');

[Mall q]=steel_findVariance(I_all, dsettings);
save([cd,'/0. variables/I_all.mat'],'I_all','q')

%%%%%%%
if size(aa,1)==4
   aa(5:6,:)=aa(3:4,:); 
end
if size(aa_I,1)==4
   aa_I(5:6,:)=aa_I(3:4,:); 
end
for n=1:size(I_all,2)
    
    tth=-delK:2*delK/(length(I_all)-1):delK;tth=tth+aa(1,n);
    aa(2,n)=1;
    
    I_all(:,n,1)=pk_alpha_asymm(tth',aa(:,n));
    
    k_I=abs(aa_I(1,:)-aa(1,n));
    peakno_I=find(k_I==min(k_I));
    tth=-delK:2*delK/(length(I_all)-1):delK;tth=tth+aa_I(1,peakno_I);
    aa_I(2,peakno_I)=aa(2,n);
    I_all(:,n,2)=pk_alpha_asymm(tth',aa_I(:,peakno_I));
end
    [Mall_PV q]=steel_findVariance(I_all, dsettings);
% end
%%%%%%%%

% usePV=get(handles.usePV_b,'value');

theta0=aa(1,:)/2;%in theta not 2theta

save([cd,'/0. variables/variance.mat'],'Mall','q','Mall_PV','theta0')
set(handles.delK_t,'string', num2str(delK));

% --- Executes on selection change in popupmenu10.
function popupmenu10_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu10 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu10


% --- Executes during object creation, after setting all properties.
function popupmenu10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in usePV_b.
function usePV_b_Callback(hObject, eventdata, handles)
% hObject    handle to usePV_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of usePV_b


% --- Executes on button press in VARbcg_b.
function VARbcg_b_Callback(hObject, eventdata, handles)
% hObject    handle to VARbcg_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of VARbcg_b


logpltq=get(handles.logplot_b,'value');
MorI=menu('Change background level?','Measured','Instrumental','Real, minimising q^3 term','Nothing');
load([cd,'/0. variables/I_all.mat'])
peakno=get(handles.indexres_l,'value');

if MorI<3
plusminus=menu('?','Reduce','Increase','just LHS peak','just RHS peak');


    if plusminus<3
        if ishold==1;hold;end
        if logpltq==1
            semilogy(sortrows([-q;0;q]),I_all(:,peakno,MorI),'.')
        else
            plot(sortrows([-q;0;q]),I_all(:,peakno,MorI))
        end


        [x y]=ginput(1);
        if plusminus == 2 ; y=-y; end
        I_all(:,peakno,MorI)=I_all(:,peakno,MorI)-y;
        I_all(:,peakno,MorI)=I_all(:,peakno,MorI)/max(I_all(:,peakno,MorI));
    elseif plusminus==3
        lenII=( length(I_all)+rem(length(I_all),2) )/2;
        I_all(lenII:end,peakno,MorI)=wrev(I_all(1:length(I_all(lenII:end,peakno,MorI)),peakno,MorI));

    elseif plusminus==4
        lenII=( length(I_all)-rem(length(I_all),2) )/2;
        I_all(1:lenII,peakno,MorI)=wrev(I_all(end+1-length(I_all(1:lenII,peakno,MorI)):end,peakno,MorI));



    end
elseif MorI==3
    
    [MallOUT q bcg]=varbcg_fit_2THETA(I_all, peakno);
    I_all(:,peakno,1)=I_all(:,peakno,1)-bcg(1);
    I_all(:,peakno,2)=I_all(:,peakno,2)-bcg(2);
end

    
save([cd,'/0. variables/I_all.mat'],'I_all','q')

if ishold==1;hold;end
if logpltq==1
    semilogy(sortrows([-q;0;q]),I_all(:,peakno,MorI),'.')
else
    plot(sortrows([-q;0;q]),I_all(:,peakno,MorI))
end

function edit43_Callback(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of WHq_t as text
%        str2double(get(hObject,'String')) returns contents of WHq_t as a double


% --- Executes during object creation, after setting all properties.
function edit43_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHq_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in plotwh_b.
function RES_varWH_l_Callback(hObject, eventdata, handles)
% hObject    handle to plotwh_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns plotwh_b contents as cell array
%        contents{get(hObject,'Value')} returns selected item from plotwh_b

load([cd,'/0. variables/WHres.mat'],'IB_','WHres','fw_r','MWHres','k')
load([cd,'/0. variables/phases.mat'])
% load([cd,'/0. variables/fit.mat'])


index=num2str(dsettings(1).index);
inda=get(handles.WHselected_l,'string');
h=1;
for n=1:size(inda,1)
    for m=1:size(index,1)
        index_=index(m,find(index(m,:)~=' '));
        inda_=inda(n,find(inda(n,:)~=' '));
       if strcmp(inda_,index_)==1
           select(h)=m;
           h=h+1;
           break
       end
    end
    
end

axes(handles.axes1),if ishold==1;hold;end
% figure(11)
val=get(hObject,'Value');
% clear aa
switch val
    case 1 %Variance Raw
        load([cd,'/0. variables/RES_VAR.mat'])

        set(handles.WH_p,'visible','off')
        set(handles.variance_act_p,'visible','on')
        peakno=get(handles.indexres_l,'value');
        load([cd,'/0. variables/variance.mat'])
        
        if ishold==1;hold;end
        

        plot(q,Mall(:,peakno,1),'k:','linewidth',6)   
        hold
        plot(q,Mall(:,peakno,2),'.','Color',[.8 .8 .8])
        plot(q,Mall(:,peakno,1)-Mall(:,peakno,2),'-k','linewidth',6)
        set(handles.variancegs_t,'string', D )
        
        set(handles.variancermss_t,'string', rmss*1e3 )
        plot(q,xh(1)+xh(2)*q,'--','Color',[.8 .8 .8],'linewidth',2)
        plot(q,xg(1)+xg(2)*q,'k-','linewidth',2)
        
        Wh=xh(1);
        Wg=xg(1);
        kh=xh(2);
        kg=xg(2);
        kf=kh-kg;
        Wf=Wh- Wg +.5*pi^2*kg*(kh-kg);

        plot(q,Wf + kf*q,':','linewidth',4,'Color',[.5 .5 .5])
        
        xlim([0 0.5])
        legend('Var MEas','Var Instr','Var Real','Fit of Var Meas','Fit of Var Instr','Fit of Var Real','location','best')  
        
    case 2 %Variance PV
        load([cd,'/0. variables/RES_VAR.mat'])

        set(handles.WH_p,'visible','off')
        set(handles.variance_act_p,'visible','on')
        peakno=get(handles.indexres_l,'value');
        load([cd,'/0. variables/variance.mat'])
        
        if ishold==1;hold;end
        
            Mall=Mall_PV;
        
        plot(q,Mall(:,peakno,1),'k.')   
        hold
        plot(q,Mall(:,peakno,2),'r.')
%         varfind_PV_t_Callback(hObject, eventdata, handles)
        set(handles.variancegs_t,'string', D_PV )
        
        set(handles.variancermss_t,'string', rmss_PV*1e3 )
        plot(q,xh_PV(1)+xh_PV(2)*q,'m')
        plot(q,xg_PV(1)+xg_PV(2)*q,'g')
        
   

        
    case 3 %WH
        set(handles.WH_p,'visible','on')
        set(handles.variance_act_p,'visible','off')
        textFW='real FW';
        if ishold==1;hold;end
        plot(k,fw_r,'o','markersize',5,'linewidth',5)
        kk=0:.1:max(k)*1.2;
        yy=1/WHres(1,2)+WHres(1,3)*kk;
        title(['WH PLOT',textFW],'fontsize',20)
        hold
        plot(kk,yy)
        set(handles.WHq_t,'string', 0 )
        set(handles.variancegs_t,'string', WHres(1,2) )
        const=2*sqrt(2*pi);
        set(handles.variancermss_t,'string', 1e3*WHres(1,3)/const )
        
        set(handles.q2_t,'string', 0 )
        
    case 4 %MWH1
        set(handles.WH_p,'visible','on')
        set(handles.variance_act_p,'visible','off')
        q=MWHres(1,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(1,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(k'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        textFW='real FW';
        plot(C.^.5.*k,fw_r,'o','markersize',5,'linewidth',5)
        kk=0:.1:max(C.^.5.*k)*1.2;
        yy=1/MWHres(1,2)+MWHres(1,3)*kk;
        title(['MWH-1 PLOT',textFW],'fontsize',20)
        hold
        plot(kk,yy)
        set(handles.WHq_t,'string', MWHres(1,1) )
        set(handles.variancegs_t,'string', MWHres(1,2) )
        set(handles.variancermss_t,'string', 1e3*MWHres(1,3) )  
        if strcmp(dsettings(1).cstruct(1),'4')==1
        set(handles.q2_t,'string', MWHres(1,4) )
        end
    case 5 %MWH2
        set(handles.WH_p,'visible','on')
        set(handles.variance_act_p,'visible','off')
        q=MWHres(2,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(2,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(k'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        textFW='real FW-squared';
        plot(C.*k.^2,fw_r.^2,'o','markersize',5,'linewidth',5)
        kk=0:.1:max(C.*k.^2)*1.2;
        yy=(1/MWHres(2,2))^2 + (MWHres(2,3))^2*kk;
        title(['MWH-2 PLOT',textFW],'fontsize',20)
        hold
        plot(kk,yy)
        set(handles.WHq_t,'string', MWHres(2,1) )
        set(handles.variancegs_t,'string', MWHres(2,2) )
        set(handles.variancermss_t,'string', 1e3*MWHres(2,3) )  
        if strcmp(dsettings(1).cstruct(1),'4')==1
        set(handles.q2_t,'string', MWHres(2,4) )
        end
        
    case 6 %MWH3
        set(handles.WH_p,'visible','on')
        set(handles.variance_act_p,'visible','off')
        q=MWHres(3,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(3,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(k'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        textFW='real FW';
        plot(C.*k.^2,fw_r,'o','markersize',5,'linewidth',5)
        kk=0:.1:max(C.*k.^2)*1.2;
        yy=1/MWHres(3,2)+MWHres(3,3)*kk;
        title(['MWH-3 PLOT',textFW],'fontsize',20)
        hold
        plot(kk,yy)
        set(handles.WHq_t,'string', MWHres(3,1) )
        set(handles.variancegs_t,'string', MWHres(3,2) )
        set(handles.variancermss_t,'string', 1e3*MWHres(3,3) )  
        if strcmp(dsettings(1).cstruct(1),'4')==1
        set(handles.q2_t,'string', MWHres(3,4) )
        end
        
        
end
    

% --- Executes during object creation, after setting all properties.
function RES_varWH_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotwh_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveRES_b.
function saveRES_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveRES_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% what to save: VAR & WH
%             : WHres MWHres IB fw_r select sample_name(genset identa) val

WHorVAR=get(handles.WH_p,'visible');

if strcmp(WHorVAR,'on')~=1
    load([cd,'/0. variables/genset.mat'],'bcg2peak','wavelen','alpha2','identa','tube')
    load([cd,'/0. variables/RES_VAR.mat'])
    load([cd,'/0. variables/phases.mat'])
    
    
    [FileName,PathName] = uiputfile('*.mat','Select the Res file',[cd]);
    filq=exist( [PathName,FileName]);
    if filq~=0
        load([PathName,FileName],'RESA')
        sizfit=length(RESA);
    else
        dotsq=find(FileName=='.');
        if isempty(dotsq)==0
            FileName=FileName(1:dotsq-1);

        end
        FileName=[FileName,'_VARres'];
        sizfit=0;
        val_old=1;
        RESA=[];
    end
    
    for n=1:length(RESA)
        noms{n}=RESA(1,n).identa;
    end


    if sizfit~=0
        noms=['ADD NEW' ,noms];
        place_=menu('Select option: ',noms);
        if place_ ~= 1; placeA=place_-1;
        else
            placeA=sizfit+1;
        end
    else
        placeA=1;
    end

    
    RESA(placeA).D(peakno)=D;
    RESA(placeA).D_PV(peakno)=D_PV;
    RESA(placeA).rmss(peakno)=rmss;
    RESA(placeA).rmss_PV(peakno)=rmss_PV;   
    RESA(placeA).identa=identa;
    RESA(placeA).xg=xg;
    RESA(placeA).xh=xh;
    RESA(placeA).xg_PV=xg_PV;
    RESA(placeA).xh_PV=xh_PV;
    
    RESA(placeA).index(peakno,:)=dsettings(1).index(peakno,:);
    identa
    val=input('Enter value:     ');
    RESA(placeA).val=val;


    save([PathName,FileName],'RESA')

   
else

    load([cd,'/0. variables/genset.mat'],'bcg2peak','wavelen','alpha2','identa','tube')
    load([cd,'/0. variables/WHres.mat'],'IB_','WHres','fw_r','MWHres')
    load([cd,'/0. variables/phases.mat'])
    load([cd,'/0. variables/fit.mat'])

    index=num2str(dsettings(1).index);
    inda=get(handles.WHselected_l,'string');
    h=1;
    for n=1:size(inda,1)
        for m=1:size(index,1)
            index_=index(m,find(index(m,:)~=' '));
            inda_=inda(n,find(inda(n,:)~=' '));
           if strcmp(inda_,index_)==1
               select(h)=m;
               h=h+1;
               break
           end
        end

    end


    [FileName,PathName] = uiputfile('*.mat','Select the Res file',[cd]);
    filq=exist( [PathName,FileName]);
    if filq~=0
        load([PathName,FileName],'RESA')
        sizfit=length(RESA);
    else
        dotsq=find(FileName=='.');
        if isempty(dotsq)==0
            FileName=FileName(1:dotsq-1);

        end
        FileName=[FileName,'_WHres'];
        sizfit=0;
        val_old=1;
        RESA=[];
    end

    for n=1:length(RESA)
    noms{1,n}=RESA(1,n).identa;
    end


    if sizfit~=0
        noms=['ADD NEW' ,noms];
        place_=menu('Select option: ',noms);
        if place_ ~= 1; placeA=place_-1;
        else
            placeA=sizfit+1;
        end
    else
        placeA=1;
    end

    RESA(placeA).WHres=WHres;
    RESA(placeA).MWHres=MWHres;
    RESA(placeA).IB_=IB_;
    RESA(placeA).fw_r=fw_r;
    identa
    RESA
    RESA(placeA).identa=identa;
    RESA(placeA).select=select;
    val=input('Enter value:     ');
    RESA(placeA).val=val;
    RESA(placeA).aa=aa;


save([PathName,FileName],'RESA')

end

% --- Executes on selection change in WHselected_l.
function WHselected_l_Callback(hObject, eventdata, handles)
% hObject    handle to WHselected_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns WHselected_l contents as cell array
%        contents{get(hObject,'Value')} returns selected item from WHselected_l
load([cd,'/0. variables/phases.mat'])
NPKS=size(dsettings(1,1).index,1);
str=get(handles.WHselected_l,'string');
if size(str,1)==1 && strcmp(str(1,:),'Select Peaks')==1
    for n=1:NPKS
    index{n}=num2str(dsettings(1,1).index(n,:));
    end
    
    index{n+1}='ALL';
    index{n+2}='END';
    sizeindex=size(index,2)
    n=1;menusel=1;
    selected=[];
    
    while  menusel<sizeindex-1;
    menusel=menu('Select peaks to use',index')
    if menusel<sizeindex-1
        selected(n)=menusel;
        index{menusel}=['<- ',index{menusel},' ->'];
        n=n+1;
    elseif menusel==sizeindex-1
        selected=1:1:NPKS;
    end
    end
    set(handles.WHselected_l,'string',index)
end

% --- Executes during object creation, after setting all properties.
function WHselected_l_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WHselected_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in WHselectpks_b.
function WHselectpks_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHselectpks_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


load([cd,'/0. variables/phases.mat'])
NPKS=size(dsettings(1,1).index,1);
str=get(handles.WHselected_l,'string');

    for n=1:NPKS
    index{n}=num2str(dsettings(1,1).index(n,:));
    end
    
    index{n+1}='ALL';
    index{n+2}='END';
    sizeindex=size(index,2)
    n=1;menusel=1;
    selected=[];
    
    while  menusel<sizeindex-1;
    menusel=menu('Select peaks to use',index')
    if menusel<sizeindex-1
        selected(n)=menusel;
        index{menusel}=['<- ',index{menusel},' ->'];
        n=n+1;
    elseif menusel==sizeindex-1
        selected=1:1:NPKS;
    end
    end
    selected=sort(selected);
    set(handles.WHselected_l,'value',1)
    set(handles.WHselected_l,'string',num2str(dsettings(1,1).index(selected,:)));



function q2_t_Callback(hObject, eventdata, handles)
% hObject    handle to q2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of q2_t as text
%        str2double(get(hObject,'String')) returns contents of q2_t as a double


% --- Executes during object creation, after setting all properties.
function q2_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to q2_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in WHpk_b.
function WHpk_b_Callback(hObject, eventdata, handles)
% hObject    handle to WHpk_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/WHres.mat'],'IB_','WHres','fw_r','MWHres')
load([cd,'/0. variables/phases.mat'])
load([cd,'/0. variables/fit.mat'])


index=num2str(dsettings(1).index);
inda=get(handles.WHselected_l,'string');
h=1;
for n=1:size(inda,1)
    for m=1:size(index,1)
        index_=index(m,find(index(m,:)~=' '));
        inda_=inda(n,find(inda(n,:)~=' '));
       if strcmp(inda_,index_)==1
           select(h)=m;
           h=h+1;
           break
       end
    end
    
end


val=get(handles.RES_varWH_l,'value');


switch val
    case 3 %WH
        xx=aa(1,select);
        yy=fw_r;
    case 4
        q=MWHres(1,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(1,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(aa(1,select)'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        xx=C.^.5.*aa(1,select);
        yy=fw_r;
    case 5
        q=MWHres(1,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(1,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(aa(1,select)'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        xx=C.*aa(1,select).^2;
        yy=fw_r.^2;
    case 6
         q=MWHres(1,1);
        if strcmp(dsettings(1).cstruct(1),'4')==1
            q2=MWHres(1,4);
            l=dsettings(1).index(select,3);
            xXx=(2/3)*((l./(aa(1,select)'*2.95)).^2);
            C=(1+q*xXx + q2*xXx.^2)'  ;  
        else
            H2=Hsq(dsettings(1,1).index(select,:));
            C=0.3*(1-q*H2);
        end
        xx=C.*aa(1,select).^2;
        yy=fw_r;
end
        
        

[x y]=ginput(1);


diff=abs( (xx.^2 - x.^2) + (yy.^2 - y.^2) );
pos=find(diff==min(diff));
menu([ num2str(dsettings(1).index(pos,:)),'  ---  ', num2str(pos)],'ok')



function delK_t_Callback(hObject, eventdata, handles)

% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delK_t as text
%        str2double(get(hObject,'String')) returns contents of delK_t as a double

load([cd,'/0. variables/genset.mat'])

delK=str2num(get(hObject,'string'));
bcg2peak=delK;
save([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')

% --- Executes during object creation, after setting all properties.
function delK_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delK_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in batchrefit_b.
function batchrefit_b_Callback(hObject, eventdata, handles)
% hObject    handle to batchrefit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadIall_b.
function loadIall_b_Callback(hObject, eventdata, handles)
% hObject    handle to loadIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')

[file path] = uigetfile({'*.mat'},'Select Instrumental File to open');
load([path,file],'fita');
for n=1:length(fita);nom{n}=fita(n).name;end
selec=menu('select file',nom);
set(handles.sampleid2_t,'string',nom{selec})
identa=nom{selec};
I_all=fita(selec).I_all;
q=fita(selec).q;

save([cd,'/0. variables/I_all.mat'],'I_all','q')
save([cd,'/0. variables/genset.mat'],'alpha2','bcg2peak','identa','tube','wavelen')


% --- Executes on button press in saveIall_b.
function saveIall_b_Callback(hObject, eventdata, handles)
% hObject    handle to saveIall_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

 load([cd,'/0. variables/I_all.mat'],'I_all','q')
 
 [FileName,PathName] = uiputfile('*.mat','Save file name');

filq=exist( [PathName,FileName]);

if filq~=0
    load([PathName,FileName],'fita')
    sizfit=length(fita);
else  
    sizfit=0;
    fita=[];
end
na=get(handles.sampleid2_t,'string');
user_entry = input(['Enter name:   ',na] , 's');
val = input('Enter val:   ');

fita(sizfit+1).name=user_entry;
fita(sizfit+1).val=val;
fita(sizfit+1).q=q;
fita(sizfit+1).I_all=I_all;

save([PathName,FileName],'fita')


% --- Executes on button press in varbatch_b.
function varbatch_b_Callback(hObject, eventdata, handles)
% hObject    handle to varbatch_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load('/Applications/MATLAB74/work/5. New Steelfit/0. variables/phases.mat')
load('/Applications/MATLAB74/work/5. New Steelfit/0. variables/genset.mat','identa')

for fit_=1:4
    nj=[1 2 5 8];
    menu(['select   ',num2str(nj(fit_)),'  tr'],'ok')
    
loadIall_b_Callback(hObject, eventdata, handles)
str_pos=fit_;
peaknos=[1 4 5 12 13];
filna=[cd,'/7. Variance/VAR_Ti64_Klugg_RES_TR.mat'];
if fit_~=1
    load(filna,'RESA_VAR')
end

for xcv=1:length(peaknos)
    peak_pos=xcv;
    set(handles.indexres_l,'value',peaknos(xcv))
    findvar_b_Callback(hObject, eventdata, handles)
    varfind_PV_t_Callback(hObject, eventdata, handles)
    
    menu('Do Meas + Instr','ok')
    variancefit_b_Callback(hObject, eventdata, handles)
    RES_varWH_l_Callback(hObject, eventdata, handles)
    menu('Take Pic of Meas + Instr','ok')
        load([cd,'/0. variables/RES_VAR.mat'])
        RESA_VAR(str_pos,peak_pos).D=D;
        RESA_VAR(str_pos,peak_pos).D_PV=D_PV;
        RESA_VAR(str_pos,peak_pos).rmss=rmss;
        RESA_VAR(str_pos,peak_pos).rmss_PV=rmss_PV;
        RESA_VAR(str_pos,peak_pos).peakno=peakno;
        RESA_VAR(str_pos,peak_pos).index=dsettings(1).index(peakno,:);
        load('/Applications/MATLAB74/work/5. New Steelfit/0. variables/genset.mat','identa')
        RESA_VAR(str_pos,peak_pos).name=identa;
        

    
    menu('Do Real','ok')
    variancefit_b_Callback(hObject, eventdata, handles)
    RES_varWH_l_Callback(hObject, eventdata, handles)
    menu('Take Pic of Real','ok')
        load([cd,'/0. variables/RES_VAR.mat'])
        RESA_VAR(str_pos,peak_pos).D_real=D;
        RESA_VAR(str_pos,peak_pos).rmss_real=rmss;
    
    filna=[cd,'/7. Variance/VAR_Ti64_Klugg_RES_TR.mat'];
    save(filna,'RESA_VAR')

    VARbcg_b_Callback(hObject, eventdata, handles)
    findvar_b_Callback(hObject, eventdata, handles)
    
    menu('Do Meas + Instr','ok')
    variancefit_b_Callback(hObject, eventdata, handles)
    RES_varWH_l_Callback(hObject, eventdata, handles)
    menu('Take Pic of Meas + Instr: bcg q3','ok')
        load([cd,'/0. variables/RES_VAR.mat'])
        RESA_VAR(str_pos,peak_pos).Dq3=D;
        RESA_VAR(str_pos,peak_pos).rmssq3=rmss;
        
    menu('Do Real','ok')
    variancefit_b_Callback(hObject, eventdata, handles)
    RES_varWH_l_Callback(hObject, eventdata, handles)
    menu('Take Pic of Real: bcg q3','ok')
        load([cd,'/0. variables/RES_VAR.mat'])
        RESA_VAR(str_pos,peak_pos).Dq3_real=D;
        RESA_VAR(str_pos,peak_pos).rmssq3_real=rmss;
        
save(filna,'RESA_VAR')      
end

end


% --- Executes on button press in plot_2.
function plot_2_Callback(hObject, eventdata, handles)
% hObject    handle to plot_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load([cd,'/0. variables/data.mat'])
load([cd,'/0. variables/phases.mat'])

xp=[];
for n=1:length(dsettings)

 xp=[xp;1./dsettings(1,n).d];
%     xp=[xp,1./dsettings(1,n).d];
end
axes(handles.axes1)
if ishold==1
    hold
end
logplot=get(handles.logplot_b,'value');
if logplot==1

    semilogy(data(:,1),data(:,2)),hold
else
    plot(data(:,1),data(:,2)),hold
end
    sizxp1=length(dsettings(1,1).d);
    for n=1:sizxp1
    plot([xp(n),xp(n)],[(min(abs(data(:,2)))+1)*.6;max(data(:,2))*3],'sb--')
    end
    for n=sizxp1+1:length(xp)
    plot([xp(n),xp(n)],[(min(abs(data(:,2)))+1)*.6;max(data(:,2))*3],'sr-')
    end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over load_l.
function load_l_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to load_l (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
