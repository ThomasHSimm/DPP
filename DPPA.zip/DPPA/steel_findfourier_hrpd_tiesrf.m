function [  OUT]=steel_findfourier_hrpd_tiesrf( aa,aabcg,data, aa_I,aabcg_I, data_I,sample_n, plot_I,dsettings)
global delK 
%%%used to find the intensity values of the peaks
% delK=0.025;
incretth=data(2,1)-data(1,1);
incretth=double( int16(incretth/1e-5 ))*1e-05;
posdelK=delK/incretth;
posdelK=posdelK-rem(posdelK,1);

incretth=data_I(2,1)-data_I(1,1);
incretth=double( int16(incretth/1e-5 ))*1e-05;
posdelK_I=delK/incretth;
posdelK_I=posdelK_I-rem(posdelK_I,1);

len_1=length(dsettings(1,1).d);if len_1>length(aabcg);len_1=length(aabcg);end
% FClen=101;
for n=1:length(data)
    data(n,:)=data(n,:)+rand(1,2)*1e-5;
end
for n=1:length(data_I)
    data_I(n,:)=data_I(n,:)+rand(1,2)*1e-5;
end
% 
% LHS=0;%%take just LHS

for n=1:length(dsettings(1,1).d)   %find which instrumental are closest to the measured
 
  
    delxp=abs( aa_I(1,1:end-1)-aa(1,n) );
    posxp(n)=find(delxp==min(delxp));
end
clear dsettings
n=1;
while n<=length(posxp)
% for n=1:length(posxp)
    adjtth=abs(data_I(:,1)-aa_I(1,posxp(n)));
    
    peakpos=find(adjtth==min(adjtth));
    adjtth=(data_I(:,1)-aa_I(1,posxp(n)));
    lam0=aa_I;
    lam0(:,posxp(n))=zeros(size(lam0,1),1);
    Ipeak=data_I(:,2)-pv_tv_aa(lam0,data_I(:,1) ) -pv_tv_aa([aabcg_I(:,posxp(n));0;0],data_I(:,1));
    
    adjtth_new=-delK:incretth:delK;
    posb4=peakpos-posdelK_I;%if posb4<1;posb4=1;end
    posa4=peakpos+posdelK_I;
    
%     if n==length(posxp) && posa4>length(adjtth)
%         adjtth(end:posa4)=adjtth(end):incretth:adjtth(end)*(posa4-length(adjtth));
%         Ipeak(end:posa4)=Ipeak(end);
%     end
        
    Ipeaknew=interp1(adjtth(posb4:posa4), Ipeak(posb4:posa4), adjtth_new, 'PCHIP');
    
    
%     if posa4>size(data_I,1);
% %          aa_I(1,posxp(n))=inf;
%          posxp(n)=posxp(n-1);
%          
%     else
%         if posb4<1;menu('ERROR too few data points before Standard peaks','ok');end
% %         if posa4>size(data,1);menu('ERROR too few data points after Standard peaks','ok');end
        I_I(:,n)=Ipeaknew;
%         I_I(:,n)=Ipeak(posb4:posa4);
        I_I(:,n)=I_I(:,n)/abs(max(I_I(:,n)));
        
        FClen=length(I_I);

        FC_I(:,n)=fft(I_I(:,n),FClen);
        FC_I(:,n)=FC_I(:,n)/max(abs(FC_I(:,n)));
%         if n<9;plot(data_I(posb4:posa4,1),I_I(:,n),'r');end
    n=n+1;
%     end
    
end



% len_1=24;

len_1=length(posxp);


clear data_I adjtth lam0 Ipeak delxp


I=zeros(length(Ipeaknew),len_1);
for n=1:len_1
    adjtth=abs(data(:,1)-aa(1,n));
    peakpos=find(adjtth==min(adjtth));
    adjtth=(data(:,1)-aa(1,n));
    lam0=aa;lam0(:,n)=zeros(size(aa,1),1);
    Ipeak=data(:,2)-pv_tv_aa(lam0,data(:,1) ) -pv_tv_aa([aabcg(:,n);0;0],data(:,1));
    
    adjtth_new=-delK:incretth:delK;
    posb4=peakpos-posdelK;%if posb4<1;posb4=1;end
    posa4=peakpos+posdelK;
    if posa4>length(Ipeak)
        dat=data(:,1);
        for hn=length(Ipeak)+1:posa4
            dat(hn)=dat(hn-1)+incretth;
        end
        adjtth=(dat-aa(1,n));
        posEND=length(data);
        XX=adjtth(posEND-100:posEND);
        YY=Ipeak(posEND-100:posEND);
        LAM=[0 0 0];
        LAM=lsqcurvefit(@polyno, LAM, XX, YY);%tulk 16th april
        
        
        Ipeak( length(data):posa4 )= polyno( LAM,adjtth(length(data):posa4,1)   )  ;%pv_tv_aa( [aa(:,n),[0; 0 ; 0; 0; 0 ; 0 ] ],  dat(length(data):posa4,1) );
    end
    Ipeaknew=interp1(adjtth(posb4:posa4), Ipeak(posb4:posa4), adjtth_new, 'PCHIP');
    
%     
%     posb4=peakpos-posdelK;if posb4<1;menu('ERROR too few data points b4 peaks','ok') ;end
%     posa4=peakpos+posdelK;if posa4>size(data,1);menu('ERROR too few data points after peaks','ok');end
%     
%     I(:,n)=Ipeak(posb4:posa4);I(:,n)=I(:,n)/abs(max(I(:,n)));
    
    I(:,n)=Ipeaknew;
    I(:,n)=I(:,n)/abs(max(I(:,n)));

%     if LRHS(n)~=0;I(:,n)=oneside(I(:,n),LRHS(n));end
    
%%    
%     minI=min(I(:,n));
% %     if minI<0
%         I(:,n)=I(:,n)-(minI);
% %     end
%%  
%     if LHS==1;I(:,n)=oneside(I(:,n));end
    FC(:,n)=fft(I(:,n),FClen);
    FC(:,n)=FC(:,n)/max(abs(FC(:,n)));
    FC_R(:,n)=FC(:,n)./FC_I(:,(n));
    
    FC_R2=zeros(size(FC_R(:,n)));
    
    
    usedL=sample_n;
    
    %%make FC consist of 1st part ad last part of the deconvoluted
    %%FCs--rest is zero
    
    FC_R2(1:usedL)=FC_R(1:usedL,n);
    FC_R2(end-usedL:end)=FC_R(end-usedL:end,n);
    FC_R(:,n)=(FC_R2);
    FC_Rreal(:,n)=abs(FC_R(:,n));
    clear FC_R2
    I_R(:,n)=reverse(ifft(FC_R(:,n)));
    I_Rreal(:,n)=reverse(ifft( FC_Rreal(:,n)));
    
    FC_R(:,n)=abs( FC_R(:,n) )./max(abs( FC_R(1,n) ));
    
%     if  ( FC_R(1,n)-FC_R(2,n))< abs( FC_R(2,n)-FC_R(3,n) )
%         FC_R(1,n)=FC_R(2,n)+  0.5*(FC_R(2,n)-FC_R(3,n));
%         FC_R(:,n)=abs( FC_R(:,n) )./max(abs( FC_R(:,n) ));
%     
%     end
    
    if  ( FC_R(1,n)-FC_R(2,n))> 2.5*( FC_R(2,n)-FC_R(3,n) )
        FC_R(1,n)=FC_R(2,n)+  0.5*(FC_R(2,n)-FC_R(3,n));
        FC_R(:,n)=abs( FC_R(:,n) )./max(abs( FC_R(1,n) ));
    
    end


%     if n<6 && plot_I==1;plot(data(posb4:posa4,1),I(:,n),'k');
%         figure(12)
%         subplot(2,3,n)
%         if ishold==1;hold;end
%         plot(I_R(:,n),'g.-');hold
%         plot(I_I(:,posxp(n) ),'k-.')
%         plot(I(:,n),'r.-')
%         plot(I_Rreal(:,n),'b:.')
%     end
    
end

if plot_I==1
    OUT(:,:,1)=I(:,1:len_1);
    OUT(:,:,2)=I_I(:,1:len_1);
    OUT(:,:,3)=I_R(:,1:len_1);
    
else
    OUT=FC_R;
    
end

clear data adjtth lam0 Ipeak

end

function Iout=reverse(I)

len=length(I);lenhalf=(len+1)/2;
Iout=I;
Iout(1:lenhalf)=I(lenhalf:end);
Iout(lenhalf+1:end)=I(1:lenhalf-1);
Iout=abs(real(Iout));Iout=Iout/max(Iout);


end


function [f ]=polyno(lam,x)

        f= lam(1) + x*lam(2) + x.^2*lam(3) ;
end

