function  [OUT all_I]=steel_tsfourier_alt(A,settings,selected,num)

global a sizA lat g H2 number delK type B C xx type

a=[]; sizA=[]; lat=[]; g=[];  number=[];
% number=[ 1 2 3 4 5];
H2=Hsq(settings(1,1).index(selected,:));
% H2=H2(selected);

lat=0.35675*10;%for nickel 
B=0.5*pi*(lat/2^0.5)^2;
C=0.3*(1-2.3*H2);
C=C(1);
%close all

L=0:1:(length(A)-1);
a3=0.5/delK;
L=L*a3;
L=L';

A=A(:,selected);
for n=1:length(selected)
    g(n)=1./settings(1,1).d(selected(n));
end

xx=1;
for n=1:length(selected)
    
    Li(:,n)=L*g(n)./g(xx);
end
a3_new=2.5;
Linterp=0:a3_new:1300;

for n=1:length(selected)
    Anew(:,n) = interp1(Li(:,n),A(:,n),Linterp)';
end


col=['g','b','r'];
sizplot=15;
figure(15)
if ishold==1;hold;end
plot(L,(A),'-','linewidth',2)
hold
plot(Linterp,(Anew),'--','linewidth',2),
legend('111-norm','222-norm','111','222')
set(gca,'fontsize',17)
xlabel('Fourier length L (10^-^1^0m)','fontsize',17)
ylabel('Fourier coeficients','fontsize',17)

 xlim([0 2.2*500])
 
%  figure(19)
% if ishold==1;hold;end
% plot(L,log(A),'-','linewidth',2)
% hold
% plot(Linterp,log(Anew),'-','linewidth',2),
% legend('111-norm','222-norm','111','222')
% set(gca,'fontsize',17)
% xlabel('Fourier length L (10^-^1^0m)','fontsize',17)
% ylabel('Fourier coeficients','fontsize',17)
% 
%  xlim([0 2.2*500])
%  
 
% % figure(4)
% if ishold==1;hold;end
lo=(length(Anew)-1);
lo=find(Anew(:,1)==0,1)-10

posval=1:15:lo;

Anew2=Anew(posval,:);
% plot(1./g,log(Anew(1:lo,:)),'o'),hold
% plot(1./g,(Anew2),'.k','markersize',28),hold
guesspar=[ 0.5 1 ];
for n=2:lo
    all_I(n,:)=lsqcurvefit(@logalt, guesspar ,g , log(Anew(n,:)) );
    all_I2(n,:)=lsqcurvefit(@linalt, all_I(n,:) ,g , (Anew(n,:)) );
    n,lo
end
for n=2:lo
fit(n,:)=logalt(all_I(n,:),g);
end
for n=2:lo
AA(n,:)=(linalt(all_I2(n,:),g));
end
fitb=fit(posval,:);
%  plot(1./g,exp(fitb),'-k','linewidth',2)
%  xlabel('1/g (10^-^1^0m)','fontsize',17)
%  ylabel('log of the Fourier coefficients','fontsize',17)
%  set(gca,'fontsize',17)
%  
 
 figure(11)
 if ishold==1;hold;end
 plot(Linterp(1:lo),exp(all_I(:,1)) ,'.-'),hold
% title('size')
%  figure(12)
 plot(Linterp(1:lo),exp(all_I(:,2)) ,'.-r')
 legend('size','strain')
 title('size strain fcs')
%plot(1./g,(AA),'-')
%%

gs =lsqcurvefit(@sizeFC, [500] , (Linterp(2:lo)), exp( all_I(1:lo-1,1)' ),0,10e04);%.*(L2(frst:lst)).^2';

%%
ratPOS=0.8;

% type(3)=type(3)*0.65;


frst=find( abs(Linterp-ratPOS*type(3))==min(abs(Linterp-ratPOS*type(3))) );
lst=find( abs(Linterp-ratPOS*type(4))==min(abs(Linterp-ratPOS*type(4))) );

if lst>lo-1;lst=lo;end
XL_m=-( all_I2(1:lo,2) )./Linterp(1:lo).^2';
% ub(1)=0;lb(2)=0;
% lb(1)=-10;ub(2)=inf;
XL =lsqcurvefit(@Kriv_Wilk, [-6.5e-03 0.5] , log(Linterp(frst:lst)), XL_m(frst:lst,:));

rho=XL(2);
Re=exp(XL(1)/rho);
M=rho^0.5*Re
rho=rho*1e4

XL_d=Kriv_Wilk(XL,log(Linterp(1:lo)));
% figure(5),if ishold==1;hold;end
% plot(log(Linterp(1:lo)), XL_m(1:lo,:) ,'o'),hold
% plot(log(Linterp(1:lo)),XL_d(1:lo,:))

figure(6),if ishold==1;hold;end
semilogx((Linterp(1:lo)), XL_m(1:lo,:) ,'o'),hold
plot((Linterp(1:lo)),XL_d(1:lo,:))
plot([ratPOS*type(3), ratPOS*type(3)],[0 4e-3])
plot([ratPOS*type(4), ratPOS*type(4)],[0 4e-3])

OUT=[0, gs, rho(1), M(1),0,a3];

for n=1:2
   all_Inew(:,n) = interp1(Linterp(1:lo),all_I(:,n),L)';
end


all_I=[];
all_I(:,3)=-(all_Inew(:,2));
 
all_I(:,2)=(all_Inew(:,1));
 

all_I(:,1)=zeros( size(all_Inew(:,1) ));


end
    function [lnAA lam]=logalt(lam, g)
        global B C xx
                lnAS=lam(1);
                lnAD=lam(2);
                lnAA = (lnAD*(B*C)) + lnAS*(g(xx)./g) ;
    end

    function [AA lam]=linalt(lam, g)
        global B C xx
                lnAS=lam(1);
                lnAD=lam(2);
                AA = exp(lnAD*(B*C)) * (1  - (g(xx)./g)* (1-exp(lnAS))  );
    end
    
    
    function [XL lam]=Kriv_Wilk(lam,lnL)
        for n=1:length(lnL)
        XL(n,:) = lam(1) -lam(2)*lnL(n);
        end
    end

function [AA lam]=sizeFC(lam, L)
        
                
                
                AA = exp(-L/lam(1) );
    end

