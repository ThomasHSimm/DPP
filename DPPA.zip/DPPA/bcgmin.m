function I_all=bcgmin(sample_n, selected, I_all)
ff=6;
bcg=zeros(1,2);
bcg=lsqcurvefit(@bcgmin_f,bcg, I_all,0);

I_all(:,selected,1)=I_all(:,selected,1)+bcg(1);        
I_all(:,selected,2)=I_all(:,selected,2)+bcg(2);

    function erro=bcgmin_f(lam, I_all)
        I_all(:,selected,1)=I_all(:,selected,1)+lam(1);        
        I_all(:,selected,2)=I_all(:,selected,2)+lam(2);
        
        [   FCi  FCnew FCm]=ts_findfourier_indi(I_all,sample_n,selected);
        
        lb=0;ub=inf;
        L=0:1:ff-1;L=L'*25;
        if exist('xf1')==0;xf1=500;end
        if exist('xf2')==0;xf2=500;end        
        if exist('xf3')==0;xf3=500;end
        
        [xf1 erro1]=lsqcurvefit(@gauss,xf1, L,FCnew(1:ff,selected),lb,ub);
        [xf2 erro2]=lsqcurvefit(@gauss,xf2, L,FCm(1:ff,selected),lb,ub);
        [xf3 erro3]=lsqcurvefit(@gauss,xf3, L,FCi(1:ff,selected),lb,ub);
        disp('');
        erro=erro1+erro2+erro3;
        
    end
    
    function GA=gauss(lam0,L)
        GA=1-L/lam0;
%             GA=exp(-L/lam0);
    end
end