function d=dspacing(dp, sym, lambda,lat1, lat2)

%%  find d-spacing values given symmetry and hkl values
% eg for hcp--> dp=[0 0 2;1 0 0;1 0 1;1 0 2;1 1 0;1 0 3;0 0 4;1 1 2;2 0 0;2 0 1;1 0 4] 
% mg--> lat1=3.210; lat2=1.624*3.21;lambda=0.179 (Co)
lenindex=size(dp,1);



if strcmp(sym, 'cub')==1
    crystalsymm=2;
elseif strcmp(sym, 'tet')==1
    crystalsymm=3;
elseif strcmp(sym, 'hex')==1
    crystalsymm=4;
end

switch crystalsymm
    case 1
%         d=lambda./(2*sin(peaks*pi/360));
    case 2
        for n=1:lenindex;
            lat1/(sum(dp(n,:).^2)).^0.5;
            d(n)=lat1/(sum(dp(n,:).^2)).^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
    case 3
        for n=1:lenindex;
            d(n)=1/( ( dp(n,1)^2 + dp(n,2)^2 )/lat1^2 + dp(n,3)^2/lat2^2 )^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
    case 4
        for n=1:lenindex;
            d(n)=1/( (4/3)*(dp(n,1)^2 + dp(n,1)*dp(n,2) + dp(n,2)^2)/lat1^2  +  dp(n,3)^2/lat2^2 )^0.5;
        end
        peaks=180*2*asin(lambda./(2*d))/pi;
        
end
k=1./d;