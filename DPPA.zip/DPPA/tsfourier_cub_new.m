function  [ OUT all_I]=tsfourier_cub_new(A,settings,selected,num)
%%%TH Simm 07
%%%possible inputs --> L2, A, a2
%%%                    a, standard (i.e. 'Si' or change fname)
%%                    a
global a sizA lat  g number delK l type same q_ind
a=[]; sizA=[]; lat=[]; g=[];  
a=[]; sizA=[]; lat=[]; g=[];  

same=0;
chk0=0.2;
H2=Hsq(settings(1,1).index(selected,:));
lat=0.35675*10;%for nickel 
B=0.5*pi*(lat/2^0.5)^2;
%b=lat/2^0.5
%B=0.5*pi*b^2
 
L2=0:1:(length(A)-1);
a3=0.5/delK;
L2=L2*a3;
L2=L2';
A=A(:,selected);

for n=1:length(selected)
    g(n)=1./settings(1,1).d(selected(n));
end

sizA=length(A);
lnA=log(A);
                

%%

st=2;%%starting L
%num=90;%%end L
st_1=st;num_1=num;
%% Initial Combined Fits 
options=optimset('tolx',1e-9,'tolf',1e-12);

% Fit of individual

qscrew=2.4699;
qedge=1.7180 ;
qv=.5*(qscrew+qedge);
guesspar=[qv -0.05 0.003];
%+0.2;



% % qv=1.718;
% % 
% % 
lb=[qedge*.8 -7 0   ];
ub=[qscrew*1.2 -1e-34 15 ];
% % 
% % 
% % lb=[qv*.99 -7 0   ];
% % ub=[qv*1.01 -1e-34 15 ];


guesspar_all=[qv,   1e6,    0.05e-4,      3];   %q gs rho  M
lb_all      =[lb(1), 1e-10,  1e-10,        0.1];
ub_all      =[ub(1), 1e20,   1e20,       10];

% The first fit gets the q-values but could be used as a fit on its own
all_I_together=lsqcurvefit(@allF_together, guesspar_all , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);
all_I_together=lsqcurvefit(@allF_together, all_I_together , L2(st:num), lnA((st:num),:),lb_all,ub_all,options);


qv=all_I_together(1);

guesspar(1)=qv;

lb(1)=qv-1e-4;ub(1)=qv+1e-4;

for nn=st:num
guesspar(nn,:)=guesspar(1,:);
end

% 2nd fit gets the gradient and intercept terms (used later)
all_I(st:num,:)=lsqcurvefit(@allF, guesspar(st:num,:) , L2(st:num), lnA((st:num),:),lb,ub,options);


%% Individual Fits

all_I(:,1)=qv*ones(size( all_I(:,1) ) ) ;
lb(1)=qv - 1e-4;
ub(1)=qv+1e-4;

q_ind=qv;

% load('Taylor_C_ti','newC_ax','newC_tran');

CHOI=4;%menu('What C value?','1. from fit of data','2. input','3. intergranular','4. load C values')
switch CHOI
    case 4
        
        for n=st:num
        all_I(n,:)=lsqcurvefit(@indivF, all_I(n,:) , L2(n), lnA(n,:),lb,ub,options);
        end
        
    case 1
%         C=newC_ax(selected);
%         
%         for n=st:num
%         all_I(n,2:3)=lsqcurvefit(@indiv_plas, all_I(n,2:3) , L2(n), lnA(n,:),lb(2:3),ub(2:3),options);
%         end
    case 2
         
%         qvals_opt=menu('Which one?','Ax 1', 'Ax 2', 'Ax 5', 'Ax 8', 'T 1','T 2','T 3.5', 'T 5','T 8');
%         
%         load('/Applications/MATLAB74/work/5. New Steelfit/Ti_WHres_axplustran1_1to15__28910.mat','q_all_ax','q_all_t')
%         switch qvals_opt
%             case 1
%                 qv1=q_all_ax(1,1); qv2=q_all_ax(1,2);
%             case 2
%                  qv1=q_all_ax(2,1); qv2=q_all_ax(2,2);
%             case 3
%                  qv1=q_all_ax(3,1); qv2=q_all_ax(3,2);
%             case 4
%                  qv1=q_all_ax(4,1); qv2=q_all_ax(4,2);
%             case 5
%                  qv1=q_all_t(1,1); qv2=q_all_t(1,2);
%             case 6
%                  qv1=q_all_t(2,1); qv2=q_all_t(2,2);
%             case 7
%                  qv1=.5*(q_all_t(2,1)+q_all_t(3,1)); 
%                  qv2=.5*(q_all_t(2,2)+q_all_t(3,2)); 
%             case 8
%                  qv1=q_all_t(3,1); qv2=q_all_t(3,2);
%             case 9
%                  qv1=q_all_t(4,1); qv2=q_all_t(4,2);
%         end
%         
%         lb(1)=qv1-1e-4;ub(1)=qv1+1e-4;
%         lb(4)=qv2-1e-4;ub(4)=qv2+1e-4;
%         for nn=st:num
%         all_I(nn,1)=qv1;
%         all_I(nn,4)=qv2;
%         end
%     
%         for n=st:num
%         all_I(n,:)=lsqcurvefit(@indivF, all_I(n,:) , L2(n), lnA(n,:),lb,ub,options);
%         end
        
    case 3
        
%         guesspar=[2 1e-10 88 1e-04  10000] ;
%         Mlb=2;
%         lb=[1.5;0;zeros(1,1);Mlb; 0];ub=[2.4;5e-3;1e-4;7; 1e6 ];
% %         lb(5)=0;ub(5)=1e-2;
%         C=newC_tran(selected)*0+1;
%         all_I_inter=lsqcurvefit(@allF_inter, guesspar , L2(st:num), exp(lnA((st:num),:)),lb,ub,options)
%         all_I_inter=lsqcurvefit(@allF_inter, all_I_inter , L2(st:num), exp(lnA((st:num),:)),lb,ub,options)
%         all_I_inter(5)=3*all_I_inter(3)^-0.5;
%         ;
end
%% Fit of strain & size
if CHOI~=3;
            

            frst=find( abs(L2-type(3))==min(abs(L2-type(3))) ,1);
            lst=find( abs(L2-type(4))==min(abs(L2-type(4))) ,1);
            
            if lst>num;lst=num;end
            
            XL_m=( all_I(1:num,3) )./L2(1:num).^2;
            posnot=find(all_I(1:num,3)>-inf);
            posnot=posnot( find(posnot>5 & posnot<num) );
            XL =lsqcurvefit(@Kriv_Wilk, [6.5e-03 0.5] , log(L2(frst:lst)), XL_m(frst:lst,:));

            %%
            rho=XL(2);Re=exp(XL(1)/rho);
            lb=[5 1e-07];ub=[3000 1e-03];
%             XL2 =lsqcurvefit(@Wilkens3, [Re rho] , (L2(posnot)), XL_m(posnot),lb,ub,options)%.*(L2(frst:lst)).^2';
            XL2 =lsqcurvefit(@Wilkens3, [Re rho] , (L2(frst:lst)), XL_m(frst:lst),lb,ub,options);%.*(L2(frst:lst)).^2';

            %%
            % sizefit =lsqcurvefit(@sizeFC, [500] , (L2(st:num)), exp( all_I(st:num,2) ),0,10e04,options);%.*(L2(frst:lst)).^2';

            %%
            % all_I2=lsqcurvefit(@allF,[qv sizefit 88 1e-05]  , L2(2:num), lnA(2:num,:),[1.5;sizefit*.8;zeros(2,1)],[2.4;sizefit*1.2;inf*ones(2,1) ] );
            % sizes=all_I2(2);rhoall=all_I2(3);Reall=all_I2(4);

            % posnot=find(all_I(1:num-1,2)>-inf | abs(diff(all_I(1:num,2)))>0.5 );
            sizefit =lsqcurvefit(@sizeFC, [300 ] , (L2(posnot)), exp( all_I(posnot,2) ),[0 ],[100000000],options);%10e04,options);%.*(L2(frst:lst)).^2';


            %% 
            q=qv;
            gs=sizefit(1);
            rho=XL(2);
            Re=exp(XL(1)/rho);
            M=rho^0.5*Re;

            rho(2)=XL2(2);
            Re(2)=XL2(1);
            M(2)=rho(2)^0.5*Re(2);

            RerhoM=[Re(2),rho(2)*1e20*1e-16,M(2)];

OUT=[q, gs, rho(1)*1e4, M(1),a3]; 

else
    OUT=[all_I_inter,a3];
    OUT(3)=OUT(3)*1e4;
    gs=OUT(5);mss=OUT(2);
    OUT(2)=gs;OUT(5)=mss;
end


%%
    function [lnAA lam]=indivF(lam, L)
        
                
        
        q=q_ind;
        
        C=chk0*(1-q*H2)  ;      
             
           
                lnAA = (lam(2)) - B*real(lam(3))*g.^2.*C ;
                if min(C)<0;lnAA=inf*lnAA;
                end
    end 

% %%
% function [lnAA lam]=indiv_plas(lam, L)
%                 
%         
% %         x=(2/3)*((l./(g*2.95)).^2);
% %         C=(1+lam(1)*x + lam(4)*x.^2)  ;      
%               q=lam(1);
%            C=chk0*(1-q*H2)  ;      
%                 lnAA = (lam(1)) - B*real(lam(2))*g.^2.*C ;
% %                 if min(C)<0;lnAA=inf*lnAA;
% %                 end
%     end 

%%

function [lnAA lam]=allF(lam, L)
        
       q=lam(1);
       C=chk0*(1-q*H2)  ;      
       
             
           for no=1:length(L)
                lnAA(no,:) = (lam(no,2)) - B*real(lam(no,3))*g.^2.*C ;
           end
                if min(C)<0;lnAA=inf*lnAA;
                end
end

function [lnAA lam]=allF_together(lam, L)
        
             
         q=lam(1);
C=chk0*(1-q*H2)  ;      
             
          
               
           
                for na=1:length(L)       
                lnAA(na,:)=(-L(na)/lam(2) ) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  ;
                end
                
                if min(C)<0;lnAA=inf*lnAA;
                end
end


function [lnAA lam]=allF_inter(lam, L)
            lnAA=zeros(length(L),length(g));
            siza=3*lam(3)^-0.5;
           for na=1:length(L)       
                lnAA(na,:)=exp( (-L(na)/siza )-L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  - 2*pi^2*g.^2*L(na)^2*lam(2)^2  );
           end
           
                if min(C)<0;lnAA=inf*lnAA;
                end
                
               
end

%%


function [AA lam]=sizeFC(lam, L)
        
                
                
                AA = exp(-L/lam(1) );
    end 


function [AA lam]=sizeFC2(lam, L)                
                AA = lam(3)*ASlognormSc(lam(1:2),L);
end 


    function [XL lam]=Kriv_Wilk(lam,lnL)
        for n=1:length(lnL)
        XL(n,:) = lam(1) -lam(2)*lnL(n,:);
        end
    end
%%
end
