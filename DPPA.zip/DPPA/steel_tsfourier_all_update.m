function  [ OUT all_I]=steel_tsfourier_all(A,settings,selected,num,guesspar)
%%%TH Simm 07
%%%possible inputs --> L2, A, a2
%%%                    a, standard (i.e. 'Si' or change fname)
%%                    a
global a sizA lat Choo g H2 number delK type

a=[]; sizA=[]; lat=[]; g=[];  number=[];
number=[ 1 2 3 4 5];

H2=Hsq(settings(1,1).index(selected,:));

lat=0.35675*10;%for nickel 
B=0.5*pi*(lat/2^0.5)^2;
L2=0:1:(length(A)-1);
a3=0.5/delK;
L2=L2*a3;L2=L2';
A=A(:,selected);

for n=1:length(selected)
    g(n)=1./settings(1,1).d(selected(n));
end

sizA=length(A);
lnA=log(A);

%%
tth=0:1:sizA-1;tth=tth*delK*2/(sizA-1);tth=tth-delK;
%%
st=2;
st_1=st;num_1=num;
%%
options=optimset('tolx',1e-4,'tolf',1e-4);

guesspar=[2 300 88 1e-05  ] ;

    guesspar=guesspar(1:4);
    guesspar(3)=guesspar(3)*1e-4;
    guesspar(2)=guesspar(2);
    guesspar(5)=guesspar(2)/10;
    guesspar(6)=0.5;
    
%%
qlb= 1.374400000000000;
qub= 2.963880000000000;

Mlb=.1;
all_I2=lsqcurvefit(@allF,guesspar , L2(2:num), exp(lnA(2:num,:)),[qlb;10;zeros(1,1);Mlb;5;0],[qub;100000;10e-4;10 ;1e5;1] );
options=optimset('tolx',1e-9,'tolf',1e-9);
all_I2=lsqcurvefit(@allF,all_I2 , L2(2:num), exp(lnA(2:num,:)),[qlb;10;zeros(1,1);Mlb;5;0],[qub;100000;10e-4;10 ;10e4;1] );
options=optimset('tolx',1e-9,'tolf',1e-12);
all_I2=lsqcurvefit(@allF,all_I2 , L2(2:num), exp(lnA(2:num,:)),[qlb;10;zeros(1,1);Mlb;5;0],[qub;100000;10e-4;10 ;10e4;1] );
options=optimset('tolx',1e-15,'tolf',1e-15);
all_I2=lsqcurvefit(@allF,all_I2 , L2(2:num), exp(lnA(2:num,:)),[qlb;10;zeros(1,1);Mlb;5;0],[qub;100000;10e-4;10;10e4;1] )


sizes=all_I2(2);rhoall=all_I2(3);Reall=all_I2(4);


%% 
figure(69),if ishold==1;hold;end
plot(L2,A,'o'),hold
plot(L2,(allF(all_I2,L2)))
maxL=L2(find(A==0,1));
xlim([0 maxL+100])
legend('111','200','220','311','222')
OUT=[all_I2,0,a3]; 
OUT(3)=OUT(3)*1e4;

all_I(:,2)=(- L2*1/(all_I2(2)) );

all_I(:,3)=L2.^2.*all_I2(3).*log( (all_I2(4)/all_I2(3).^.5) ./L2);
all_I(:,1)=all_I2(1)*ones(length(L2),1);
%%          Functions


function [AA lam]=allF(lam, L) 
                q=lam(1);
                
                C=0.32*(1-q*H2);

                for na=1:length(L)       
                AA(na,:)=exp(  log(ASlognormSc([lam(2),lam(5)],L(na))) - L(na)^2*B*Wilkens3([ (lam(4)/lam(3).^.5) , lam(3)],L(na) ) *g.^2.*C  );
                end
end
%%
end