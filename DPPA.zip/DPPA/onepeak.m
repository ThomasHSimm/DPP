function anew=onepeak(tth,F,astart)
load([cd,'/0. variables/genset.mat'],'bcg2peak','wavelen','alpha2')
if astart(4,end)~=0
    fpos=astart(4,end);
end
asymmq=size(astart,1);
lb=zeros(size(astart));
ub=inf*ones(size(astart));
lb(1,end)=-inf;
lb(2,end)=-inf;

for mb=1:size(astart,2)-1
    if astart(2,mb)<0
        astart(2,mb)=1e-7;
    end
end
% lb(1,end)=astart(1,end)-1e-3;
% lb(2,end)=astart(2,end)-1e-3;
% 
% ub(1,end)=astart(1,end)+1e-3;
% ub(2,end)=astart(2,end)+1e-3;


if asymmq==6
    %new change
%     lb(3,end)=-1e-50;
%     ub(3,end)=1e-50;
end
if size(astart,2)>2
    lb(1,1:end-1)=.9*astart(1,1:end-1);
    ub(1,1:end-1)=1.1*astart(1,1:end-1);
    if .01*astart(2,1:end-1)<max(F)
        lb(2,1:end-1)=.01*astart(2,1:end-1);
    else
        lb(2,1:end-1)=0;
    end
    ub(2,1:end-1)=max(F);
    
    
    lb(4,1:end-1)=0;
    ub(4,1:end-1)=1.3;
    ub(1,1:end-1)=1.0001*astart(1,1:end-1);
    lb(1,1:end-1)=.9999*astart(1,1:end-1);
    lb(3,1:end-1)=.1*astart(3,1:end-1);
    ub(3,1:end-1)=1e-2;
    
    
    if asymmq==6
        lb(6,1:end-1)=0;
        ub(6,1:end-1)=1.3;
        lb(5,1:end-1)=.1*astart(3,1:end-1);    
        ub(5,1:end-1)=1e-2;
    end
    
    
%     for mk=1:size(lb,2)-1
%         lb(3,mk)
%     end
    

end

lb(1,fpos)=astart(1,fpos)-bcg2peak;
ub(1,fpos)=astart(1,fpos)+bcg2peak;
lb(2,fpos)=astart(2,fpos)*.1;
ub(2,fpos)=astart(2,fpos)*10;
ub(3,fpos)=bcg2peak/2.5;
lb(3,fpos)=1e-6;
ub(4,fpos)=1.3;
lb(4,fpos)=0;


if asymmq==6
    ub(5,fpos)=1e-2;
    lb(5,fpos)=1e-6;
    ub(6,fpos)=1.3;
    lb(6,fpos)=0;
end

% if aa(1,1)>5
%     ub(
%     
    
    
zeroaas=find(ub(1,:)-lb(1,:)==0);
ub(1,zeroaas)=1e-05;
lb(1,zeroaas)=-1e-05;
if asymmq==6
anew=lsqcurvefit(@pv_tv_asymm, astart, tth,F,lb,ub) ;
else
anew=lsqcurvefit(@pv_tv_aab, astart, tth,F,lb,ub) ;
end 
 
end
 
            function F= pv_tv_aab(lam0, x)
            global alpha2
            len=size(lam0,2);
            npks=(len-1);
            F=zeros(size(x));
            if npks>0
            for n=1:npks

                lam(1:4)=lam0(:,n);
                if alpha2==1
                [fia lam]=pk_voigt2(x,lam); %if no alpha2 present
                elseif alpha2==0
                [fia lam]=pk_alpha(x,lam);
                end
                F=F+fia;
            end
            end
            backgd =  lam0(1,len) + x*lam0(2,len) ;%+ lam0(3,len)*x.^2;
            F=F+backgd;

            end
            
            
            
            function F= pv_tv_asymm(lam0, x)
            global alpha2
            len=size(lam0,2);
            npks=(len-1);
            F=zeros(size(x));
            
            
            for n=1:npks

                lam(1:6)=lam0(:,n);
%                 if alpha2==1
%                 [fia lam]=pk_voigt2(x,lam); %if no alpha2 present
%                 elseif alpha2==0
                [fia ]=pk_alpha_asymm(x,lam);
%                 end
                F=F+fia;
            end

            backgd =  lam0(1,len) + x*lam0(2,len) ;
            F=F+backgd;
            for nx=1:size(lam0,2)
                if max(imag(lam0(:,nx)))~=0
                    F=F*1e9;
                end
            end

            end