function Iout=oneside(I,LR)
    switch LR
        case 1
    len=length(I);lenhalf=(len+1)/2;
    Iout=I;
    Iout(1:lenhalf)=I(1:lenhalf);
    Iout(lenhalf:end)=flipud(I(1:lenhalf));
        case 2
            
    len=length(I);lenhalf=(len+1)/2;
    Iout=I;
    
    Iout(1:lenhalf)=flipud(I(lenhalf:end));
    end
end